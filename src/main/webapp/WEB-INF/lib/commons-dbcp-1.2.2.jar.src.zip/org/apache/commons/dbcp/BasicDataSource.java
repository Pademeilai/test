/*      */ package org.apache.commons.dbcp;
/*      */ 
/*      */ import java.io.PrintWriter;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Driver;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Properties;
/*      */ import javax.sql.DataSource;
/*      */ import org.apache.commons.pool.KeyedObjectPoolFactory;
/*      */ import org.apache.commons.pool.ObjectPool;
/*      */ import org.apache.commons.pool.impl.GenericKeyedObjectPoolFactory;
/*      */ import org.apache.commons.pool.impl.GenericObjectPool;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BasicDataSource
/*      */   implements DataSource
/*      */ {
/*      */   protected boolean defaultAutoCommit = true;
/*      */   
/*      */   public synchronized boolean getDefaultAutoCommit() {
/*   59 */     return this.defaultAutoCommit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDefaultAutoCommit(boolean defaultAutoCommit) {
/*   74 */     this.defaultAutoCommit = defaultAutoCommit;
/*   75 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   82 */   protected Boolean defaultReadOnly = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean getDefaultReadOnly() {
/*   90 */     if (this.defaultReadOnly != null) {
/*   91 */       return this.defaultReadOnly.booleanValue();
/*      */     }
/*   93 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDefaultReadOnly(boolean defaultReadOnly) {
/*  107 */     this.defaultReadOnly = defaultReadOnly ? Boolean.TRUE : Boolean.FALSE;
/*  108 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   protected int defaultTransactionIsolation = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getDefaultTransactionIsolation() {
/*  123 */     return this.defaultTransactionIsolation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDefaultTransactionIsolation(int defaultTransactionIsolation) {
/*  140 */     this.defaultTransactionIsolation = defaultTransactionIsolation;
/*  141 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  148 */   protected String defaultCatalog = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getDefaultCatalog() {
/*  156 */     return this.defaultCatalog;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDefaultCatalog(String defaultCatalog) {
/*  170 */     if (defaultCatalog != null && defaultCatalog.trim().length() > 0) {
/*  171 */       this.defaultCatalog = defaultCatalog;
/*      */     } else {
/*      */       
/*  174 */       this.defaultCatalog = null;
/*      */     } 
/*  176 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  183 */   protected String driverClassName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getDriverClassName() {
/*  191 */     return this.driverClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDriverClassName(String driverClassName) {
/*  205 */     if (driverClassName != null && driverClassName.trim().length() > 0) {
/*  206 */       this.driverClassName = driverClassName;
/*      */     } else {
/*      */       
/*  209 */       this.driverClassName = null;
/*      */     } 
/*  211 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  219 */   protected int maxActive = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getMaxActive() {
/*  230 */     return this.maxActive;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMaxActive(int maxActive) {
/*  241 */     this.maxActive = maxActive;
/*  242 */     if (this.connectionPool != null) {
/*  243 */       this.connectionPool.setMaxActive(maxActive);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  251 */   protected int maxIdle = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getMaxIdle() {
/*  262 */     return this.maxIdle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMaxIdle(int maxIdle) {
/*  273 */     this.maxIdle = maxIdle;
/*  274 */     if (this.connectionPool != null) {
/*  275 */       this.connectionPool.setMaxIdle(maxIdle);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  283 */   protected int minIdle = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getMinIdle() {
/*  292 */     return this.minIdle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMinIdle(int minIdle) {
/*  302 */     this.minIdle = minIdle;
/*  303 */     if (this.connectionPool != null) {
/*  304 */       this.connectionPool.setMinIdle(minIdle);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  314 */   protected int initialSize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getInitialSize() {
/*  322 */     return this.initialSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setInitialSize(int initialSize) {
/*  337 */     this.initialSize = initialSize;
/*  338 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  346 */   protected long maxWait = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long getMaxWait() {
/*  357 */     return this.maxWait;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMaxWait(long maxWait) {
/*  367 */     this.maxWait = maxWait;
/*  368 */     if (this.connectionPool != null) {
/*  369 */       this.connectionPool.setMaxWait(maxWait);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean poolPreparedStatements = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isPoolPreparedStatements() {
/*  384 */     return this.poolPreparedStatements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPoolPreparedStatements(boolean poolingStatements) {
/*  398 */     this.poolPreparedStatements = poolingStatements;
/*  399 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  408 */   protected int maxOpenPreparedStatements = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getMaxOpenPreparedStatements() {
/*  417 */     return this.maxOpenPreparedStatements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMaxOpenPreparedStatements(int maxOpenStatements) {
/*  433 */     this.maxOpenPreparedStatements = maxOpenStatements;
/*  434 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean testOnBorrow = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean getTestOnBorrow() {
/*  453 */     return this.testOnBorrow;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTestOnBorrow(boolean testOnBorrow) {
/*  465 */     this.testOnBorrow = testOnBorrow;
/*  466 */     if (this.connectionPool != null) {
/*  467 */       this.connectionPool.setTestOnBorrow(testOnBorrow);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean testOnReturn = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean getTestOnReturn() {
/*  485 */     return this.testOnReturn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTestOnReturn(boolean testOnReturn) {
/*  497 */     this.testOnReturn = testOnReturn;
/*  498 */     if (this.connectionPool != null) {
/*  499 */       this.connectionPool.setTestOnReturn(testOnReturn);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  508 */   protected long timeBetweenEvictionRunsMillis = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long getTimeBetweenEvictionRunsMillis() {
/*  519 */     return this.timeBetweenEvictionRunsMillis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTimeBetweenEvictionRunsMillis(long timeBetweenEvictionRunsMillis) {
/*  529 */     this.timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis;
/*  530 */     if (this.connectionPool != null) {
/*  531 */       this.connectionPool.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  539 */   protected int numTestsPerEvictionRun = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getNumTestsPerEvictionRun() {
/*  550 */     return this.numTestsPerEvictionRun;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setNumTestsPerEvictionRun(int numTestsPerEvictionRun) {
/*  561 */     this.numTestsPerEvictionRun = numTestsPerEvictionRun;
/*  562 */     if (this.connectionPool != null) {
/*  563 */       this.connectionPool.setNumTestsPerEvictionRun(numTestsPerEvictionRun);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  571 */   protected long minEvictableIdleTimeMillis = 1800000L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long getMinEvictableIdleTimeMillis() {
/*  581 */     return this.minEvictableIdleTimeMillis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMinEvictableIdleTimeMillis(long minEvictableIdleTimeMillis) {
/*  592 */     this.minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
/*  593 */     if (this.connectionPool != null) {
/*  594 */       this.connectionPool.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean testWhileIdle = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean getTestWhileIdle() {
/*  613 */     return this.testWhileIdle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTestWhileIdle(boolean testWhileIdle) {
/*  625 */     this.testWhileIdle = testWhileIdle;
/*  626 */     if (this.connectionPool != null) {
/*  627 */       this.connectionPool.setTestWhileIdle(testWhileIdle);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getNumActive() {
/*  638 */     if (this.connectionPool != null) {
/*  639 */       return this.connectionPool.getNumActive();
/*      */     }
/*  641 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getNumIdle() {
/*  653 */     if (this.connectionPool != null) {
/*  654 */       return this.connectionPool.getNumIdle();
/*      */     }
/*  656 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  664 */   protected String password = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getPassword() {
/*  672 */     return this.password;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPassword(String password) {
/*  686 */     this.password = password;
/*  687 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  694 */   protected String url = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getUrl() {
/*  703 */     return this.url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUrl(String url) {
/*  717 */     this.url = url;
/*  718 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  725 */   protected String username = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getUsername() {
/*  734 */     return this.username;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUsername(String username) {
/*  748 */     this.username = username;
/*  749 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  758 */   protected String validationQuery = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getValidationQuery() {
/*  768 */     return this.validationQuery;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setValidationQuery(String validationQuery) {
/*  782 */     if (validationQuery != null && validationQuery.trim().length() > 0) {
/*  783 */       this.validationQuery = validationQuery;
/*      */     } else {
/*  785 */       this.validationQuery = null;
/*      */     } 
/*  787 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean accessToUnderlyingConnectionAllowed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isAccessToUnderlyingConnectionAllowed() {
/*  802 */     return this.accessToUnderlyingConnectionAllowed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAccessToUnderlyingConnectionAllowed(boolean allow) {
/*  818 */     this.accessToUnderlyingConnectionAllowed = allow;
/*  819 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean restartNeeded = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized boolean isRestartNeeded() {
/*  841 */     return this.restartNeeded;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  847 */   protected GenericObjectPool connectionPool = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  855 */   protected Properties connectionProperties = new Properties();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  862 */   protected DataSource dataSource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  867 */   protected PrintWriter logWriter = new PrintWriter(System.out);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AbandonedConfig abandonedConfig;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection() throws SQLException {
/*  880 */     return createDataSource().getConnection();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection(String username, String password) throws SQLException {
/*  899 */     throw new UnsupportedOperationException("Not supported by BasicDataSource");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLoginTimeout() throws SQLException {
/*  916 */     return createDataSource().getLoginTimeout();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PrintWriter getLogWriter() throws SQLException {
/*  930 */     return createDataSource().getLogWriter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoginTimeout(int loginTimeout) throws SQLException {
/*  945 */     createDataSource().setLoginTimeout(loginTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLogWriter(PrintWriter logWriter) throws SQLException {
/*  959 */     createDataSource().setLogWriter(logWriter);
/*  960 */     this.logWriter = logWriter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getRemoveAbandoned() {
/*  977 */     if (this.abandonedConfig != null) {
/*  978 */       return this.abandonedConfig.getRemoveAbandoned();
/*      */     }
/*  980 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRemoveAbandoned(boolean removeAbandoned) {
/*  988 */     if (this.abandonedConfig == null) {
/*  989 */       this.abandonedConfig = new AbandonedConfig();
/*      */     }
/*  991 */     this.abandonedConfig.setRemoveAbandoned(removeAbandoned);
/*  992 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRemoveAbandonedTimeout() {
/* 1003 */     if (this.abandonedConfig != null) {
/* 1004 */       return this.abandonedConfig.getRemoveAbandonedTimeout();
/*      */     }
/* 1006 */     return 300;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRemoveAbandonedTimeout(int removeAbandonedTimeout) {
/* 1014 */     if (this.abandonedConfig == null) {
/* 1015 */       this.abandonedConfig = new AbandonedConfig();
/*      */     }
/* 1017 */     this.abandonedConfig.setRemoveAbandonedTimeout(removeAbandonedTimeout);
/* 1018 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getLogAbandoned() {
/* 1034 */     if (this.abandonedConfig != null) {
/* 1035 */       return this.abandonedConfig.getLogAbandoned();
/*      */     }
/* 1037 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLogAbandoned(boolean logAbandoned) {
/* 1045 */     if (this.abandonedConfig == null) {
/* 1046 */       this.abandonedConfig = new AbandonedConfig();
/*      */     }
/* 1048 */     this.abandonedConfig.setLogAbandoned(logAbandoned);
/* 1049 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addConnectionProperty(String name, String value) {
/* 1065 */     this.connectionProperties.put(name, value);
/* 1066 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeConnectionProperty(String name) {
/* 1076 */     this.connectionProperties.remove(name);
/* 1077 */     this.restartNeeded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close() throws SQLException {
/* 1087 */     GenericObjectPool oldpool = this.connectionPool;
/* 1088 */     this.connectionPool = null;
/* 1089 */     this.dataSource = null;
/*      */     try {
/* 1091 */       if (oldpool != null) {
/* 1092 */         oldpool.close();
/*      */       }
/* 1094 */     } catch (SQLException e) {
/* 1095 */       throw e;
/* 1096 */     } catch (RuntimeException e) {
/* 1097 */       throw e;
/* 1098 */     } catch (Exception e) {
/* 1099 */       throw new SQLNestedException("Cannot close connection pool", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized DataSource createDataSource() throws SQLException {
/* 1123 */     if (this.dataSource != null) {
/* 1124 */       return this.dataSource;
/*      */     }
/*      */ 
/*      */     
/* 1128 */     if (this.driverClassName != null) {
/*      */       try {
/* 1130 */         Class.forName(this.driverClassName);
/* 1131 */       } catch (Throwable t) {
/* 1132 */         String message = "Cannot load JDBC driver class '" + this.driverClassName + "'";
/*      */         
/* 1134 */         this.logWriter.println(message);
/* 1135 */         t.printStackTrace(this.logWriter);
/* 1136 */         throw new SQLNestedException(message, t);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1141 */     Driver driver = null;
/*      */     try {
/* 1143 */       driver = DriverManager.getDriver(this.url);
/* 1144 */     } catch (Throwable t) {
/* 1145 */       String message = "Cannot create JDBC driver of class '" + ((this.driverClassName != null) ? this.driverClassName : "") + "' for connect URL '" + this.url + "'";
/*      */ 
/*      */       
/* 1148 */       this.logWriter.println(message);
/* 1149 */       t.printStackTrace(this.logWriter);
/* 1150 */       throw new SQLNestedException(message, t);
/*      */     } 
/*      */ 
/*      */     
/* 1154 */     if (this.validationQuery == null) {
/* 1155 */       setTestOnBorrow(false);
/* 1156 */       setTestOnReturn(false);
/* 1157 */       setTestWhileIdle(false);
/*      */     } 
/*      */ 
/*      */     
/* 1161 */     if (this.abandonedConfig != null && this.abandonedConfig.getRemoveAbandoned()) {
/* 1162 */       this.connectionPool = new AbandonedObjectPool(null, this.abandonedConfig);
/*      */     } else {
/*      */       
/* 1165 */       this.connectionPool = new GenericObjectPool();
/*      */     } 
/* 1167 */     this.connectionPool.setMaxActive(this.maxActive);
/* 1168 */     this.connectionPool.setMaxIdle(this.maxIdle);
/* 1169 */     this.connectionPool.setMinIdle(this.minIdle);
/* 1170 */     this.connectionPool.setMaxWait(this.maxWait);
/* 1171 */     this.connectionPool.setTestOnBorrow(this.testOnBorrow);
/* 1172 */     this.connectionPool.setTestOnReturn(this.testOnReturn);
/* 1173 */     this.connectionPool.setTimeBetweenEvictionRunsMillis(this.timeBetweenEvictionRunsMillis);
/* 1174 */     this.connectionPool.setNumTestsPerEvictionRun(this.numTestsPerEvictionRun);
/* 1175 */     this.connectionPool.setMinEvictableIdleTimeMillis(this.minEvictableIdleTimeMillis);
/* 1176 */     this.connectionPool.setTestWhileIdle(this.testWhileIdle);
/*      */ 
/*      */     
/* 1179 */     GenericKeyedObjectPoolFactory statementPoolFactory = null;
/* 1180 */     if (isPoolPreparedStatements()) {
/* 1181 */       statementPoolFactory = new GenericKeyedObjectPoolFactory(null, -1, (byte)0, 0L, 1, this.maxOpenPreparedStatements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1190 */     if (this.username != null) {
/* 1191 */       this.connectionProperties.put("user", this.username);
/*      */     } else {
/* 1193 */       log("DBCP DataSource configured without a 'username'");
/*      */     } 
/*      */     
/* 1196 */     if (this.password != null) {
/* 1197 */       this.connectionProperties.put("password", this.password);
/*      */     } else {
/* 1199 */       log("DBCP DataSource configured without a 'password'");
/*      */     } 
/*      */     
/* 1202 */     DriverConnectionFactory driverConnectionFactory = new DriverConnectionFactory(driver, this.url, this.connectionProperties);
/*      */ 
/*      */ 
/*      */     
/* 1206 */     PoolableConnectionFactory connectionFactory = null;
/*      */     try {
/* 1208 */       connectionFactory = new PoolableConnectionFactory(driverConnectionFactory, (ObjectPool)this.connectionPool, (KeyedObjectPoolFactory)statementPoolFactory, this.validationQuery, this.defaultReadOnly, this.defaultAutoCommit, this.defaultTransactionIsolation, this.defaultCatalog, this.abandonedConfig);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1218 */       if (connectionFactory == null) {
/* 1219 */         throw new SQLException("Cannot create PoolableConnectionFactory");
/*      */       }
/* 1221 */       validateConnectionFactory(connectionFactory);
/* 1222 */     } catch (RuntimeException e) {
/* 1223 */       throw e;
/* 1224 */     } catch (Exception e) {
/* 1225 */       throw new SQLNestedException("Cannot create PoolableConnectionFactory (" + e.getMessage() + ")", e);
/*      */     } 
/*      */ 
/*      */     
/* 1229 */     this.dataSource = new PoolingDataSource((ObjectPool)this.connectionPool);
/* 1230 */     ((PoolingDataSource)this.dataSource).setAccessToUnderlyingConnectionAllowed(isAccessToUnderlyingConnectionAllowed());
/* 1231 */     this.dataSource.setLogWriter(this.logWriter);
/*      */     
/*      */     try {
/* 1234 */       for (int i = 0; i < this.initialSize; i++) {
/* 1235 */         this.connectionPool.addObject();
/*      */       }
/* 1237 */     } catch (Exception e) {
/* 1238 */       throw new SQLNestedException("Error preloading the connection pool", e);
/*      */     } 
/*      */     
/* 1241 */     return this.dataSource;
/*      */   }
/*      */   
/*      */   private static void validateConnectionFactory(PoolableConnectionFactory connectionFactory) throws Exception {
/* 1245 */     Connection conn = null;
/*      */     try {
/* 1247 */       conn = (Connection)connectionFactory.makeObject();
/* 1248 */       connectionFactory.activateObject(conn);
/* 1249 */       connectionFactory.validateConnection(conn);
/* 1250 */       connectionFactory.passivateObject(conn);
/*      */     } finally {
/*      */       
/* 1253 */       connectionFactory.destroyObject(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void restart() {
/*      */     try {
/* 1262 */       close();
/* 1263 */     } catch (SQLException e) {
/* 1264 */       log("Could not restart DataSource, cause: " + e.getMessage());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void log(String message) {
/* 1269 */     if (this.logWriter != null)
/* 1270 */       this.logWriter.println(message); 
/*      */   }
/*      */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\BasicDataSource.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */