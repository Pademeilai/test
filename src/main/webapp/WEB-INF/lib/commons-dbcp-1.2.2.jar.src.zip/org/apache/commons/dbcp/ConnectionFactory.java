package org.apache.commons.dbcp;

import java.sql.Connection;
import java.sql.SQLException;

public interface ConnectionFactory {
  Connection createConnection() throws SQLException;
}


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\ConnectionFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */