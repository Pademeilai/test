/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.net.URL;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Date;
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.Ref;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingPreparedStatement
/*     */   extends DelegatingStatement
/*     */   implements PreparedStatement
/*     */ {
/*  54 */   protected PreparedStatement _stmt = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingPreparedStatement(DelegatingConnection c, PreparedStatement s) {
/*  66 */     super(c, s);
/*  67 */     this._stmt = s;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*  71 */     PreparedStatement delegate = (PreparedStatement)getInnermostDelegate();
/*  72 */     if (delegate == null) {
/*  73 */       return false;
/*     */     }
/*  75 */     if (obj instanceof DelegatingPreparedStatement) {
/*  76 */       DelegatingPreparedStatement s = (DelegatingPreparedStatement)obj;
/*  77 */       return delegate.equals(s.getInnermostDelegate());
/*     */     } 
/*     */     
/*  80 */     return delegate.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelegate(PreparedStatement s) {
/*  86 */     setDelegate(s);
/*  87 */     this._stmt = s;
/*     */   }
/*     */   
/*     */   public ResultSet executeQuery() throws SQLException {
/*  91 */     checkOpen();
/*     */     try {
/*  93 */       return DelegatingResultSet.wrapResultSet(this, this._stmt.executeQuery());
/*     */     }
/*  95 */     catch (SQLException e) {
/*  96 */       handleException(e);
/*  97 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int executeUpdate() throws SQLException {
/* 102 */     checkOpen(); try { return this._stmt.executeUpdate(); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public void setNull(int parameterIndex, int sqlType) throws SQLException {
/* 105 */     checkOpen(); try { this._stmt.setNull(parameterIndex, sqlType); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setBoolean(int parameterIndex, boolean x) throws SQLException {
/* 108 */     checkOpen(); try { this._stmt.setBoolean(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setByte(int parameterIndex, byte x) throws SQLException {
/* 111 */     checkOpen(); try { this._stmt.setByte(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setShort(int parameterIndex, short x) throws SQLException {
/* 114 */     checkOpen(); try { this._stmt.setShort(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setInt(int parameterIndex, int x) throws SQLException {
/* 117 */     checkOpen(); try { this._stmt.setInt(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setLong(int parameterIndex, long x) throws SQLException {
/* 120 */     checkOpen(); try { this._stmt.setLong(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setFloat(int parameterIndex, float x) throws SQLException {
/* 123 */     checkOpen(); try { this._stmt.setFloat(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setDouble(int parameterIndex, double x) throws SQLException {
/* 126 */     checkOpen(); try { this._stmt.setDouble(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
/* 129 */     checkOpen(); try { this._stmt.setBigDecimal(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setString(int parameterIndex, String x) throws SQLException {
/* 132 */     checkOpen(); try { this._stmt.setString(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setBytes(int parameterIndex, byte[] x) throws SQLException {
/* 135 */     checkOpen(); try { this._stmt.setBytes(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setDate(int parameterIndex, Date x) throws SQLException {
/* 138 */     checkOpen(); try { this._stmt.setDate(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setTime(int parameterIndex, Time x) throws SQLException {
/* 141 */     checkOpen(); try { this._stmt.setTime(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
/* 144 */     checkOpen(); try { this._stmt.setTimestamp(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
/* 147 */     checkOpen(); try { this._stmt.setAsciiStream(parameterIndex, x, length); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   }
/*     */   public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
/* 151 */     checkOpen(); try { this._stmt.setUnicodeStream(parameterIndex, x, length); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
/* 154 */     checkOpen(); try { this._stmt.setBinaryStream(parameterIndex, x, length); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void clearParameters() throws SQLException {
/* 157 */     checkOpen(); try { this._stmt.clearParameters(); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException {
/* 160 */     checkOpen(); try { this._stmt.setObject(parameterIndex, x, targetSqlType, scale); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {
/* 163 */     checkOpen(); try { this._stmt.setObject(parameterIndex, x, targetSqlType); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setObject(int parameterIndex, Object x) throws SQLException {
/* 166 */     checkOpen(); try { this._stmt.setObject(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public boolean execute() throws SQLException {
/* 169 */     checkOpen(); try { return this._stmt.execute(); } catch (SQLException e) { handleException(e); return false; }
/*     */   
/*     */   } public void addBatch() throws SQLException {
/* 172 */     checkOpen(); try { this._stmt.addBatch(); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
/* 175 */     checkOpen(); try { this._stmt.setCharacterStream(parameterIndex, reader, length); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setRef(int i, Ref x) throws SQLException {
/* 178 */     checkOpen(); try { this._stmt.setRef(i, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setBlob(int i, Blob x) throws SQLException {
/* 181 */     checkOpen(); try { this._stmt.setBlob(i, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setClob(int i, Clob x) throws SQLException {
/* 184 */     checkOpen(); try { this._stmt.setClob(i, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setArray(int i, Array x) throws SQLException {
/* 187 */     checkOpen(); try { this._stmt.setArray(i, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public ResultSetMetaData getMetaData() throws SQLException {
/* 190 */     checkOpen(); try { return this._stmt.getMetaData(); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   } public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
/* 193 */     checkOpen(); try { this._stmt.setDate(parameterIndex, x, cal); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {
/* 196 */     checkOpen(); try { this._stmt.setTime(parameterIndex, x, cal); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {
/* 199 */     checkOpen(); try { this._stmt.setTimestamp(parameterIndex, x, cal); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setNull(int paramIndex, int sqlType, String typeName) throws SQLException {
/* 202 */     checkOpen(); try { this._stmt.setNull(paramIndex, sqlType, typeName); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 211 */     return this._stmt.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setURL(int parameterIndex, URL x) throws SQLException {
/* 220 */     checkOpen(); try { this._stmt.setURL(parameterIndex, x); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public ParameterMetaData getParameterMetaData() throws SQLException {
/* 223 */     checkOpen(); try { return this._stmt.getParameterMetaData(); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\DelegatingPreparedStatement.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */