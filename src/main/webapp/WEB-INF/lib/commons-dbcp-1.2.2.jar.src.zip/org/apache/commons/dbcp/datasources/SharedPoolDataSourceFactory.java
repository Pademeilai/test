/*    */ package org.apache.commons.dbcp.datasources;
/*    */ 
/*    */ import javax.naming.RefAddr;
/*    */ import javax.naming.Reference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SharedPoolDataSourceFactory
/*    */   extends InstanceKeyObjectFactory
/*    */ {
/* 30 */   private static final String SHARED_POOL_CLASSNAME = SharedPoolDataSource.class.getName();
/*    */ 
/*    */   
/*    */   protected boolean isCorrectClass(String className) {
/* 34 */     return SHARED_POOL_CLASSNAME.equals(className);
/*    */   }
/*    */   
/*    */   protected InstanceKeyDataSource getNewInstance(Reference ref) {
/* 38 */     SharedPoolDataSource spds = new SharedPoolDataSource();
/* 39 */     RefAddr ra = ref.get("maxActive");
/* 40 */     if (ra != null && ra.getContent() != null) {
/* 41 */       spds.setMaxActive(Integer.parseInt(ra.getContent().toString()));
/*    */     }
/*    */ 
/*    */     
/* 45 */     ra = ref.get("maxIdle");
/* 46 */     if (ra != null && ra.getContent() != null) {
/* 47 */       spds.setMaxIdle(Integer.parseInt(ra.getContent().toString()));
/*    */     }
/*    */ 
/*    */     
/* 51 */     ra = ref.get("maxWait");
/* 52 */     if (ra != null && ra.getContent() != null) {
/* 53 */       spds.setMaxWait(Integer.parseInt(ra.getContent().toString()));
/*    */     }
/*    */ 
/*    */     
/* 57 */     return spds;
/*    */   }
/*    */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\SharedPoolDataSourceFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */