/*    */ package org.apache.commons.dbcp;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSourceConnectionFactory
/*    */   implements ConnectionFactory
/*    */ {
/*    */   protected String _uname;
/*    */   protected String _passwd;
/*    */   protected DataSource _source;
/*    */   
/*    */   public DataSourceConnectionFactory(DataSource source) {
/* 32 */     this(source, null, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataSourceConnectionFactory(DataSource source, String uname, String passwd) {
/* 49 */     this._uname = null;
/* 50 */     this._passwd = null;
/* 51 */     this._source = null;
/*    */     this._source = source;
/*    */     this._uname = uname;
/*    */     this._passwd = passwd;
/*    */   }
/*    */   
/*    */   public Connection createConnection() throws SQLException {
/*    */     if (null == this._uname && null == this._passwd)
/*    */       return this._source.getConnection(); 
/*    */     return this._source.getConnection(this._uname, this._passwd);
/*    */   }
/*    */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\DataSourceConnectionFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */