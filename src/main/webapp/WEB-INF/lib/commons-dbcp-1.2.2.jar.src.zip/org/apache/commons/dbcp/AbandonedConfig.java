/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbandonedConfig
/*     */ {
/*     */   private boolean removeAbandoned = false;
/*     */   
/*     */   public boolean getRemoveAbandoned() {
/*  48 */     return this.removeAbandoned;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoveAbandoned(boolean removeAbandoned) {
/*  65 */     this.removeAbandoned = removeAbandoned;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private int removeAbandonedTimeout = 300;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRemoveAbandonedTimeout() {
/*  81 */     return this.removeAbandonedTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoveAbandonedTimeout(int removeAbandonedTimeout) {
/*  92 */     this.removeAbandonedTimeout = removeAbandonedTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean logAbandoned = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getLogAbandoned() {
/* 115 */     return this.logAbandoned;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogAbandoned(boolean logAbandoned) {
/* 130 */     this.logAbandoned = logAbandoned;
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\AbandonedConfig.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */