/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.pool.ObjectPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoolableConnection
/*     */   extends DelegatingConnection
/*     */ {
/*  37 */   protected ObjectPool _pool = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolableConnection(Connection conn, ObjectPool pool) {
/*  45 */     super(conn);
/*  46 */     this._pool = pool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolableConnection(Connection conn, ObjectPool pool, AbandonedConfig config) {
/*  58 */     super(conn, config);
/*  59 */     this._pool = pool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void close() throws SQLException {
/*  67 */     boolean isClosed = false;
/*     */     try {
/*  69 */       isClosed = isClosed();
/*  70 */     } catch (SQLException e) {
/*     */       try {
/*  72 */         this._pool.invalidateObject(this);
/*  73 */       } catch (Exception ie) {}
/*     */ 
/*     */       
/*  76 */       throw new SQLNestedException("Cannot close connection (isClosed check failed)", e);
/*     */     } 
/*  78 */     if (isClosed) {
/*     */       try {
/*  80 */         this._pool.invalidateObject(this);
/*  81 */       } catch (Exception ie) {}
/*     */ 
/*     */       
/*  84 */       throw new SQLException("Already closed.");
/*     */     } 
/*     */     try {
/*  87 */       this._pool.returnObject(this);
/*  88 */     } catch (SQLException e) {
/*  89 */       throw e;
/*  90 */     } catch (RuntimeException e) {
/*  91 */       throw e;
/*  92 */     } catch (Exception e) {
/*  93 */       throw new SQLNestedException("Cannot close connection (return to pool failed)", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reallyClose() throws SQLException {
/* 102 */     super.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\PoolableConnection.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */