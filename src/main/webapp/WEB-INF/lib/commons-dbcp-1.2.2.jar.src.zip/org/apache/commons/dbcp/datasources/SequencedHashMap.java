/*     */ package org.apache.commons.dbcp.datasources;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SequencedHashMap
/*     */   implements Map, Cloneable, Externalizable
/*     */ {
/*     */   private Entry sentinel;
/*     */   private HashMap entries;
/*     */   
/*     */   private static class Entry
/*     */     implements Map.Entry
/*     */   {
/*     */     private final Object key;
/*     */     private Object value;
/*  84 */     Entry next = null;
/*  85 */     Entry prev = null;
/*     */     
/*     */     public Entry(Object key, Object value) {
/*  88 */       this.key = key;
/*  89 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getKey() {
/*  94 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getValue() {
/*  99 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object setValue(Object value) {
/* 104 */       Object oldValue = this.value;
/* 105 */       this.value = value;
/* 106 */       return oldValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 111 */       return ((getKey() == null) ? 0 : getKey().hashCode()) ^ ((getValue() == null) ? 0 : getValue().hashCode());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 116 */       if (obj == null) return false; 
/* 117 */       if (obj == this) return true; 
/* 118 */       if (!(obj instanceof Map.Entry)) return false;
/*     */       
/* 120 */       Map.Entry other = (Map.Entry)obj;
/*     */ 
/*     */       
/* 123 */       if ((getKey() == null) ? (other.getKey() == null) : getKey().equals(other.getKey())) if ((getValue() == null) ? (other.getValue() == null) : getValue().equals(other.getValue()));  return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 131 */       return "[" + getKey() + "=" + getValue() + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Entry createSentinel() {
/* 141 */     Entry s = new Entry(null, null);
/* 142 */     s.prev = s;
/* 143 */     s.next = s;
/* 144 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   private transient long modCount = 0L; private static final int KEY = 0;
/*     */   private static final int VALUE = 1;
/*     */   private static final int ENTRY = 2;
/*     */   private static final int REMOVED_MASK = -2147483648;
/*     */   private static final long serialVersionUID = 3380552487888102930L;
/*     */   
/*     */   public SequencedHashMap() {
/* 170 */     this.sentinel = createSentinel();
/* 171 */     this.entries = new HashMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SequencedHashMap(int initialSize) {
/* 183 */     this.sentinel = createSentinel();
/* 184 */     this.entries = new HashMap(initialSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SequencedHashMap(int initialSize, float loadFactor) {
/* 198 */     this.sentinel = createSentinel();
/* 199 */     this.entries = new HashMap(initialSize, loadFactor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SequencedHashMap(Map m) {
/* 208 */     this();
/* 209 */     putAll(m);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeEntry(Entry entry) {
/* 217 */     entry.next.prev = entry.prev;
/* 218 */     entry.prev.next = entry.next;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void insertEntry(Entry entry) {
/* 226 */     entry.next = this.sentinel;
/* 227 */     entry.prev = this.sentinel.prev;
/* 228 */     this.sentinel.prev.next = entry;
/* 229 */     this.sentinel.prev = entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 239 */     return this.entries.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 248 */     return (this.sentinel.next == this.sentinel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 256 */     return this.entries.containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 271 */     if (value == null) {
/* 272 */       for (Entry pos = this.sentinel.next; pos != this.sentinel; pos = pos.next) {
/* 273 */         if (pos.getValue() == null) return true; 
/*     */       } 
/*     */     } else {
/* 276 */       for (Entry pos = this.sentinel.next; pos != this.sentinel; pos = pos.next) {
/* 277 */         if (value.equals(pos.getValue())) return true; 
/*     */       } 
/*     */     } 
/* 280 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object o) {
/* 288 */     Entry entry = (Entry)this.entries.get(o);
/* 289 */     if (entry == null) return null;
/*     */     
/* 291 */     return entry.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map.Entry getFirst() {
/* 308 */     return isEmpty() ? null : this.sentinel.next;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getFirstKey() {
/* 328 */     return this.sentinel.next.getKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getFirstValue() {
/* 348 */     return this.sentinel.next.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map.Entry getLast() {
/* 375 */     return isEmpty() ? null : this.sentinel.prev;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getLastKey() {
/* 395 */     return this.sentinel.prev.getKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getLastValue() {
/* 415 */     return this.sentinel.prev.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 422 */     this.modCount++;
/*     */     
/* 424 */     Object oldValue = null;
/*     */ 
/*     */     
/* 427 */     Entry e = (Entry)this.entries.get(key);
/*     */ 
/*     */     
/* 430 */     if (e != null) {
/*     */       
/* 432 */       removeEntry(e);
/*     */ 
/*     */       
/* 435 */       oldValue = e.setValue(value);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 444 */       e = new Entry(key, value);
/* 445 */       this.entries.put(key, e);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 450 */     insertEntry(e);
/*     */     
/* 452 */     return oldValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 459 */     Entry e = removeImpl(key);
/* 460 */     return (e == null) ? null : e.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Entry removeImpl(Object key) {
/* 468 */     Entry e = (Entry)this.entries.remove(key);
/* 469 */     if (e == null) return null; 
/* 470 */     this.modCount++;
/* 471 */     removeEntry(e);
/* 472 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map t) {
/* 486 */     Iterator iter = t.entrySet().iterator();
/* 487 */     while (iter.hasNext()) {
/* 488 */       Map.Entry entry = iter.next();
/* 489 */       put(entry.getKey(), entry.getValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 497 */     this.modCount++;
/*     */ 
/*     */     
/* 500 */     this.entries.clear();
/*     */ 
/*     */     
/* 503 */     this.sentinel.next = this.sentinel;
/* 504 */     this.sentinel.prev = this.sentinel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 511 */     if (obj == null) return false; 
/* 512 */     if (obj == this) return true;
/*     */     
/* 514 */     if (!(obj instanceof Map)) return false;
/*     */     
/* 516 */     return entrySet().equals(((Map)obj).entrySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 523 */     return entrySet().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 534 */     StringBuffer buf = new StringBuffer();
/* 535 */     buf.append('[');
/* 536 */     for (Entry pos = this.sentinel.next; pos != this.sentinel; pos = pos.next) {
/* 537 */       buf.append(pos.getKey());
/* 538 */       buf.append('=');
/* 539 */       buf.append(pos.getValue());
/* 540 */       if (pos.next != this.sentinel) {
/* 541 */         buf.append(',');
/*     */       }
/*     */     } 
/* 544 */     buf.append(']');
/*     */     
/* 546 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set keySet() {
/* 553 */     return new AbstractSet(this) { private final SequencedHashMap this$0;
/*     */         
/*     */         public Iterator iterator() {
/* 556 */           return new SequencedHashMap.OrderedIterator(this.this$0, 0);
/*     */         } public boolean remove(Object o) {
/* 558 */           SequencedHashMap.Entry e = this.this$0.removeImpl(o);
/* 559 */           return (e != null);
/*     */         }
/*     */ 
/*     */         
/*     */         public void clear() {
/* 564 */           this.this$0.clear();
/*     */         }
/*     */         public int size() {
/* 567 */           return this.this$0.size();
/*     */         }
/*     */         public boolean isEmpty() {
/* 570 */           return this.this$0.isEmpty();
/*     */         }
/*     */         public boolean contains(Object o) {
/* 573 */           return this.this$0.containsKey(o);
/*     */         } }
/*     */       ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection values() {
/* 583 */     return new AbstractCollection(this) { private final SequencedHashMap this$0;
/*     */         public Iterator iterator() {
/* 585 */           return new SequencedHashMap.OrderedIterator(this.this$0, 1);
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean remove(Object value) {
/* 590 */           if (value == null) {
/* 591 */             for (SequencedHashMap.Entry pos = this.this$0.sentinel.next; pos != this.this$0.sentinel; pos = pos.next) {
/* 592 */               if (pos.getValue() == null) {
/* 593 */                 this.this$0.removeImpl(pos.getKey());
/* 594 */                 return true;
/*     */               } 
/*     */             } 
/*     */           } else {
/* 598 */             for (SequencedHashMap.Entry pos = this.this$0.sentinel.next; pos != this.this$0.sentinel; pos = pos.next) {
/* 599 */               if (value.equals(pos.getValue())) {
/* 600 */                 this.this$0.removeImpl(pos.getKey());
/* 601 */                 return true;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 606 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public void clear() {
/* 611 */           this.this$0.clear();
/*     */         }
/*     */         public int size() {
/* 614 */           return this.this$0.size();
/*     */         }
/*     */         public boolean isEmpty() {
/* 617 */           return this.this$0.isEmpty();
/*     */         }
/*     */         public boolean contains(Object o) {
/* 620 */           return this.this$0.containsValue(o);
/*     */         } }
/*     */       ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set entrySet() {
/* 629 */     return new AbstractSet(this) { private final SequencedHashMap this$0;
/*     */         
/*     */         private SequencedHashMap.Entry findEntry(Object o) {
/* 632 */           if (o == null) return null; 
/* 633 */           if (!(o instanceof Map.Entry)) return null;
/*     */           
/* 635 */           Map.Entry e = (Map.Entry)o;
/* 636 */           SequencedHashMap.Entry entry = (SequencedHashMap.Entry)this.this$0.entries.get(e.getKey());
/* 637 */           if (entry != null && entry.equals(e)) return entry; 
/* 638 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public Iterator iterator() {
/* 643 */           return new SequencedHashMap.OrderedIterator(this.this$0, 2);
/*     */         }
/*     */         public boolean remove(Object o) {
/* 646 */           SequencedHashMap.Entry e = findEntry(o);
/* 647 */           if (e == null) return false;
/*     */           
/* 649 */           return (this.this$0.removeImpl(e.getKey()) != null);
/*     */         }
/*     */ 
/*     */         
/*     */         public void clear() {
/* 654 */           this.this$0.clear();
/*     */         }
/*     */         public int size() {
/* 657 */           return this.this$0.size();
/*     */         }
/*     */         public boolean isEmpty() {
/* 660 */           return this.this$0.isEmpty();
/*     */         }
/*     */         public boolean contains(Object o) {
/* 663 */           return (findEntry(o) != null);
/*     */         } }
/*     */       ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class OrderedIterator
/*     */     implements Iterator
/*     */   {
/*     */     private int returnType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private SequencedHashMap.Entry pos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private transient long expectedModCount;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final SequencedHashMap this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public OrderedIterator(SequencedHashMap this$0, int returnType) {
/* 705 */       this.this$0 = this$0;
/*     */ 
/*     */ 
/*     */       
/*     */       this.pos = this.this$0.sentinel;
/*     */ 
/*     */ 
/*     */       
/*     */       this.expectedModCount = this.this$0.modCount;
/*     */ 
/*     */       
/* 716 */       this.returnType = returnType | Integer.MIN_VALUE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 727 */       return (this.pos.next != this.this$0.sentinel);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object next() {
/* 742 */       if (this.this$0.modCount != this.expectedModCount) {
/* 743 */         throw new ConcurrentModificationException();
/*     */       }
/* 745 */       if (this.pos.next == this.this$0.sentinel) {
/* 746 */         throw new NoSuchElementException();
/*     */       }
/*     */ 
/*     */       
/* 750 */       this.returnType &= Integer.MAX_VALUE;
/*     */       
/* 752 */       this.pos = this.pos.next;
/* 753 */       switch (this.returnType) {
/*     */         case 0:
/* 755 */           return this.pos.getKey();
/*     */         case 1:
/* 757 */           return this.pos.getValue();
/*     */         case 2:
/* 759 */           return this.pos;
/*     */       } 
/*     */       
/* 762 */       throw new Error("bad iterator type: " + this.returnType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {
/* 779 */       if ((this.returnType & Integer.MIN_VALUE) != 0) {
/* 780 */         throw new IllegalStateException("remove() must follow next()");
/*     */       }
/* 782 */       if (this.this$0.modCount != this.expectedModCount) {
/* 783 */         throw new ConcurrentModificationException();
/*     */       }
/*     */       
/* 786 */       this.this$0.removeImpl(this.pos.getKey());
/*     */ 
/*     */       
/* 789 */       this.expectedModCount++;
/*     */ 
/*     */       
/* 792 */       this.returnType |= Integer.MIN_VALUE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/* 814 */     SequencedHashMap map = (SequencedHashMap)super.clone();
/*     */ 
/*     */     
/* 817 */     map.sentinel = createSentinel();
/*     */ 
/*     */ 
/*     */     
/* 821 */     map.entries = new HashMap();
/*     */ 
/*     */     
/* 824 */     map.putAll(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 834 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map.Entry getEntry(int index) {
/* 844 */     Entry pos = this.sentinel;
/*     */     
/* 846 */     if (index < 0) {
/* 847 */       throw new ArrayIndexOutOfBoundsException(index + " < 0");
/*     */     }
/*     */ 
/*     */     
/* 851 */     int i = -1;
/* 852 */     while (i < index - 1 && pos.next != this.sentinel) {
/* 853 */       i++;
/* 854 */       pos = pos.next;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 859 */     if (pos.next == this.sentinel) {
/* 860 */       throw new ArrayIndexOutOfBoundsException(index + " >= " + (i + 1));
/*     */     }
/*     */     
/* 863 */     return pos.next;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(int index) {
/* 874 */     return getEntry(index).getKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(int index) {
/* 885 */     return getEntry(index).getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOf(Object key) {
/* 893 */     Entry e = (Entry)this.entries.get(key);
/* 894 */     int pos = 0;
/* 895 */     while (e.prev != this.sentinel) {
/* 896 */       pos++;
/* 897 */       e = e.prev;
/*     */     } 
/* 899 */     return pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator iterator() {
/* 907 */     return keySet().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object key) {
/* 916 */     return indexOf(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List sequence() {
/* 935 */     List l = new ArrayList(size());
/* 936 */     Iterator iter = keySet().iterator();
/* 937 */     while (iter.hasNext()) {
/* 938 */       l.add(iter.next());
/*     */     }
/*     */     
/* 941 */     return Collections.unmodifiableList(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(int index) {
/* 956 */     return remove(get(index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 971 */     int size = in.readInt();
/* 972 */     for (int i = 0; i < size; i++) {
/* 973 */       Object key = in.readObject();
/* 974 */       Object value = in.readObject();
/* 975 */       put(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 986 */     out.writeInt(size());
/* 987 */     for (Entry pos = this.sentinel.next; pos != this.sentinel; pos = pos.next) {
/* 988 */       out.writeObject(pos.getKey());
/* 989 */       out.writeObject(pos.getValue());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\SequencedHashMap.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */