/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingConnection
/*     */   extends AbandonedTrace
/*     */   implements Connection
/*     */ {
/*  54 */   protected Connection _conn = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _closed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingConnection(Connection c) {
/*  66 */     this._conn = c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingConnection(Connection c, AbandonedConfig config) {
/*  79 */     super(config);
/*  80 */     this._conn = c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     String s = null;
/*     */     
/*  92 */     Connection c = getInnermostDelegate();
/*  93 */     if (c != null) {
/*     */       try {
/*  95 */         if (c.isClosed()) {
/*  96 */           s = "connection is closed";
/*     */         } else {
/*     */           
/*  99 */           DatabaseMetaData meta = c.getMetaData();
/* 100 */           if (meta != null) {
/* 101 */             StringBuffer sb = new StringBuffer();
/* 102 */             sb.append(meta.getURL());
/* 103 */             sb.append(", UserName=");
/* 104 */             sb.append(meta.getUserName());
/* 105 */             sb.append(", ");
/* 106 */             sb.append(meta.getDriverName());
/* 107 */             s = sb.toString();
/*     */           }
/*     */         
/*     */         } 
/* 111 */       } catch (SQLException ex) {
/* 112 */         s = null;
/*     */       } 
/*     */     }
/*     */     
/* 116 */     if (s == null) {
/* 117 */       s = super.toString();
/*     */     }
/*     */     
/* 120 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getDelegate() {
/* 128 */     return this._conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean innermostDelegateEquals(Connection c) {
/* 139 */     Connection innerCon = getInnermostDelegate();
/* 140 */     if (innerCon == null) {
/* 141 */       return (c == null);
/*     */     }
/* 143 */     return innerCon.equals(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 148 */     if (obj == null) {
/* 149 */       return false;
/*     */     }
/* 151 */     if (obj == this) {
/* 152 */       return true;
/*     */     }
/* 154 */     Connection delegate = getInnermostDelegate();
/* 155 */     if (delegate == null) {
/* 156 */       return false;
/*     */     }
/* 158 */     if (obj instanceof DelegatingConnection) {
/* 159 */       DelegatingConnection c = (DelegatingConnection)obj;
/* 160 */       return c.innermostDelegateEquals(delegate);
/*     */     } 
/*     */     
/* 163 */     return delegate.equals(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 168 */     Object obj = getInnermostDelegate();
/* 169 */     if (obj == null) {
/* 170 */       return 0;
/*     */     }
/* 172 */     return obj.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getInnermostDelegate() {
/* 192 */     Connection c = this._conn;
/* 193 */     while (c != null && c instanceof DelegatingConnection) {
/* 194 */       c = ((DelegatingConnection)c).getDelegate();
/* 195 */       if (this == c) {
/* 196 */         return null;
/*     */       }
/*     */     } 
/* 199 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDelegate(Connection c) {
/* 204 */     this._conn = c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/* 213 */     passivate();
/* 214 */     this._conn.close();
/*     */   }
/*     */   
/*     */   protected void handleException(SQLException e) throws SQLException {
/* 218 */     throw e;
/*     */   }
/*     */   
/*     */   public Statement createStatement() throws SQLException {
/* 222 */     checkOpen();
/*     */     try {
/* 224 */       return new DelegatingStatement(this, this._conn.createStatement());
/*     */     }
/* 226 */     catch (SQLException e) {
/* 227 */       handleException(e);
/* 228 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/* 234 */     checkOpen();
/*     */     try {
/* 236 */       return new DelegatingStatement(this, this._conn.createStatement(resultSetType, resultSetConcurrency));
/*     */     
/*     */     }
/* 239 */     catch (SQLException e) {
/* 240 */       handleException(e);
/* 241 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql) throws SQLException {
/* 246 */     checkOpen();
/*     */     try {
/* 248 */       return new DelegatingPreparedStatement(this, this._conn.prepareStatement(sql));
/*     */     
/*     */     }
/* 251 */     catch (SQLException e) {
/* 252 */       handleException(e);
/* 253 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 260 */     checkOpen();
/*     */     try {
/* 262 */       return new DelegatingPreparedStatement(this, this._conn.prepareStatement(sql, resultSetType, resultSetConcurrency));
/*     */ 
/*     */     
/*     */     }
/* 266 */     catch (SQLException e) {
/* 267 */       handleException(e);
/* 268 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public CallableStatement prepareCall(String sql) throws SQLException {
/* 273 */     checkOpen();
/*     */     try {
/* 275 */       return new DelegatingCallableStatement(this, this._conn.prepareCall(sql));
/*     */     }
/* 277 */     catch (SQLException e) {
/* 278 */       handleException(e);
/* 279 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 286 */     checkOpen();
/*     */     try {
/* 288 */       return new DelegatingCallableStatement(this, this._conn.prepareCall(sql, resultSetType, resultSetConcurrency));
/*     */     
/*     */     }
/* 291 */     catch (SQLException e) {
/* 292 */       handleException(e);
/* 293 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clearWarnings() throws SQLException {
/* 298 */     checkOpen(); try { this._conn.clearWarnings(); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void commit() throws SQLException {
/* 301 */     checkOpen(); try { this._conn.commit(); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public boolean getAutoCommit() throws SQLException {
/* 304 */     checkOpen(); try { return this._conn.getAutoCommit(); } catch (SQLException e) { handleException(e); return false; }
/*     */   
/*     */   } public String getCatalog() throws SQLException {
/* 307 */     checkOpen(); try { return this._conn.getCatalog(); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   } public DatabaseMetaData getMetaData() throws SQLException {
/* 310 */     checkOpen(); try { return this._conn.getMetaData(); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   } public int getTransactionIsolation() throws SQLException {
/* 313 */     checkOpen(); try { return this._conn.getTransactionIsolation(); } catch (SQLException e) { handleException(e); return -1; }
/*     */   
/*     */   } public Map getTypeMap() throws SQLException {
/* 316 */     checkOpen(); try { return this._conn.getTypeMap(); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   } public SQLWarning getWarnings() throws SQLException {
/* 319 */     checkOpen(); try { return this._conn.getWarnings(); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   } public boolean isReadOnly() throws SQLException {
/* 322 */     checkOpen(); try { return this._conn.isReadOnly(); } catch (SQLException e) { handleException(e); return false; }
/*     */   
/*     */   } public String nativeSQL(String sql) throws SQLException {
/* 325 */     checkOpen(); try { return this._conn.nativeSQL(sql); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   } public void rollback() throws SQLException {
/* 328 */     checkOpen(); try { this._conn.rollback(); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setAutoCommit(boolean autoCommit) throws SQLException {
/* 331 */     checkOpen(); try { this._conn.setAutoCommit(autoCommit); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setCatalog(String catalog) throws SQLException {
/* 334 */     checkOpen(); try { this._conn.setCatalog(catalog); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setReadOnly(boolean readOnly) throws SQLException {
/* 337 */     checkOpen(); try { this._conn.setReadOnly(readOnly); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setTransactionIsolation(int level) throws SQLException {
/* 340 */     checkOpen(); try { this._conn.setTransactionIsolation(level); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setTypeMap(Map map) throws SQLException {
/* 343 */     checkOpen(); try { this._conn.setTypeMap(map); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public boolean isClosed() throws SQLException {
/* 346 */     if (this._closed || this._conn.isClosed()) {
/* 347 */       return true;
/*     */     }
/* 349 */     return false;
/*     */   }
/*     */   
/*     */   protected void checkOpen() throws SQLException {
/* 353 */     if (this._closed) {
/* 354 */       throw new SQLException("Connection " + this._conn + " is closed.");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void activate() {
/* 360 */     this._closed = false;
/* 361 */     setLastUsed();
/* 362 */     if (this._conn instanceof DelegatingConnection) {
/* 363 */       ((DelegatingConnection)this._conn).activate();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void passivate() throws SQLException {
/*     */     try {
/* 371 */       List statements = getTrace();
/* 372 */       if (statements != null) {
/* 373 */         Statement[] set = new Statement[statements.size()];
/* 374 */         statements.toArray((Object[])set);
/* 375 */         for (int i = 0; i < set.length; i++) {
/* 376 */           set[i].close();
/*     */         }
/* 378 */         clearTrace();
/*     */       } 
/* 380 */       setLastUsed(0L);
/* 381 */       if (this._conn instanceof DelegatingConnection) {
/* 382 */         ((DelegatingConnection)this._conn).passivate();
/*     */       }
/*     */     } finally {
/*     */       
/* 386 */       this._closed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHoldability() throws SQLException {
/* 396 */     checkOpen(); try { return this._conn.getHoldability(); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public void setHoldability(int holdability) throws SQLException {
/* 399 */     checkOpen(); try { this._conn.setHoldability(holdability); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public Savepoint setSavepoint() throws SQLException {
/* 402 */     checkOpen(); try { return this._conn.setSavepoint(); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   } public Savepoint setSavepoint(String name) throws SQLException {
/* 405 */     checkOpen(); try { return this._conn.setSavepoint(name); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   } public void rollback(Savepoint savepoint) throws SQLException {
/* 408 */     checkOpen(); try { this._conn.rollback(savepoint); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void releaseSavepoint(Savepoint savepoint) throws SQLException {
/* 411 */     checkOpen(); try { this._conn.releaseSavepoint(savepoint); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   }
/*     */   
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 416 */     checkOpen();
/*     */     try {
/* 418 */       return new DelegatingStatement(this, this._conn.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability));
/*     */     
/*     */     }
/* 421 */     catch (SQLException e) {
/* 422 */       handleException(e);
/* 423 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 430 */     checkOpen();
/*     */     try {
/* 432 */       return new DelegatingPreparedStatement(this, this._conn.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
/*     */     
/*     */     }
/* 435 */     catch (SQLException e) {
/* 436 */       handleException(e);
/* 437 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 444 */     checkOpen();
/*     */     try {
/* 446 */       return new DelegatingCallableStatement(this, this._conn.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
/*     */     
/*     */     }
/* 449 */     catch (SQLException e) {
/* 450 */       handleException(e);
/* 451 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException {
/* 456 */     checkOpen();
/*     */     try {
/* 458 */       return new DelegatingPreparedStatement(this, this._conn.prepareStatement(sql, autoGeneratedKeys));
/*     */     
/*     */     }
/* 461 */     catch (SQLException e) {
/* 462 */       handleException(e);
/* 463 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException {
/* 468 */     checkOpen();
/*     */     try {
/* 470 */       return new DelegatingPreparedStatement(this, this._conn.prepareStatement(sql, columnIndexes));
/*     */     
/*     */     }
/* 473 */     catch (SQLException e) {
/* 474 */       handleException(e);
/* 475 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException {
/* 480 */     checkOpen();
/*     */     try {
/* 482 */       return new DelegatingPreparedStatement(this, this._conn.prepareStatement(sql, columnNames));
/*     */     
/*     */     }
/* 485 */     catch (SQLException e) {
/* 486 */       handleException(e);
/* 487 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\DelegatingConnection.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */