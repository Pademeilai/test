/*    */ package org.apache.commons.dbcp.datasources;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UserPassKey
/*    */   implements Serializable
/*    */ {
/*    */   private String password;
/*    */   private String username;
/*    */   
/*    */   UserPassKey(String username, String password) {
/* 31 */     this.username = username;
/* 32 */     this.password = password;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPassword() {
/* 40 */     return this.password;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUsername() {
/* 48 */     return this.username;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 57 */     if (obj == null) {
/* 58 */       return false;
/*    */     }
/*    */     
/* 61 */     if (obj == this) {
/* 62 */       return true;
/*    */     }
/*    */     
/* 65 */     if (!(obj instanceof UserPassKey)) {
/* 66 */       return false;
/*    */     }
/*    */     
/* 69 */     UserPassKey key = (UserPassKey)obj;
/*    */     
/* 71 */     boolean usersEqual = (this.username == null) ? ((key.username == null)) : this.username.equals(key.username);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 76 */     boolean passwordsEqual = (this.password == null) ? ((key.password == null)) : this.password.equals(key.password);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 81 */     return (usersEqual && passwordsEqual);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 85 */     return (this.username != null) ? this.username.hashCode() : 0;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 89 */     StringBuffer sb = new StringBuffer(50);
/* 90 */     sb.append("UserPassKey(");
/* 91 */     sb.append(this.username).append(", ").append(this.password).append(')');
/* 92 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\UserPassKey.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */