/*     */ package org.apache.commons.dbcp.cpdsadapter;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ import javax.sql.ConnectionEvent;
/*     */ import javax.sql.ConnectionEventListener;
/*     */ import javax.sql.PooledConnection;
/*     */ import org.apache.commons.dbcp.DelegatingConnection;
/*     */ import org.apache.commons.dbcp.DelegatingPreparedStatement;
/*     */ import org.apache.commons.dbcp.SQLNestedException;
/*     */ import org.apache.commons.pool.KeyedObjectPool;
/*     */ import org.apache.commons.pool.KeyedPoolableObjectFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PooledConnectionImpl
/*     */   implements PooledConnection, KeyedPoolableObjectFactory
/*     */ {
/*     */   private static final String CLOSED = "Attempted to use PooledConnection after closed() was called.";
/*  51 */   private Connection connection = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private DelegatingConnection delegatingConnection = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private Connection logicalConnection = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector eventListeners;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isClosed;
/*     */ 
/*     */ 
/*     */   
/*  74 */   protected KeyedObjectPool pstmtPool = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PooledConnectionImpl(Connection connection, KeyedObjectPool pool) {
/*  81 */     this.connection = connection;
/*  82 */     if (connection instanceof DelegatingConnection) {
/*  83 */       this.delegatingConnection = (DelegatingConnection)connection;
/*     */     } else {
/*  85 */       this.delegatingConnection = new DelegatingConnection(connection);
/*     */     } 
/*  87 */     this.eventListeners = new Vector();
/*  88 */     this.isClosed = false;
/*  89 */     if (pool != null) {
/*  90 */       this.pstmtPool = pool;
/*  91 */       this.pstmtPool.setFactory(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addConnectionEventListener(ConnectionEventListener listener) {
/*  99 */     if (!this.eventListeners.contains(listener)) {
/* 100 */       this.eventListeners.add(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/* 112 */     assertOpen();
/* 113 */     this.isClosed = true;
/*     */     try {
/* 115 */       if (this.pstmtPool != null) {
/*     */         try {
/* 117 */           this.pstmtPool.close();
/*     */         } finally {
/* 119 */           this.pstmtPool = null;
/*     */         } 
/*     */       }
/* 122 */     } catch (RuntimeException e) {
/* 123 */       throw e;
/* 124 */     } catch (Exception e) {
/* 125 */       throw new SQLNestedException("Cannot close connection (return to pool failed)", e);
/*     */     } finally {
/*     */       try {
/* 128 */         this.connection.close();
/*     */       } finally {
/* 130 */         this.connection = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void assertOpen() throws SQLException {
/* 139 */     if (this.isClosed) {
/* 140 */       throw new SQLException("Attempted to use PooledConnection after closed() was called.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 150 */     assertOpen();
/*     */     
/* 152 */     if (this.logicalConnection != null && !this.logicalConnection.isClosed())
/*     */     {
/*     */       
/* 155 */       throw new SQLException("PooledConnection was reused, withoutits previous Connection being closed.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 160 */     this.logicalConnection = new ConnectionImpl(this, this.connection);
/* 161 */     return this.logicalConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeConnectionEventListener(ConnectionEventListener listener) {
/* 169 */     this.eventListeners.remove(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/*     */     try {
/* 180 */       this.connection.close();
/* 181 */     } catch (Exception ignored) {}
/*     */ 
/*     */ 
/*     */     
/* 185 */     if (this.logicalConnection != null && !this.logicalConnection.isClosed()) {
/* 186 */       throw new SQLException("PooledConnection was gc'ed, withoutits last Connection being closed.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void notifyListeners() {
/* 195 */     ConnectionEvent event = new ConnectionEvent(this);
/* 196 */     Iterator i = this.eventListeners.iterator();
/* 197 */     while (i.hasNext()) {
/* 198 */       ((ConnectionEventListener)i.next()).connectionClosed(event);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PreparedStatement prepareStatement(String sql) throws SQLException {
/* 210 */     if (this.pstmtPool == null) {
/* 211 */       return this.connection.prepareStatement(sql);
/*     */     }
/*     */     try {
/* 214 */       return (PreparedStatement)this.pstmtPool.borrowObject(createKey(sql));
/*     */     }
/* 216 */     catch (RuntimeException e) {
/* 217 */       throw e;
/* 218 */     } catch (Exception e) {
/* 219 */       throw new SQLNestedException("Borrow prepareStatement from pool failed", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 231 */     if (this.pstmtPool == null) {
/* 232 */       return this.connection.prepareStatement(sql, resultSetType, resultSetConcurrency);
/*     */     }
/*     */     try {
/* 235 */       return (PreparedStatement)this.pstmtPool.borrowObject(createKey(sql, resultSetType, resultSetConcurrency));
/*     */     }
/* 237 */     catch (RuntimeException e) {
/* 238 */       throw e;
/* 239 */     } catch (Exception e) {
/* 240 */       throw new SQLNestedException("Borrow prepareStatement from pool failed", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object createKey(String sql, int resultSetType, int resultSetConcurrency) {
/* 250 */     return new PStmtKey(this, normalizeSQL(sql), resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object createKey(String sql) {
/* 258 */     return new PStmtKey(this, normalizeSQL(sql));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String normalizeSQL(String sql) {
/* 266 */     return sql.trim();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object makeObject(Object obj) throws Exception {
/* 275 */     if (null == obj || !(obj instanceof PStmtKey)) {
/* 276 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 279 */     PStmtKey key = (PStmtKey)obj;
/* 280 */     if (null == key._resultSetType && null == key._resultSetConcurrency)
/*     */     {
/* 282 */       return new PoolablePreparedStatementStub(this.connection.prepareStatement(key._sql), key, this.pstmtPool, (Connection)this.delegatingConnection);
/*     */     }
/*     */ 
/*     */     
/* 286 */     return new PoolablePreparedStatementStub(this.connection.prepareStatement(key._sql, key._resultSetType.intValue(), key._resultSetConcurrency.intValue()), key, this.pstmtPool, (Connection)this.delegatingConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroyObject(Object key, Object obj) throws Exception {
/* 303 */     if (obj instanceof DelegatingPreparedStatement) {
/* 304 */       ((DelegatingPreparedStatement)obj).getInnermostDelegate().close();
/*     */     } else {
/* 306 */       ((PreparedStatement)obj).close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean validateObject(Object key, Object obj) {
/* 318 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void activateObject(Object key, Object obj) throws Exception {
/* 328 */     ((PoolablePreparedStatementStub)obj).activate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void passivateObject(Object key, Object obj) throws Exception {
/* 338 */     ((PreparedStatement)obj).clearParameters();
/* 339 */     ((PoolablePreparedStatementStub)obj).passivate();
/*     */   }
/*     */   
/*     */   class PStmtKey
/*     */   {
/*     */     protected String _sql;
/*     */     protected Integer _resultSetType;
/*     */     protected Integer _resultSetConcurrency;
/*     */     private final PooledConnectionImpl this$0;
/*     */     
/*     */     PStmtKey(PooledConnectionImpl this$0, String sql) {
/* 350 */       this.this$0 = this$0; this._sql = null; this._resultSetType = null; this._resultSetConcurrency = null;
/* 351 */       this._sql = sql;
/*     */     }
/*     */     PStmtKey(PooledConnectionImpl this$0, String sql, int resultSetType, int resultSetConcurrency) {
/* 354 */       this.this$0 = this$0; this._sql = null; this._resultSetType = null; this._resultSetConcurrency = null;
/* 355 */       this._sql = sql;
/* 356 */       this._resultSetType = new Integer(resultSetType);
/* 357 */       this._resultSetConcurrency = new Integer(resultSetConcurrency);
/*     */     }
/*     */     
/*     */     public boolean equals(Object that) {
/*     */       try {
/* 362 */         PStmtKey key = (PStmtKey)that;
/* 363 */         return (((null == this._sql && null == key._sql) || this._sql.equals(key._sql)) && ((null == this._resultSetType && null == key._resultSetType) || this._resultSetType.equals(key._resultSetType)) && ((null == this._resultSetConcurrency && null == key._resultSetConcurrency) || this._resultSetConcurrency.equals(key._resultSetConcurrency)));
/*     */ 
/*     */       
/*     */       }
/* 367 */       catch (ClassCastException e) {
/* 368 */         return false;
/* 369 */       } catch (NullPointerException e) {
/* 370 */         return false;
/*     */       } 
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 375 */       return (null == this._sql) ? 0 : this._sql.hashCode();
/*     */     }
/*     */     
/*     */     public String toString() {
/* 379 */       StringBuffer buf = new StringBuffer();
/* 380 */       buf.append("PStmtKey: sql=");
/* 381 */       buf.append(this._sql);
/* 382 */       buf.append(", resultSetType=");
/* 383 */       buf.append(this._resultSetType);
/* 384 */       buf.append(", resultSetConcurrency=");
/* 385 */       buf.append(this._resultSetConcurrency);
/* 386 */       return buf.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\cpdsadapter\PooledConnectionImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */