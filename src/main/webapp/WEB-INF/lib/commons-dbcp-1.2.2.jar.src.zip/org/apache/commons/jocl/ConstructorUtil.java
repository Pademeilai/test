/*    */ package org.apache.commons.jocl;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstructorUtil
/*    */ {
/*    */   public static Constructor getConstructor(Class type, Class[] argTypes) {
/* 41 */     if (null == type || null == argTypes) {
/* 42 */       throw new NullPointerException();
/*    */     }
/* 44 */     Constructor ctor = null;
/*    */     try {
/* 46 */       ctor = type.getConstructor(argTypes);
/* 47 */     } catch (Exception e) {
/* 48 */       ctor = null;
/*    */     } 
/* 50 */     if (null == ctor) {
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 55 */       Constructor[] ctors = (Constructor[])type.getConstructors();
/* 56 */       for (int i = 0; i < ctors.length; i++) {
/* 57 */         Class[] paramtypes = ctors[i].getParameterTypes();
/* 58 */         if (paramtypes.length == argTypes.length) {
/* 59 */           boolean canuse = true;
/* 60 */           for (int j = 0; j < paramtypes.length; ) {
/* 61 */             if (paramtypes[j].isAssignableFrom(argTypes[j])) {
/*    */               j++; continue;
/*    */             } 
/* 64 */             canuse = false;
/*    */           } 
/*    */ 
/*    */           
/* 68 */           if (canuse == true) {
/* 69 */             ctor = ctors[i];
/*    */             break;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/* 75 */     return ctor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Object invokeConstructor(Class type, Class[] argTypes, Object[] argValues) throws InstantiationException, IllegalAccessException, InvocationTargetException {
/* 94 */     return getConstructor(type, argTypes).newInstance(argValues);
/*    */   }
/*    */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\jocl\ConstructorUtil.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */