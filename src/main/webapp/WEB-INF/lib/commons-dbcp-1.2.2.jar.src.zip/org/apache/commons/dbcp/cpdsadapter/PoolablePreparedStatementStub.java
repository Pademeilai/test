/*    */ package org.apache.commons.dbcp.cpdsadapter;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import org.apache.commons.dbcp.PoolablePreparedStatement;
/*    */ import org.apache.commons.pool.KeyedObjectPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PoolablePreparedStatementStub
/*    */   extends PoolablePreparedStatement
/*    */ {
/*    */   public PoolablePreparedStatementStub(PreparedStatement stmt, Object key, KeyedObjectPool pool, Connection conn) {
/* 45 */     super(stmt, key, pool, conn);
/*    */   }
/*    */   
/*    */   protected void activate() throws SQLException {
/* 49 */     super.activate();
/*    */   }
/*    */   
/*    */   protected void passivate() throws SQLException {
/* 53 */     super.passivate();
/*    */   }
/*    */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\cpdsadapter\PoolablePreparedStatementStub.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */