/*     */ package org.apache.commons.dbcp.datasources;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.sql.ConnectionPoolDataSource;
/*     */ import org.apache.commons.dbcp.SQLNestedException;
/*     */ import org.apache.commons.pool.ObjectPool;
/*     */ import org.apache.commons.pool.impl.GenericObjectPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PerUserPoolDataSource
/*     */   extends InstanceKeyDataSource
/*     */ {
/*  54 */   private static final Map poolKeys = new HashMap();
/*     */   
/*  56 */   private int defaultMaxActive = 8;
/*  57 */   private int defaultMaxIdle = 8;
/*  58 */   private int defaultMaxWait = (int)Math.min(2147483647L, -1L);
/*     */   
/*  60 */   Map perUserDefaultAutoCommit = null;
/*  61 */   Map perUserDefaultTransactionIsolation = null;
/*  62 */   Map perUserMaxActive = null;
/*  63 */   Map perUserMaxIdle = null;
/*  64 */   Map perUserMaxWait = null;
/*  65 */   Map perUserDefaultReadOnly = null;
/*     */   
/*  67 */   private transient Map pools = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void close(Map poolMap) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  85 */     Iterator poolIter = this.pools.values().iterator();
/*  86 */     while (poolIter.hasNext()) {
/*     */       try {
/*  88 */         ((ObjectPool)poolIter.next()).close();
/*  89 */       } catch (Exception closePoolException) {}
/*     */     } 
/*     */ 
/*     */     
/*  93 */     InstanceKeyObjectFactory.removeInstance(this.instanceKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDefaultMaxActive() {
/* 106 */     return this.defaultMaxActive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultMaxActive(int maxActive) {
/* 116 */     assertInitializationAllowed();
/* 117 */     this.defaultMaxActive = maxActive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDefaultMaxIdle() {
/* 127 */     return this.defaultMaxIdle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultMaxIdle(int defaultMaxIdle) {
/* 137 */     assertInitializationAllowed();
/* 138 */     this.defaultMaxIdle = defaultMaxIdle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDefaultMaxWait() {
/* 150 */     return this.defaultMaxWait;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultMaxWait(int defaultMaxWait) {
/* 162 */     assertInitializationAllowed();
/* 163 */     this.defaultMaxWait = defaultMaxWait;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getPerUserDefaultAutoCommit(String key) {
/* 171 */     Boolean value = null;
/* 172 */     if (this.perUserDefaultAutoCommit != null) {
/* 173 */       value = (Boolean)this.perUserDefaultAutoCommit.get(key);
/*     */     }
/* 175 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPerUserDefaultAutoCommit(String username, Boolean value) {
/* 183 */     assertInitializationAllowed();
/* 184 */     if (this.perUserDefaultAutoCommit == null) {
/* 185 */       this.perUserDefaultAutoCommit = new HashMap();
/*     */     }
/* 187 */     this.perUserDefaultAutoCommit.put(username, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getPerUserDefaultTransactionIsolation(String username) {
/* 195 */     Integer value = null;
/* 196 */     if (this.perUserDefaultTransactionIsolation != null) {
/* 197 */       value = (Integer)this.perUserDefaultTransactionIsolation.get(username);
/*     */     }
/* 199 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPerUserDefaultTransactionIsolation(String username, Integer value) {
/* 208 */     assertInitializationAllowed();
/* 209 */     if (this.perUserDefaultTransactionIsolation == null) {
/* 210 */       this.perUserDefaultTransactionIsolation = new HashMap();
/*     */     }
/* 212 */     this.perUserDefaultTransactionIsolation.put(username, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getPerUserMaxActive(String username) {
/* 222 */     Integer value = null;
/* 223 */     if (this.perUserMaxActive != null) {
/* 224 */       value = (Integer)this.perUserMaxActive.get(username);
/*     */     }
/* 226 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPerUserMaxActive(String username, Integer value) {
/* 236 */     assertInitializationAllowed();
/* 237 */     if (this.perUserMaxActive == null) {
/* 238 */       this.perUserMaxActive = new HashMap();
/*     */     }
/* 240 */     this.perUserMaxActive.put(username, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getPerUserMaxIdle(String username) {
/* 251 */     Integer value = null;
/* 252 */     if (this.perUserMaxIdle != null) {
/* 253 */       value = (Integer)this.perUserMaxIdle.get(username);
/*     */     }
/* 255 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPerUserMaxIdle(String username, Integer value) {
/* 265 */     assertInitializationAllowed();
/* 266 */     if (this.perUserMaxIdle == null) {
/* 267 */       this.perUserMaxIdle = new HashMap();
/*     */     }
/* 269 */     this.perUserMaxIdle.put(username, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getPerUserMaxWait(String username) {
/* 281 */     Integer value = null;
/* 282 */     if (this.perUserMaxWait != null) {
/* 283 */       value = (Integer)this.perUserMaxWait.get(username);
/*     */     }
/* 285 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPerUserMaxWait(String username, Integer value) {
/* 297 */     assertInitializationAllowed();
/* 298 */     if (this.perUserMaxWait == null) {
/* 299 */       this.perUserMaxWait = new HashMap();
/*     */     }
/* 301 */     this.perUserMaxWait.put(username, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getPerUserDefaultReadOnly(String username) {
/* 309 */     Boolean value = null;
/* 310 */     if (this.perUserDefaultReadOnly != null) {
/* 311 */       value = (Boolean)this.perUserDefaultReadOnly.get(username);
/*     */     }
/* 313 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPerUserDefaultReadOnly(String username, Boolean value) {
/* 321 */     assertInitializationAllowed();
/* 322 */     if (this.perUserDefaultReadOnly == null) {
/* 323 */       this.perUserDefaultReadOnly = new HashMap();
/*     */     }
/* 325 */     this.perUserDefaultReadOnly.put(username, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumActive() {
/* 335 */     return getNumActive((String)null, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumActive(String username, String password) {
/* 342 */     ObjectPool pool = (ObjectPool)this.pools.get(getPoolKey(username));
/* 343 */     return (pool == null) ? 0 : pool.getNumActive();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumIdle() {
/* 350 */     return getNumIdle((String)null, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumIdle(String username, String password) {
/* 357 */     ObjectPool pool = (ObjectPool)this.pools.get(getPoolKey(username));
/* 358 */     return (pool == null) ? 0 : pool.getNumIdle();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized PooledConnectionAndInfo getPooledConnectionAndInfo(String username, String password) throws SQLException {
/* 369 */     PoolKey key = getPoolKey(username);
/* 370 */     Object pool = this.pools.get(key);
/* 371 */     if (pool == null) {
/*     */       try {
/* 373 */         registerPool(username, password);
/* 374 */         pool = this.pools.get(key);
/* 375 */       } catch (NamingException e) {
/* 376 */         throw new SQLNestedException("RegisterPool failed", e);
/*     */       } 
/*     */     }
/*     */     
/* 380 */     PooledConnectionAndInfo info = null;
/*     */     try {
/* 382 */       info = (PooledConnectionAndInfo)((ObjectPool)pool).borrowObject();
/*     */     }
/* 384 */     catch (Exception e) {
/* 385 */       throw new SQLNestedException("Could not retrieve connection info from pool", e);
/*     */     } 
/*     */ 
/*     */     
/* 389 */     return info;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setupDefaults(Connection con, String username) throws SQLException {
/* 394 */     boolean defaultAutoCommit = isDefaultAutoCommit();
/* 395 */     if (username != null) {
/* 396 */       Boolean userMax = getPerUserDefaultAutoCommit(username);
/* 397 */       if (userMax != null) {
/* 398 */         defaultAutoCommit = userMax.booleanValue();
/*     */       }
/*     */     } 
/*     */     
/* 402 */     boolean defaultReadOnly = isDefaultReadOnly();
/* 403 */     if (username != null) {
/* 404 */       Boolean userMax = getPerUserDefaultReadOnly(username);
/* 405 */       if (userMax != null) {
/* 406 */         defaultReadOnly = userMax.booleanValue();
/*     */       }
/*     */     } 
/*     */     
/* 410 */     int defaultTransactionIsolation = getDefaultTransactionIsolation();
/* 411 */     if (username != null) {
/* 412 */       Integer userMax = getPerUserDefaultTransactionIsolation(username);
/* 413 */       if (userMax != null) {
/* 414 */         defaultTransactionIsolation = userMax.intValue();
/*     */       }
/*     */     } 
/*     */     
/* 418 */     con.setAutoCommit(defaultAutoCommit);
/* 419 */     if (defaultTransactionIsolation != -1) {
/* 420 */       con.setTransactionIsolation(defaultTransactionIsolation);
/*     */     }
/* 422 */     con.setReadOnly(defaultReadOnly);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reference getReference() throws NamingException {
/* 431 */     Reference ref = new Reference(getClass().getName(), PerUserPoolDataSourceFactory.class.getName(), null);
/*     */     
/* 433 */     ref.add(new StringRefAddr("instanceKey", this.instanceKey));
/* 434 */     return ref;
/*     */   }
/*     */   
/*     */   private PoolKey getPoolKey(String username) {
/* 438 */     PoolKey key = null;
/* 439 */     String dsName = getDataSourceName();
/* 440 */     Map dsMap = (Map)poolKeys.get(dsName);
/* 441 */     if (dsMap != null) {
/* 442 */       key = (PoolKey)dsMap.get(username);
/*     */     }
/*     */     
/* 445 */     if (key == null) {
/* 446 */       key = new PoolKey(dsName, username);
/* 447 */       if (dsMap == null) {
/* 448 */         dsMap = new HashMap();
/* 449 */         poolKeys.put(dsName, dsMap);
/*     */       } 
/* 451 */       dsMap.put(username, key);
/*     */     } 
/* 453 */     return key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void registerPool(String username, String password) throws NamingException, SQLException {
/* 460 */     ConnectionPoolDataSource cpds = testCPDS(username, password);
/*     */     
/* 462 */     Integer userMax = getPerUserMaxActive(username);
/* 463 */     int maxActive = (userMax == null) ? getDefaultMaxActive() : userMax.intValue();
/*     */     
/* 465 */     userMax = getPerUserMaxIdle(username);
/* 466 */     int maxIdle = (userMax == null) ? getDefaultMaxIdle() : userMax.intValue();
/*     */     
/* 468 */     userMax = getPerUserMaxWait(username);
/* 469 */     int maxWait = (userMax == null) ? getDefaultMaxWait() : userMax.intValue();
/*     */ 
/*     */ 
/*     */     
/* 473 */     GenericObjectPool pool = new GenericObjectPool(null);
/* 474 */     pool.setMaxActive(maxActive);
/* 475 */     pool.setMaxIdle(maxIdle);
/* 476 */     pool.setMaxWait(maxWait);
/* 477 */     pool.setWhenExhaustedAction(whenExhaustedAction(maxActive, maxWait));
/* 478 */     pool.setTestOnBorrow(getTestOnBorrow());
/* 479 */     pool.setTestOnReturn(getTestOnReturn());
/* 480 */     pool.setTimeBetweenEvictionRunsMillis(getTimeBetweenEvictionRunsMillis());
/*     */     
/* 482 */     pool.setNumTestsPerEvictionRun(getNumTestsPerEvictionRun());
/* 483 */     pool.setMinEvictableIdleTimeMillis(getMinEvictableIdleTimeMillis());
/* 484 */     pool.setTestWhileIdle(getTestWhileIdle());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 489 */     new CPDSConnectionFactory(cpds, (ObjectPool)pool, getValidationQuery(), isRollbackAfterValidation(), username, password);
/*     */ 
/*     */ 
/*     */     
/* 493 */     this.pools.put(getPoolKey(username), pool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/*     */     try {
/* 507 */       in.defaultReadObject();
/* 508 */       PerUserPoolDataSource oldDS = (PerUserPoolDataSource)(new PerUserPoolDataSourceFactory()).getObjectInstance(getReference(), null, null, null);
/*     */ 
/*     */       
/* 511 */       this.pools = oldDS.pools;
/*     */     }
/* 513 */     catch (NamingException e) {
/*     */       
/* 515 */       throw new IOException("NamingException: " + e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\PerUserPoolDataSource.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */