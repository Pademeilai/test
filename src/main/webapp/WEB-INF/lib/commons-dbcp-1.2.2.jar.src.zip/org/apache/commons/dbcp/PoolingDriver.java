/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.jocl.JOCLContentHandler;
/*     */ import org.apache.commons.pool.ObjectPool;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoolingDriver
/*     */   implements Driver
/*     */ {
/*     */   static {
/*     */     try {
/*  56 */       DriverManager.registerDriver(new PoolingDriver());
/*  57 */     } catch (Exception e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  62 */   protected static HashMap _pools = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean accessToUnderlyingConnectionAllowed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean isAccessToUnderlyingConnectionAllowed() {
/*  76 */     return accessToUnderlyingConnectionAllowed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setAccessToUnderlyingConnectionAllowed(boolean allow) {
/*  87 */     accessToUnderlyingConnectionAllowed = allow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ObjectPool getPool(String name) {
/*     */     try {
/*  98 */       return getConnectionPool(name);
/*     */     }
/* 100 */     catch (Exception e) {
/* 101 */       throw new DbcpException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized ObjectPool getConnectionPool(String name) throws SQLException {
/* 106 */     ObjectPool pool = (ObjectPool)_pools.get(name);
/* 107 */     if (null == pool) {
/* 108 */       InputStream in = getClass().getResourceAsStream(String.valueOf(name) + ".jocl");
/* 109 */       if (null != in) {
/* 110 */         JOCLContentHandler jocl = null;
/*     */         try {
/* 112 */           jocl = JOCLContentHandler.parse(in);
/*     */         }
/* 114 */         catch (SAXException e) {
/* 115 */           throw new SQLNestedException("Could not parse configuration file", e);
/*     */         }
/* 117 */         catch (IOException e) {
/* 118 */           throw new SQLNestedException("Could not load configuration file", e);
/*     */         } 
/* 120 */         if (jocl.getType(0).equals(String.class)) {
/* 121 */           pool = getPool((String)jocl.getValue(0));
/* 122 */           if (null != pool) {
/* 123 */             registerPool(name, pool);
/*     */           }
/*     */         } else {
/* 126 */           pool = ((PoolableConnectionFactory)jocl.getValue(0)).getPool();
/* 127 */           if (null != pool) {
/* 128 */             registerPool(name, pool);
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 133 */         throw new SQLException("Configuration file not found");
/*     */       } 
/*     */     } 
/* 136 */     return pool;
/*     */   }
/*     */   
/*     */   public synchronized void registerPool(String name, ObjectPool pool) {
/* 140 */     _pools.put(name, pool);
/*     */   }
/*     */   
/*     */   public synchronized void closePool(String name) throws SQLException {
/* 144 */     ObjectPool pool = (ObjectPool)_pools.get(name);
/* 145 */     if (pool != null) {
/* 146 */       _pools.remove(name);
/*     */       try {
/* 148 */         pool.close();
/*     */       }
/* 150 */       catch (Exception e) {
/* 151 */         throw new SQLNestedException("Error closing pool " + name, e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized String[] getPoolNames() throws SQLException {
/* 157 */     Set names = _pools.keySet();
/* 158 */     return (String[])names.toArray((Object[])new String[names.size()]);
/*     */   }
/*     */   
/*     */   public boolean acceptsURL(String url) throws SQLException {
/*     */     try {
/* 163 */       return url.startsWith(URL_PREFIX);
/* 164 */     } catch (NullPointerException e) {
/* 165 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Connection connect(String url, Properties info) throws SQLException {
/* 170 */     if (acceptsURL(url)) {
/* 171 */       ObjectPool pool = getConnectionPool(url.substring(URL_PREFIX_LEN));
/* 172 */       if (null == pool) {
/* 173 */         throw new SQLException("No pool found for " + url + ".");
/*     */       }
/*     */       try {
/* 176 */         Connection conn = (Connection)pool.borrowObject();
/* 177 */         if (conn != null) {
/* 178 */           conn = new PoolGuardConnectionWrapper(this, pool, conn);
/*     */         }
/* 180 */         return conn;
/* 181 */       } catch (SQLException e) {
/* 182 */         throw e;
/* 183 */       } catch (NoSuchElementException e) {
/* 184 */         throw new SQLNestedException("Cannot get a connection, pool error: " + e.getMessage(), e);
/* 185 */       } catch (RuntimeException e) {
/* 186 */         throw e;
/* 187 */       } catch (Exception e) {
/* 188 */         throw new SQLNestedException("Cannot get a connection, general error: " + e.getMessage(), e);
/*     */       } 
/*     */     } 
/*     */     
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invalidateConnection(Connection conn) throws SQLException {
/* 206 */     if (conn instanceof PoolGuardConnectionWrapper) {
/* 207 */       PoolGuardConnectionWrapper pgconn = (PoolGuardConnectionWrapper)conn;
/* 208 */       ObjectPool pool = pgconn.pool;
/* 209 */       Connection delegate = pgconn.delegate;
/*     */       try {
/* 211 */         pool.invalidateObject(delegate);
/*     */       }
/* 213 */       catch (Exception e) {}
/*     */       
/* 215 */       pgconn.delegate = null;
/*     */     } else {
/*     */       
/* 218 */       throw new SQLException("Invalid connection class");
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getMajorVersion() {
/* 223 */     return MAJOR_VERSION;
/*     */   }
/*     */   
/*     */   public int getMinorVersion() {
/* 227 */     return MINOR_VERSION;
/*     */   }
/*     */   
/*     */   public boolean jdbcCompliant() {
/* 231 */     return true;
/*     */   }
/*     */   
/*     */   public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) {
/* 235 */     return new DriverPropertyInfo[0];
/*     */   }
/*     */ 
/*     */   
/* 239 */   protected static String URL_PREFIX = "jdbc:apache:commons:dbcp:";
/* 240 */   protected static int URL_PREFIX_LEN = URL_PREFIX.length();
/*     */ 
/*     */   
/* 243 */   protected static int MAJOR_VERSION = 1;
/* 244 */   protected static int MINOR_VERSION = 0;
/*     */ 
/*     */   
/*     */   private class PoolGuardConnectionWrapper
/*     */     extends DelegatingConnection
/*     */   {
/*     */     private ObjectPool pool;
/*     */     
/*     */     private Connection delegate;
/*     */     private final PoolingDriver this$0;
/*     */     
/*     */     PoolGuardConnectionWrapper(PoolingDriver this$0, ObjectPool pool, Connection delegate) {
/* 256 */       super(delegate); this.this$0 = this$0;
/* 257 */       this.pool = pool;
/* 258 */       this.delegate = delegate;
/*     */     }
/*     */     
/*     */     protected void checkOpen() throws SQLException {
/* 262 */       if (this.delegate == null) {
/* 263 */         throw new SQLException("Connection is closed.");
/*     */       }
/*     */     }
/*     */     
/*     */     public void close() throws SQLException {
/* 268 */       checkOpen();
/* 269 */       this.delegate.close();
/* 270 */       this.delegate = null;
/* 271 */       setDelegate(null);
/*     */     }
/*     */     
/*     */     public boolean isClosed() throws SQLException {
/* 275 */       if (this.delegate == null) {
/* 276 */         return true;
/*     */       }
/* 278 */       return this.delegate.isClosed();
/*     */     }
/*     */     
/*     */     public void clearWarnings() throws SQLException {
/* 282 */       checkOpen();
/* 283 */       this.delegate.clearWarnings();
/*     */     }
/*     */     
/*     */     public void commit() throws SQLException {
/* 287 */       checkOpen();
/* 288 */       this.delegate.commit();
/*     */     }
/*     */     
/*     */     public Statement createStatement() throws SQLException {
/* 292 */       checkOpen();
/* 293 */       return this.delegate.createStatement();
/*     */     }
/*     */     
/*     */     public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/* 297 */       checkOpen();
/* 298 */       return this.delegate.createStatement(resultSetType, resultSetConcurrency);
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj) {
/* 302 */       if (this.delegate == null) {
/* 303 */         return false;
/*     */       }
/* 305 */       return this.delegate.equals(obj);
/*     */     }
/*     */     
/*     */     public boolean getAutoCommit() throws SQLException {
/* 309 */       checkOpen();
/* 310 */       return this.delegate.getAutoCommit();
/*     */     }
/*     */     
/*     */     public String getCatalog() throws SQLException {
/* 314 */       checkOpen();
/* 315 */       return this.delegate.getCatalog();
/*     */     }
/*     */     
/*     */     public DatabaseMetaData getMetaData() throws SQLException {
/* 319 */       checkOpen();
/* 320 */       return this.delegate.getMetaData();
/*     */     }
/*     */     
/*     */     public int getTransactionIsolation() throws SQLException {
/* 324 */       checkOpen();
/* 325 */       return this.delegate.getTransactionIsolation();
/*     */     }
/*     */     
/*     */     public Map getTypeMap() throws SQLException {
/* 329 */       checkOpen();
/* 330 */       return this.delegate.getTypeMap();
/*     */     }
/*     */     
/*     */     public SQLWarning getWarnings() throws SQLException {
/* 334 */       checkOpen();
/* 335 */       return this.delegate.getWarnings();
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 339 */       if (this.delegate == null) {
/* 340 */         return 0;
/*     */       }
/* 342 */       return this.delegate.hashCode();
/*     */     }
/*     */     
/*     */     public boolean isReadOnly() throws SQLException {
/* 346 */       checkOpen();
/* 347 */       return this.delegate.isReadOnly();
/*     */     }
/*     */     
/*     */     public String nativeSQL(String sql) throws SQLException {
/* 351 */       checkOpen();
/* 352 */       return this.delegate.nativeSQL(sql);
/*     */     }
/*     */     
/*     */     public CallableStatement prepareCall(String sql) throws SQLException {
/* 356 */       checkOpen();
/* 357 */       return this.delegate.prepareCall(sql);
/*     */     }
/*     */     
/*     */     public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 361 */       checkOpen();
/* 362 */       return this.delegate.prepareCall(sql, resultSetType, resultSetConcurrency);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql) throws SQLException {
/* 366 */       checkOpen();
/* 367 */       return this.delegate.prepareStatement(sql);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 371 */       checkOpen();
/* 372 */       return this.delegate.prepareStatement(sql, resultSetType, resultSetConcurrency);
/*     */     }
/*     */     
/*     */     public void rollback() throws SQLException {
/* 376 */       checkOpen();
/* 377 */       this.delegate.rollback();
/*     */     }
/*     */     
/*     */     public void setAutoCommit(boolean autoCommit) throws SQLException {
/* 381 */       checkOpen();
/* 382 */       this.delegate.setAutoCommit(autoCommit);
/*     */     }
/*     */     
/*     */     public void setCatalog(String catalog) throws SQLException {
/* 386 */       checkOpen();
/* 387 */       this.delegate.setCatalog(catalog);
/*     */     }
/*     */     
/*     */     public void setReadOnly(boolean readOnly) throws SQLException {
/* 391 */       checkOpen();
/* 392 */       this.delegate.setReadOnly(readOnly);
/*     */     }
/*     */     
/*     */     public void setTransactionIsolation(int level) throws SQLException {
/* 396 */       checkOpen();
/* 397 */       this.delegate.setTransactionIsolation(level);
/*     */     }
/*     */     
/*     */     public void setTypeMap(Map map) throws SQLException {
/* 401 */       checkOpen();
/* 402 */       this.delegate.setTypeMap(map);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 406 */       if (this.delegate == null) {
/* 407 */         return null;
/*     */       }
/* 409 */       return this.delegate.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getHoldability() throws SQLException {
/* 418 */       checkOpen();
/* 419 */       return this.delegate.getHoldability();
/*     */     }
/*     */     
/*     */     public void setHoldability(int holdability) throws SQLException {
/* 423 */       checkOpen();
/* 424 */       this.delegate.setHoldability(holdability);
/*     */     }
/*     */     
/*     */     public Savepoint setSavepoint() throws SQLException {
/* 428 */       checkOpen();
/* 429 */       return this.delegate.setSavepoint();
/*     */     }
/*     */     
/*     */     public Savepoint setSavepoint(String name) throws SQLException {
/* 433 */       checkOpen();
/* 434 */       return this.delegate.setSavepoint(name);
/*     */     }
/*     */     
/*     */     public void releaseSavepoint(Savepoint savepoint) throws SQLException {
/* 438 */       checkOpen();
/* 439 */       this.delegate.releaseSavepoint(savepoint);
/*     */     }
/*     */     
/*     */     public void rollback(Savepoint savepoint) throws SQLException {
/* 443 */       checkOpen();
/* 444 */       this.delegate.rollback(savepoint);
/*     */     }
/*     */     
/*     */     public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 448 */       checkOpen();
/* 449 */       return this.delegate.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */     }
/*     */     
/*     */     public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 453 */       checkOpen();
/* 454 */       return this.delegate.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException {
/* 458 */       checkOpen();
/* 459 */       return this.delegate.prepareStatement(sql, autoGeneratedKeys);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 463 */       checkOpen();
/* 464 */       return this.delegate.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException {
/* 468 */       checkOpen();
/* 469 */       return this.delegate.prepareStatement(sql, columnIndexes);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException {
/* 473 */       checkOpen();
/* 474 */       return this.delegate.prepareStatement(sql, columnNames);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Connection getDelegate() {
/* 483 */       if (PoolingDriver.isAccessToUnderlyingConnectionAllowed()) {
/* 484 */         return super.getDelegate();
/*     */       }
/* 486 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Connection getInnermostDelegate() {
/* 494 */       if (PoolingDriver.isAccessToUnderlyingConnectionAllowed()) {
/* 495 */         return super.getInnermostDelegate();
/*     */       }
/* 497 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\PoolingDriver.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */