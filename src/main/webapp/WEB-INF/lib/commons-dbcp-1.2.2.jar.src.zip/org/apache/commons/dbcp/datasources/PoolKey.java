/*    */ package org.apache.commons.dbcp.datasources;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PoolKey
/*    */   implements Serializable
/*    */ {
/*    */   private String datasourceName;
/*    */   private String username;
/*    */   
/*    */   PoolKey(String datasourceName, String username) {
/* 30 */     this.datasourceName = datasourceName;
/* 31 */     this.username = username;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 35 */     if (obj instanceof PoolKey) {
/* 36 */       PoolKey pk = (PoolKey)obj;
/* 37 */       return (((null == this.datasourceName) ? (null == pk.datasourceName) : this.datasourceName.equals(pk.datasourceName)) && ((null == this.username) ? (null == pk.username) : this.username.equals(pk.username)));
/*    */     } 
/*    */     
/* 40 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 45 */     int h = 0;
/* 46 */     if (this.datasourceName != null) {
/* 47 */       h += this.datasourceName.hashCode();
/*    */     }
/* 49 */     if (this.username != null) {
/* 50 */       h = 29 * h + this.username.hashCode();
/*    */     }
/* 52 */     return h;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 56 */     StringBuffer sb = new StringBuffer(50);
/* 57 */     sb.append("PoolKey(");
/* 58 */     sb.append(this.username).append(", ").append(this.datasourceName);
/* 59 */     sb.append(')');
/* 60 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\PoolKey.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */