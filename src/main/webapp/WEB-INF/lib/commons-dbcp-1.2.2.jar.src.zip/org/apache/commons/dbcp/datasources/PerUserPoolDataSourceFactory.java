/*    */ package org.apache.commons.dbcp.datasources;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.naming.RefAddr;
/*    */ import javax.naming.Reference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PerUserPoolDataSourceFactory
/*    */   extends InstanceKeyObjectFactory
/*    */ {
/* 34 */   private static final String PER_USER_POOL_CLASSNAME = PerUserPoolDataSource.class.getName();
/*    */ 
/*    */   
/*    */   protected boolean isCorrectClass(String className) {
/* 38 */     return PER_USER_POOL_CLASSNAME.equals(className);
/*    */   }
/*    */ 
/*    */   
/*    */   protected InstanceKeyDataSource getNewInstance(Reference ref) throws IOException, ClassNotFoundException {
/* 43 */     PerUserPoolDataSource pupds = new PerUserPoolDataSource();
/* 44 */     RefAddr ra = ref.get("defaultMaxActive");
/* 45 */     if (ra != null && ra.getContent() != null) {
/* 46 */       pupds.setDefaultMaxActive(Integer.parseInt(ra.getContent().toString()));
/*    */     }
/*    */ 
/*    */     
/* 50 */     ra = ref.get("defaultMaxIdle");
/* 51 */     if (ra != null && ra.getContent() != null) {
/* 52 */       pupds.setDefaultMaxIdle(Integer.parseInt(ra.getContent().toString()));
/*    */     }
/*    */ 
/*    */     
/* 56 */     ra = ref.get("defaultMaxWait");
/* 57 */     if (ra != null && ra.getContent() != null) {
/* 58 */       pupds.setDefaultMaxWait(Integer.parseInt(ra.getContent().toString()));
/*    */     }
/*    */ 
/*    */     
/* 62 */     ra = ref.get("perUserDefaultAutoCommit");
/* 63 */     if (ra != null && ra.getContent() != null) {
/* 64 */       byte[] serialized = (byte[])ra.getContent();
/* 65 */       pupds.perUserDefaultAutoCommit = (Map)deserialize(serialized);
/*    */     } 
/*    */     
/* 68 */     ra = ref.get("perUserDefaultTransactionIsolation");
/* 69 */     if (ra != null && ra.getContent() != null) {
/* 70 */       byte[] serialized = (byte[])ra.getContent();
/* 71 */       pupds.perUserDefaultTransactionIsolation = (Map)deserialize(serialized);
/*    */     } 
/*    */ 
/*    */     
/* 75 */     ra = ref.get("perUserMaxActive");
/* 76 */     if (ra != null && ra.getContent() != null) {
/* 77 */       byte[] serialized = (byte[])ra.getContent();
/* 78 */       pupds.perUserMaxActive = (Map)deserialize(serialized);
/*    */     } 
/*    */     
/* 81 */     ra = ref.get("perUserMaxIdle");
/* 82 */     if (ra != null && ra.getContent() != null) {
/* 83 */       byte[] serialized = (byte[])ra.getContent();
/* 84 */       pupds.perUserMaxIdle = (Map)deserialize(serialized);
/*    */     } 
/*    */     
/* 87 */     ra = ref.get("perUserMaxWait");
/* 88 */     if (ra != null && ra.getContent() != null) {
/* 89 */       byte[] serialized = (byte[])ra.getContent();
/* 90 */       pupds.perUserMaxWait = (Map)deserialize(serialized);
/*    */     } 
/*    */     
/* 93 */     ra = ref.get("perUserDefaultReadOnly");
/* 94 */     if (ra != null && ra.getContent() != null) {
/* 95 */       byte[] serialized = (byte[])ra.getContent();
/* 96 */       pupds.perUserDefaultReadOnly = (Map)deserialize(serialized);
/*    */     } 
/* 98 */     return pupds;
/*    */   }
/*    */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\PerUserPoolDataSourceFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */