/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ import javax.sql.DataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicDataSourceFactory
/*     */   implements ObjectFactory
/*     */ {
/*     */   private static final String PROP_DEFAULTAUTOCOMMIT = "defaultAutoCommit";
/*     */   private static final String PROP_DEFAULTREADONLY = "defaultReadOnly";
/*     */   private static final String PROP_DEFAULTTRANSACTIONISOLATION = "defaultTransactionIsolation";
/*     */   private static final String PROP_DEFAULTCATALOG = "defaultCatalog";
/*     */   private static final String PROP_DRIVERCLASSNAME = "driverClassName";
/*     */   private static final String PROP_MAXACTIVE = "maxActive";
/*     */   private static final String PROP_MAXIDLE = "maxIdle";
/*     */   private static final String PROP_MINIDLE = "minIdle";
/*     */   private static final String PROP_INITIALSIZE = "initialSize";
/*     */   private static final String PROP_MAXWAIT = "maxWait";
/*     */   private static final String PROP_TESTONBORROW = "testOnBorrow";
/*     */   private static final String PROP_TESTONRETURN = "testOnReturn";
/*     */   private static final String PROP_TIMEBETWEENEVICTIONRUNSMILLIS = "timeBetweenEvictionRunsMillis";
/*     */   private static final String PROP_NUMTESTSPEREVICTIONRUN = "numTestsPerEvictionRun";
/*     */   private static final String PROP_MINEVICTABLEIDLETIMEMILLIS = "minEvictableIdleTimeMillis";
/*     */   private static final String PROP_TESTWHILEIDLE = "testWhileIdle";
/*     */   private static final String PROP_PASSWORD = "password";
/*     */   private static final String PROP_URL = "url";
/*     */   private static final String PROP_USERNAME = "username";
/*     */   private static final String PROP_VALIDATIONQUERY = "validationQuery";
/*     */   private static final String PROP_ACCESSTOUNDERLYINGCONNECTIONALLOWED = "accessToUnderlyingConnectionAllowed";
/*     */   private static final String PROP_REMOVEABANDONED = "removeAbandoned";
/*     */   private static final String PROP_REMOVEABANDONEDTIMEOUT = "removeAbandonedTimeout";
/*     */   private static final String PROP_LOGABANDONED = "logAbandoned";
/*     */   private static final String PROP_POOLPREPAREDSTATEMENTS = "poolPreparedStatements";
/*     */   private static final String PROP_MAXOPENPREPAREDSTATEMENTS = "maxOpenPreparedStatements";
/*     */   private static final String PROP_CONNECTIONPROPERTIES = "connectionProperties";
/*  74 */   private static final String[] ALL_PROPERTIES = new String[] { "defaultAutoCommit", "defaultReadOnly", "defaultTransactionIsolation", "defaultCatalog", "driverClassName", "maxActive", "maxIdle", "minIdle", "initialSize", "maxWait", "testOnBorrow", "testOnReturn", "timeBetweenEvictionRunsMillis", "numTestsPerEvictionRun", "minEvictableIdleTimeMillis", "testWhileIdle", "password", "url", "username", "validationQuery", "accessToUnderlyingConnectionAllowed", "removeAbandoned", "removeAbandonedTimeout", "logAbandoned", "poolPreparedStatements", "maxOpenPreparedStatements", "connectionProperties" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable environment) throws Exception {
/* 127 */     if (obj == null || !(obj instanceof Reference)) {
/* 128 */       return null;
/*     */     }
/* 130 */     Reference ref = (Reference)obj;
/* 131 */     if (!"javax.sql.DataSource".equals(ref.getClassName())) {
/* 132 */       return null;
/*     */     }
/*     */     
/* 135 */     Properties properties = new Properties();
/* 136 */     for (int i = 0; i < ALL_PROPERTIES.length; i++) {
/* 137 */       String propertyName = ALL_PROPERTIES[i];
/* 138 */       RefAddr ra = ref.get(propertyName);
/* 139 */       if (ra != null) {
/* 140 */         String propertyValue = ra.getContent().toString();
/* 141 */         properties.setProperty(propertyName, propertyValue);
/*     */       } 
/*     */     } 
/*     */     
/* 145 */     return createDataSource(properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DataSource createDataSource(Properties properties) throws Exception {
/* 156 */     BasicDataSource dataSource = new BasicDataSource();
/* 157 */     String value = null;
/*     */     
/* 159 */     value = properties.getProperty("defaultAutoCommit");
/* 160 */     if (value != null) {
/* 161 */       dataSource.setDefaultAutoCommit(Boolean.valueOf(value).booleanValue());
/*     */     }
/*     */     
/* 164 */     value = properties.getProperty("defaultReadOnly");
/* 165 */     if (value != null) {
/* 166 */       dataSource.setDefaultReadOnly(Boolean.valueOf(value).booleanValue());
/*     */     }
/*     */     
/* 169 */     value = properties.getProperty("defaultTransactionIsolation");
/* 170 */     if (value != null) {
/* 171 */       int level = -1;
/* 172 */       if ("NONE".equalsIgnoreCase(value)) {
/* 173 */         level = 0;
/*     */       }
/* 175 */       else if ("READ_COMMITTED".equalsIgnoreCase(value)) {
/* 176 */         level = 2;
/*     */       }
/* 178 */       else if ("READ_UNCOMMITTED".equalsIgnoreCase(value)) {
/* 179 */         level = 1;
/*     */       }
/* 181 */       else if ("REPEATABLE_READ".equalsIgnoreCase(value)) {
/* 182 */         level = 4;
/*     */       }
/* 184 */       else if ("SERIALIZABLE".equalsIgnoreCase(value)) {
/* 185 */         level = 8;
/*     */       } else {
/*     */         
/*     */         try {
/* 189 */           level = Integer.parseInt(value);
/* 190 */         } catch (NumberFormatException e) {
/* 191 */           System.err.println("Could not parse defaultTransactionIsolation: " + value);
/* 192 */           System.err.println("WARNING: defaultTransactionIsolation not set");
/* 193 */           System.err.println("using default value of database driver");
/* 194 */           level = -1;
/*     */         } 
/*     */       } 
/* 197 */       dataSource.setDefaultTransactionIsolation(level);
/*     */     } 
/*     */     
/* 200 */     value = properties.getProperty("defaultCatalog");
/* 201 */     if (value != null) {
/* 202 */       dataSource.setDefaultCatalog(value);
/*     */     }
/*     */     
/* 205 */     value = properties.getProperty("driverClassName");
/* 206 */     if (value != null) {
/* 207 */       dataSource.setDriverClassName(value);
/*     */     }
/*     */     
/* 210 */     value = properties.getProperty("maxActive");
/* 211 */     if (value != null) {
/* 212 */       dataSource.setMaxActive(Integer.parseInt(value));
/*     */     }
/*     */     
/* 215 */     value = properties.getProperty("maxIdle");
/* 216 */     if (value != null) {
/* 217 */       dataSource.setMaxIdle(Integer.parseInt(value));
/*     */     }
/*     */     
/* 220 */     value = properties.getProperty("minIdle");
/* 221 */     if (value != null) {
/* 222 */       dataSource.setMinIdle(Integer.parseInt(value));
/*     */     }
/*     */     
/* 225 */     value = properties.getProperty("initialSize");
/* 226 */     if (value != null) {
/* 227 */       dataSource.setInitialSize(Integer.parseInt(value));
/*     */     }
/*     */     
/* 230 */     value = properties.getProperty("maxWait");
/* 231 */     if (value != null) {
/* 232 */       dataSource.setMaxWait(Long.parseLong(value));
/*     */     }
/*     */     
/* 235 */     value = properties.getProperty("testOnBorrow");
/* 236 */     if (value != null) {
/* 237 */       dataSource.setTestOnBorrow(Boolean.valueOf(value).booleanValue());
/*     */     }
/*     */     
/* 240 */     value = properties.getProperty("testOnReturn");
/* 241 */     if (value != null) {
/* 242 */       dataSource.setTestOnReturn(Boolean.valueOf(value).booleanValue());
/*     */     }
/*     */     
/* 245 */     value = properties.getProperty("timeBetweenEvictionRunsMillis");
/* 246 */     if (value != null) {
/* 247 */       dataSource.setTimeBetweenEvictionRunsMillis(Long.parseLong(value));
/*     */     }
/*     */     
/* 250 */     value = properties.getProperty("numTestsPerEvictionRun");
/* 251 */     if (value != null) {
/* 252 */       dataSource.setNumTestsPerEvictionRun(Integer.parseInt(value));
/*     */     }
/*     */     
/* 255 */     value = properties.getProperty("minEvictableIdleTimeMillis");
/* 256 */     if (value != null) {
/* 257 */       dataSource.setMinEvictableIdleTimeMillis(Long.parseLong(value));
/*     */     }
/*     */     
/* 260 */     value = properties.getProperty("testWhileIdle");
/* 261 */     if (value != null) {
/* 262 */       dataSource.setTestWhileIdle(Boolean.valueOf(value).booleanValue());
/*     */     }
/*     */     
/* 265 */     value = properties.getProperty("password");
/* 266 */     if (value != null) {
/* 267 */       dataSource.setPassword(value);
/*     */     }
/*     */     
/* 270 */     value = properties.getProperty("url");
/* 271 */     if (value != null) {
/* 272 */       dataSource.setUrl(value);
/*     */     }
/*     */     
/* 275 */     value = properties.getProperty("username");
/* 276 */     if (value != null) {
/* 277 */       dataSource.setUsername(value);
/*     */     }
/*     */     
/* 280 */     value = properties.getProperty("validationQuery");
/* 281 */     if (value != null) {
/* 282 */       dataSource.setValidationQuery(value);
/*     */     }
/*     */     
/* 285 */     value = properties.getProperty("accessToUnderlyingConnectionAllowed");
/* 286 */     if (value != null) {
/* 287 */       dataSource.setAccessToUnderlyingConnectionAllowed(Boolean.valueOf(value).booleanValue());
/*     */     }
/*     */     
/* 290 */     value = properties.getProperty("removeAbandoned");
/* 291 */     if (value != null) {
/* 292 */       dataSource.setRemoveAbandoned(Boolean.valueOf(value).booleanValue());
/*     */     }
/*     */     
/* 295 */     value = properties.getProperty("removeAbandonedTimeout");
/* 296 */     if (value != null) {
/* 297 */       dataSource.setRemoveAbandonedTimeout(Integer.parseInt(value));
/*     */     }
/*     */     
/* 300 */     value = properties.getProperty("logAbandoned");
/* 301 */     if (value != null) {
/* 302 */       dataSource.setLogAbandoned(Boolean.valueOf(value).booleanValue());
/*     */     }
/*     */     
/* 305 */     value = properties.getProperty("poolPreparedStatements");
/* 306 */     if (value != null) {
/* 307 */       dataSource.setPoolPreparedStatements(Boolean.valueOf(value).booleanValue());
/*     */     }
/*     */     
/* 310 */     value = properties.getProperty("maxOpenPreparedStatements");
/* 311 */     if (value != null) {
/* 312 */       dataSource.setMaxOpenPreparedStatements(Integer.parseInt(value));
/*     */     }
/*     */     
/* 315 */     value = properties.getProperty("connectionProperties");
/* 316 */     if (value != null) {
/* 317 */       Properties p = getProperties(value);
/* 318 */       Enumeration e = p.propertyNames();
/* 319 */       while (e.hasMoreElements()) {
/* 320 */         String propertyName = (String)e.nextElement();
/* 321 */         dataSource.addConnectionProperty(propertyName, p.getProperty(propertyName));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 326 */     return dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Properties getProperties(String propText) throws Exception {
/* 336 */     Properties p = new Properties();
/* 337 */     if (propText != null) {
/* 338 */       p.load(new ByteArrayInputStream(propText.replace(';', '\n').getBytes()));
/*     */     }
/* 340 */     return p;
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\BasicDataSourceFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */