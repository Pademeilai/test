/*     */ package org.apache.commons.dbcp.datasources;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.sql.ConnectionEvent;
/*     */ import javax.sql.ConnectionEventListener;
/*     */ import javax.sql.ConnectionPoolDataSource;
/*     */ import javax.sql.PooledConnection;
/*     */ import org.apache.commons.dbcp.SQLNestedException;
/*     */ import org.apache.commons.pool.ObjectPool;
/*     */ import org.apache.commons.pool.PoolableObjectFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CPDSConnectionFactory
/*     */   implements PoolableObjectFactory, ConnectionEventListener
/*     */ {
/*     */   private static final String NO_KEY_MESSAGE = "close() was called on a Connection, but I have no record of the underlying PooledConnection.";
/*  51 */   protected ConnectionPoolDataSource _cpds = null;
/*  52 */   protected String _validationQuery = null;
/*     */   protected boolean _rollbackAfterValidation = false;
/*  54 */   protected ObjectPool _pool = null;
/*  55 */   protected String _username = null;
/*  56 */   protected String _password = null;
/*  57 */   private Map validatingMap = new HashMap();
/*  58 */   private WeakHashMap pcMap = new WeakHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CPDSConnectionFactory(ConnectionPoolDataSource cpds, ObjectPool pool, String validationQuery, String username, String password) {
/*  78 */     this._cpds = cpds;
/*  79 */     this._pool = pool;
/*  80 */     this._pool.setFactory(this);
/*  81 */     this._validationQuery = validationQuery;
/*  82 */     this._username = username;
/*  83 */     this._password = password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CPDSConnectionFactory(ConnectionPoolDataSource cpds, ObjectPool pool, String validationQuery, boolean rollbackAfterValidation, String username, String password) {
/* 107 */     this(cpds, pool, validationQuery, username, password);
/* 108 */     this._rollbackAfterValidation = rollbackAfterValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setCPDS(ConnectionPoolDataSource cpds) {
/* 119 */     this._cpds = cpds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setValidationQuery(String validationQuery) {
/* 131 */     this._validationQuery = validationQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setRollbackAfterValidation(boolean rollbackAfterValidation) {
/* 144 */     this._rollbackAfterValidation = rollbackAfterValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setPool(ObjectPool pool) throws SQLException {
/* 153 */     if (null != this._pool && pool != this._pool) {
/*     */       try {
/* 155 */         this._pool.close();
/* 156 */       } catch (RuntimeException e) {
/* 157 */         throw e;
/* 158 */       } catch (Exception e) {
/* 159 */         throw new SQLNestedException("Cannot set the pool on this factory", e);
/*     */       } 
/*     */     }
/* 162 */     this._pool = pool;
/*     */   }
/*     */   
/*     */   public ObjectPool getPool() {
/* 166 */     return this._pool;
/*     */   }
/*     */   
/*     */   public synchronized Object makeObject() {
/*     */     Object obj;
/*     */     try {
/* 172 */       PooledConnection pc = null;
/* 173 */       if (this._username == null) {
/* 174 */         pc = this._cpds.getPooledConnection();
/*     */       } else {
/* 176 */         pc = this._cpds.getPooledConnection(this._username, this._password);
/*     */       } 
/*     */ 
/*     */       
/* 180 */       pc.addConnectionEventListener(this);
/* 181 */       obj = new PooledConnectionAndInfo(pc, this._username, this._password);
/* 182 */       this.pcMap.put(pc, obj);
/* 183 */     } catch (SQLException e) {
/* 184 */       throw new RuntimeException(e.getMessage());
/*     */     } 
/* 186 */     return obj;
/*     */   }
/*     */   
/*     */   public void destroyObject(Object obj) throws Exception {
/* 190 */     if (obj instanceof PooledConnectionAndInfo) {
/* 191 */       ((PooledConnectionAndInfo)obj).getPooledConnection().close();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean validateObject(Object obj) {
/* 196 */     boolean valid = false;
/* 197 */     if (obj instanceof PooledConnectionAndInfo) {
/* 198 */       PooledConnection pconn = ((PooledConnectionAndInfo)obj).getPooledConnection();
/*     */       
/* 200 */       String query = this._validationQuery;
/* 201 */       if (null != query) {
/* 202 */         Connection conn = null;
/* 203 */         Statement stmt = null;
/* 204 */         ResultSet rset = null;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 209 */         this.validatingMap.put(pconn, null);
/*     */         try {
/* 211 */           conn = pconn.getConnection();
/* 212 */           stmt = conn.createStatement();
/* 213 */           rset = stmt.executeQuery(query);
/* 214 */           if (rset.next()) {
/* 215 */             valid = true;
/*     */           } else {
/* 217 */             valid = false;
/*     */           } 
/* 219 */           if (this._rollbackAfterValidation) {
/* 220 */             conn.rollback();
/*     */           }
/* 222 */         } catch (Exception e) {
/* 223 */           valid = false;
/*     */         } finally {
/* 225 */           if (rset != null) {
/*     */             try {
/* 227 */               rset.close();
/* 228 */             } catch (Throwable t) {}
/*     */           }
/*     */ 
/*     */           
/* 232 */           if (stmt != null) {
/*     */             try {
/* 234 */               stmt.close();
/* 235 */             } catch (Throwable t) {}
/*     */           }
/*     */ 
/*     */           
/* 239 */           if (conn != null) {
/*     */             try {
/* 241 */               conn.close();
/* 242 */             } catch (Throwable t) {}
/*     */           }
/*     */ 
/*     */           
/* 246 */           this.validatingMap.remove(pconn);
/*     */         } 
/*     */       } else {
/* 249 */         valid = true;
/*     */       } 
/*     */     } else {
/* 252 */       valid = false;
/*     */     } 
/* 254 */     return valid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void passivateObject(Object obj) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void activateObject(Object obj) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionClosed(ConnectionEvent event) {
/* 274 */     PooledConnection pc = (PooledConnection)event.getSource();
/*     */ 
/*     */     
/* 277 */     if (!this.validatingMap.containsKey(pc)) {
/* 278 */       Object info = this.pcMap.get(pc);
/* 279 */       if (info == null) {
/* 280 */         throw new IllegalStateException("close() was called on a Connection, but I have no record of the underlying PooledConnection.");
/*     */       }
/*     */       
/*     */       try {
/* 284 */         this._pool.returnObject(info);
/* 285 */       } catch (Exception e) {
/* 286 */         System.err.println("CLOSING DOWN CONNECTION AS IT COULD NOT BE RETURNED TO THE POOL");
/*     */         
/*     */         try {
/* 289 */           destroyObject(info);
/* 290 */         } catch (Exception e2) {
/* 291 */           System.err.println("EXCEPTION WHILE DESTROYING OBJECT " + info);
/*     */           
/* 293 */           e2.printStackTrace();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionErrorOccurred(ConnectionEvent event) {
/* 304 */     PooledConnection pc = (PooledConnection)event.getSource();
/*     */     try {
/* 306 */       if (null != event.getSQLException()) {
/* 307 */         System.err.println("CLOSING DOWN CONNECTION DUE TO INTERNAL ERROR (" + event.getSQLException() + ")");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 313 */       pc.removeConnectionEventListener(this);
/* 314 */     } catch (Exception ignore) {}
/*     */ 
/*     */ 
/*     */     
/* 318 */     Object info = this.pcMap.get(pc);
/* 319 */     if (info == null) {
/* 320 */       throw new IllegalStateException("close() was called on a Connection, but I have no record of the underlying PooledConnection.");
/*     */     }
/*     */     try {
/* 323 */       destroyObject(info);
/* 324 */     } catch (Exception e) {
/* 325 */       System.err.println("EXCEPTION WHILE DESTROYING OBJECT " + info);
/* 326 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\CPDSConnectionFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */