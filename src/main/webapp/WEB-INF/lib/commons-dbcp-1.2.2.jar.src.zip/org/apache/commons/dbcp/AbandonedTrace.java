/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbandonedTrace
/*     */ {
/*  40 */   private static SimpleDateFormat format = new SimpleDateFormat("'DBCP object created' yyyy-MM-dd HH:mm:ss 'by the following code was never closed:'");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   private AbandonedConfig config = null;
/*     */   
/*     */   private AbandonedTrace parent;
/*     */   
/*     */   private Exception createdBy;
/*     */   
/*     */   private long createdTime;
/*     */   
/*  53 */   private List trace = new ArrayList();
/*     */   
/*  55 */   private long lastUsed = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbandonedTrace() {
/*  62 */     init(this.parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbandonedTrace(AbandonedConfig config) {
/*  71 */     this.config = config;
/*  72 */     init(this.parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbandonedTrace(AbandonedTrace parent) {
/*  81 */     this.config = parent.getConfig();
/*  82 */     init(parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(AbandonedTrace parent) {
/*  91 */     if (parent != null) {
/*  92 */       parent.addTrace(this);
/*     */     }
/*     */     
/*  95 */     if (this.config == null) {
/*     */       return;
/*     */     }
/*  98 */     if (this.config.getLogAbandoned()) {
/*  99 */       this.createdBy = new Exception();
/* 100 */       this.createdTime = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbandonedConfig getConfig() {
/* 110 */     return this.config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getLastUsed() {
/* 119 */     if (this.parent != null) {
/* 120 */       return this.parent.getLastUsed();
/*     */     }
/* 122 */     return this.lastUsed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLastUsed() {
/* 130 */     if (this.parent != null) {
/* 131 */       this.parent.setLastUsed();
/*     */     } else {
/* 133 */       this.lastUsed = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLastUsed(long time) {
/* 143 */     if (this.parent != null) {
/* 144 */       this.parent.setLastUsed(time);
/*     */     } else {
/* 146 */       this.lastUsed = time;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setStackTrace() {
/* 156 */     if (this.config == null) {
/*     */       return;
/*     */     }
/* 159 */     if (this.config.getLogAbandoned()) {
/* 160 */       this.createdBy = new Exception();
/* 161 */       this.createdTime = System.currentTimeMillis();
/*     */     } 
/* 163 */     if (this.parent != null) {
/* 164 */       this.parent.addTrace(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addTrace(AbandonedTrace trace) {
/* 175 */     synchronized (this) {
/* 176 */       this.trace.add(trace);
/*     */     } 
/* 178 */     setLastUsed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void clearTrace() {
/* 186 */     if (this.trace != null) {
/* 187 */       this.trace.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List getTrace() {
/* 197 */     return this.trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace() {
/* 205 */     if (this.createdBy != null) {
/* 206 */       System.out.println(format.format(new Date(this.createdTime)));
/* 207 */       this.createdBy.printStackTrace(System.out);
/*     */     } 
/* 209 */     synchronized (this) {
/* 210 */       Iterator it = this.trace.iterator();
/* 211 */       while (it.hasNext()) {
/* 212 */         AbandonedTrace at = it.next();
/* 213 */         at.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void removeTrace(AbandonedTrace trace) {
/* 224 */     if (this.trace != null)
/* 225 */       this.trace.remove(trace); 
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\AbandonedTrace.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */