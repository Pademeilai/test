/*    */ package org.apache.commons.dbcp.datasources;
/*    */ 
/*    */ import javax.sql.PooledConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PooledConnectionAndInfo
/*    */ {
/*    */   private final PooledConnection pooledConnection;
/*    */   private final String password;
/*    */   private final String username;
/*    */   private final UserPassKey upkey;
/*    */   
/*    */   PooledConnectionAndInfo(PooledConnection pc, String username, String password) {
/* 33 */     this.pooledConnection = pc;
/* 34 */     this.username = username;
/* 35 */     this.password = password;
/* 36 */     this.upkey = new UserPassKey(username, password);
/*    */   }
/*    */   
/*    */   final PooledConnection getPooledConnection() {
/* 40 */     return this.pooledConnection;
/*    */   }
/*    */   
/*    */   final UserPassKey getUserPassKey() {
/* 44 */     return this.upkey;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final String getPassword() {
/* 52 */     return this.password;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final String getUsername() {
/* 60 */     return this.username;
/*    */   }
/*    */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\PooledConnectionAndInfo.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */