/*     */ package org.apache.commons.dbcp.datasources;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.sql.ConnectionEvent;
/*     */ import javax.sql.ConnectionEventListener;
/*     */ import javax.sql.ConnectionPoolDataSource;
/*     */ import javax.sql.PooledConnection;
/*     */ import org.apache.commons.dbcp.SQLNestedException;
/*     */ import org.apache.commons.pool.KeyedObjectPool;
/*     */ import org.apache.commons.pool.KeyedPoolableObjectFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KeyedCPDSConnectionFactory
/*     */   implements KeyedPoolableObjectFactory, ConnectionEventListener
/*     */ {
/*     */   private static final String NO_KEY_MESSAGE = "close() was called on a Connection, but I have no record of the underlying PooledConnection.";
/*  51 */   protected ConnectionPoolDataSource _cpds = null;
/*  52 */   protected String _validationQuery = null;
/*     */   protected boolean _rollbackAfterValidation = false;
/*  54 */   protected KeyedObjectPool _pool = null;
/*  55 */   private Map validatingMap = new HashMap();
/*  56 */   private WeakHashMap pcMap = new WeakHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyedCPDSConnectionFactory(ConnectionPoolDataSource cpds, KeyedObjectPool pool, String validationQuery) {
/*  67 */     this._cpds = cpds;
/*  68 */     this._pool = pool;
/*  69 */     this._pool.setFactory(this);
/*  70 */     this._validationQuery = validationQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyedCPDSConnectionFactory(ConnectionPoolDataSource cpds, KeyedObjectPool pool, String validationQuery, boolean rollbackAfterValidation) {
/*  88 */     this(cpds, pool, validationQuery);
/*  89 */     this._rollbackAfterValidation = rollbackAfterValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setCPDS(ConnectionPoolDataSource cpds) {
/*  97 */     this._cpds = cpds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setValidationQuery(String validationQuery) {
/* 107 */     this._validationQuery = validationQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setRollbackAfterValidation(boolean rollbackAfterValidation) {
/* 120 */     this._rollbackAfterValidation = rollbackAfterValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setPool(KeyedObjectPool pool) throws SQLException {
/* 129 */     if (null != this._pool && pool != this._pool) {
/*     */       try {
/* 131 */         this._pool.close();
/* 132 */       } catch (RuntimeException e) {
/* 133 */         throw e;
/* 134 */       } catch (Exception e) {
/* 135 */         throw new SQLNestedException("Cannot set the pool on this factory", e);
/*     */       } 
/*     */     }
/* 138 */     this._pool = pool;
/*     */   }
/*     */   
/*     */   public KeyedObjectPool getPool() {
/* 142 */     return this._pool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object makeObject(Object key) throws Exception {
/* 151 */     Object obj = null;
/* 152 */     UserPassKey upkey = (UserPassKey)key;
/*     */     
/* 154 */     PooledConnection pc = null;
/* 155 */     String username = upkey.getUsername();
/* 156 */     String password = upkey.getPassword();
/* 157 */     if (username == null) {
/* 158 */       pc = this._cpds.getPooledConnection();
/*     */     } else {
/* 160 */       pc = this._cpds.getPooledConnection(username, password);
/*     */     } 
/*     */ 
/*     */     
/* 164 */     pc.addConnectionEventListener(this);
/* 165 */     obj = new PooledConnectionAndInfo(pc, username, password);
/* 166 */     this.pcMap.put(pc, obj);
/*     */     
/* 168 */     return obj;
/*     */   }
/*     */   
/*     */   public void destroyObject(Object key, Object obj) throws Exception {
/* 172 */     if (obj instanceof PooledConnectionAndInfo) {
/* 173 */       PooledConnection pc = ((PooledConnectionAndInfo)obj).getPooledConnection();
/* 174 */       this.pcMap.remove(pc);
/* 175 */       pc.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean validateObject(Object key, Object obj) {
/* 180 */     boolean valid = false;
/* 181 */     if (obj instanceof PooledConnectionAndInfo) {
/* 182 */       PooledConnection pconn = ((PooledConnectionAndInfo)obj).getPooledConnection();
/*     */       
/* 184 */       String query = this._validationQuery;
/* 185 */       if (null != query) {
/* 186 */         Connection conn = null;
/* 187 */         Statement stmt = null;
/* 188 */         ResultSet rset = null;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 193 */         this.validatingMap.put(pconn, null);
/*     */         try {
/* 195 */           conn = pconn.getConnection();
/* 196 */           stmt = conn.createStatement();
/* 197 */           rset = stmt.executeQuery(query);
/* 198 */           if (rset.next()) {
/* 199 */             valid = true;
/*     */           } else {
/* 201 */             valid = false;
/*     */           } 
/* 203 */           if (this._rollbackAfterValidation) {
/* 204 */             conn.rollback();
/*     */           }
/* 206 */         } catch (Exception e) {
/* 207 */           valid = false;
/*     */         } finally {
/* 209 */           if (rset != null) {
/*     */             try {
/* 211 */               rset.close();
/* 212 */             } catch (Throwable t) {}
/*     */           }
/*     */ 
/*     */           
/* 216 */           if (stmt != null) {
/*     */             try {
/* 218 */               stmt.close();
/* 219 */             } catch (Throwable t) {}
/*     */           }
/*     */ 
/*     */           
/* 223 */           if (conn != null) {
/*     */             try {
/* 225 */               conn.close();
/* 226 */             } catch (Throwable t) {}
/*     */           }
/*     */ 
/*     */           
/* 230 */           this.validatingMap.remove(pconn);
/*     */         } 
/*     */       } else {
/* 233 */         valid = true;
/*     */       } 
/*     */     } else {
/* 236 */       valid = false;
/*     */     } 
/* 238 */     return valid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void passivateObject(Object key, Object obj) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void activateObject(Object key, Object obj) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionClosed(ConnectionEvent event) {
/* 258 */     PooledConnection pc = (PooledConnection)event.getSource();
/*     */ 
/*     */     
/* 261 */     if (!this.validatingMap.containsKey(pc)) {
/* 262 */       PooledConnectionAndInfo info = (PooledConnectionAndInfo)this.pcMap.get(pc);
/*     */       
/* 264 */       if (info == null) {
/* 265 */         throw new IllegalStateException("close() was called on a Connection, but I have no record of the underlying PooledConnection.");
/*     */       }
/*     */       try {
/* 268 */         this._pool.returnObject(info.getUserPassKey(), info);
/* 269 */       } catch (Exception e) {
/* 270 */         System.err.println("CLOSING DOWN CONNECTION AS IT COULD NOT BE RETURNED TO THE POOL");
/*     */         
/*     */         try {
/* 273 */           destroyObject(info.getUserPassKey(), info);
/* 274 */         } catch (Exception e2) {
/* 275 */           System.err.println("EXCEPTION WHILE DESTROYING OBJECT " + info);
/*     */           
/* 277 */           e2.printStackTrace();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionErrorOccurred(ConnectionEvent event) {
/* 288 */     PooledConnection pc = (PooledConnection)event.getSource();
/*     */     try {
/* 290 */       if (null != event.getSQLException()) {
/* 291 */         System.err.println("CLOSING DOWN CONNECTION DUE TO INTERNAL ERROR (" + event.getSQLException() + ")");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 297 */       pc.removeConnectionEventListener(this);
/* 298 */     } catch (Exception ignore) {}
/*     */ 
/*     */ 
/*     */     
/* 302 */     PooledConnectionAndInfo info = (PooledConnectionAndInfo)this.pcMap.get(pc);
/* 303 */     if (info == null) {
/* 304 */       throw new IllegalStateException("close() was called on a Connection, but I have no record of the underlying PooledConnection.");
/*     */     }
/*     */     try {
/* 307 */       destroyObject(info.getUserPassKey(), info);
/* 308 */     } catch (Exception e) {
/* 309 */       System.err.println("EXCEPTION WHILE DESTROYING OBJECT " + info);
/* 310 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\KeyedCPDSConnectionFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */