/*     */ package org.apache.commons.dbcp.datasources;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LRUMap
/*     */   extends SequencedHashMap
/*     */   implements Externalizable
/*     */ {
/*  58 */   private int maximumSize = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 2197433140769957051L;
/*     */ 
/*     */ 
/*     */   
/*     */   public LRUMap() {
/*  67 */     this(100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LRUMap(int i) {
/*  78 */     super(i);
/*  79 */     this.maximumSize = i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/*  95 */     if (!containsKey(key)) return null;
/*     */     
/*  97 */     Object value = remove(key);
/*  98 */     super.put(key, value);
/*  99 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 117 */     int mapSize = size();
/* 118 */     Object retval = null;
/*     */     
/* 120 */     if (mapSize >= this.maximumSize)
/*     */     {
/*     */ 
/*     */       
/* 124 */       if (!containsKey(key))
/*     */       {
/* 126 */         removeLRU();
/*     */       }
/*     */     }
/*     */     
/* 130 */     retval = super.put(key, value);
/*     */     
/* 132 */     return retval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeLRU() {
/* 140 */     Object key = getFirstKey();
/*     */ 
/*     */     
/* 143 */     Object value = super.get(key);
/*     */     
/* 145 */     remove(key);
/*     */     
/* 147 */     processRemovedLRU(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processRemovedLRU(Object key, Object value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 165 */     this.maximumSize = in.readInt();
/* 166 */     int size = in.readInt();
/*     */     
/* 168 */     for (int i = 0; i < size; i++) {
/* 169 */       Object key = in.readObject();
/* 170 */       Object value = in.readObject();
/* 171 */       put(key, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 176 */     out.writeInt(this.maximumSize);
/* 177 */     out.writeInt(size());
/* 178 */     for (Iterator iterator = keySet().iterator(); iterator.hasNext(); ) {
/* 179 */       Object key = iterator.next();
/* 180 */       out.writeObject(key);
/*     */ 
/*     */       
/* 183 */       Object value = super.get(key);
/* 184 */       out.writeObject(value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximumSize() {
/* 195 */     return this.maximumSize;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaximumSize(int maximumSize) {
/* 201 */     this.maximumSize = maximumSize;
/* 202 */     while (size() > maximumSize)
/* 203 */       removeLRU(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\LRUMap.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */