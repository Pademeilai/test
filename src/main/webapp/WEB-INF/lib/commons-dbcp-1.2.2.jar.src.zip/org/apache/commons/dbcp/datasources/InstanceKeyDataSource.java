/*     */ package org.apache.commons.dbcp.datasources;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Properties;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.Referenceable;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.sql.ConnectionPoolDataSource;
/*     */ import javax.sql.DataSource;
/*     */ import javax.sql.PooledConnection;
/*     */ import org.apache.commons.dbcp.SQLNestedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InstanceKeyDataSource
/*     */   implements DataSource, Referenceable, Serializable
/*     */ {
/*     */   private static final String GET_CONNECTION_CALLED = "A Connection was already requested from this source, further initialization is not allowed.";
/*     */   private static final String BAD_TRANSACTION_ISOLATION = "The requested TransactionIsolation level is invalid.";
/*     */   protected static final int UNKNOWN_TRANSACTIONISOLATION = -1;
/*     */   private boolean getConnectionCalled = false;
/*  99 */   private ConnectionPoolDataSource cpds = null;
/*     */   
/* 101 */   private String dataSourceName = null;
/*     */   private boolean defaultAutoCommit = false;
/* 103 */   private int defaultTransactionIsolation = -1;
/* 104 */   private int maxActive = 8;
/* 105 */   private int maxIdle = 8;
/* 106 */   private int maxWait = (int)Math.min(2147483647L, -1L);
/*     */   
/*     */   private boolean defaultReadOnly = false;
/*     */   
/* 110 */   private String description = null;
/*     */   
/* 112 */   Properties jndiEnvironment = null;
/*     */   
/* 114 */   private int loginTimeout = 0;
/*     */   
/* 116 */   private PrintWriter logWriter = null;
/*     */   private boolean _testOnBorrow = false;
/*     */   private boolean _testOnReturn = false;
/* 119 */   private int _timeBetweenEvictionRunsMillis = (int)Math.min(2147483647L, -1L);
/*     */ 
/*     */   
/* 122 */   private int _numTestsPerEvictionRun = 3;
/*     */   
/* 124 */   private int _minEvictableIdleTimeMillis = (int)Math.min(2147483647L, 1800000L);
/*     */   
/*     */   private boolean _testWhileIdle = false;
/*     */   
/* 128 */   private String validationQuery = null;
/*     */   
/*     */   private boolean rollbackAfterValidation = false;
/*     */   private boolean testPositionSet = false;
/* 132 */   protected String instanceKey = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstanceKeyDataSource() {
/* 138 */     this.defaultAutoCommit = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void assertInitializationAllowed() throws IllegalStateException {
/* 147 */     if (this.getConnectionCalled) {
/* 148 */       throw new IllegalStateException("A Connection was already requested from this source, further initialization is not allowed.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void close() throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionPoolDataSource getConnectionPoolDataSource() {
/* 167 */     return this.cpds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionPoolDataSource(ConnectionPoolDataSource v) {
/* 177 */     assertInitializationAllowed();
/* 178 */     if (this.dataSourceName != null) {
/* 179 */       throw new IllegalStateException("Cannot set the DataSource, if JNDI is used.");
/*     */     }
/*     */     
/* 182 */     if (this.cpds != null)
/*     */     {
/* 184 */       throw new IllegalStateException("The CPDS has already been set. It cannot be altered.");
/*     */     }
/*     */     
/* 187 */     this.cpds = v;
/* 188 */     this.instanceKey = InstanceKeyObjectFactory.registerNewInstance(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceName() {
/* 199 */     return this.dataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSourceName(String v) {
/* 210 */     assertInitializationAllowed();
/* 211 */     if (this.cpds != null) {
/* 212 */       throw new IllegalStateException("Cannot set the JNDI name for the DataSource, if already set using setConnectionPoolDataSource.");
/*     */     }
/*     */ 
/*     */     
/* 216 */     if (this.dataSourceName != null)
/*     */     {
/* 218 */       throw new IllegalStateException("The DataSourceName has already been set. It cannot be altered.");
/*     */     }
/*     */ 
/*     */     
/* 222 */     this.dataSourceName = v;
/* 223 */     this.instanceKey = InstanceKeyObjectFactory.registerNewInstance(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefaultAutoCommit() {
/* 235 */     return this.defaultAutoCommit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultAutoCommit(boolean v) {
/* 247 */     assertInitializationAllowed();
/* 248 */     this.defaultAutoCommit = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefaultReadOnly() {
/* 260 */     return this.defaultReadOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultReadOnly(boolean v) {
/* 272 */     assertInitializationAllowed();
/* 273 */     this.defaultReadOnly = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDefaultTransactionIsolation() {
/* 285 */     return this.defaultTransactionIsolation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultTransactionIsolation(int v) {
/* 297 */     assertInitializationAllowed();
/* 298 */     switch (v) {
/*     */       case 0:
/*     */       case 1:
/*     */       case 2:
/*     */       case 4:
/*     */       case 8:
/*     */         break;
/*     */       default:
/* 306 */         throw new IllegalArgumentException("The requested TransactionIsolation level is invalid.");
/*     */     } 
/* 308 */     this.defaultTransactionIsolation = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 319 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String v) {
/* 330 */     this.description = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJndiEnvironment(String key) {
/* 341 */     String value = null;
/* 342 */     if (this.jndiEnvironment != null) {
/* 343 */       value = this.jndiEnvironment.getProperty(key);
/*     */     }
/* 345 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJndiEnvironment(String key, String value) {
/* 357 */     if (this.jndiEnvironment == null) {
/* 358 */       this.jndiEnvironment = new Properties();
/*     */     }
/* 360 */     this.jndiEnvironment.setProperty(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLoginTimeout() {
/* 368 */     return this.loginTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginTimeout(int v) {
/* 376 */     this.loginTimeout = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getLogWriter() {
/* 384 */     if (this.logWriter == null) {
/* 385 */       this.logWriter = new PrintWriter(System.out);
/*     */     }
/* 387 */     return this.logWriter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogWriter(PrintWriter v) {
/* 395 */     this.logWriter = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isTestOnBorrow() {
/* 402 */     return getTestOnBorrow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getTestOnBorrow() {
/* 416 */     return this._testOnBorrow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTestOnBorrow(boolean testOnBorrow) {
/* 432 */     assertInitializationAllowed();
/* 433 */     this._testOnBorrow = testOnBorrow;
/* 434 */     this.testPositionSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isTestOnReturn() {
/* 441 */     return getTestOnReturn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getTestOnReturn() {
/* 453 */     return this._testOnReturn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTestOnReturn(boolean testOnReturn) {
/* 467 */     assertInitializationAllowed();
/* 468 */     this._testOnReturn = testOnReturn;
/* 469 */     this.testPositionSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTimeBetweenEvictionRunsMillis() {
/* 481 */     return this._timeBetweenEvictionRunsMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeBetweenEvictionRunsMillis(int timeBetweenEvictionRunsMillis) {
/* 494 */     assertInitializationAllowed();
/* 495 */     this._timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumTestsPerEvictionRun() {
/* 506 */     return this._numTestsPerEvictionRun;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumTestsPerEvictionRun(int numTestsPerEvictionRun) {
/* 521 */     assertInitializationAllowed();
/* 522 */     this._numTestsPerEvictionRun = numTestsPerEvictionRun;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinEvictableIdleTimeMillis() {
/* 534 */     return this._minEvictableIdleTimeMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMinEvictableIdleTimeMillis(int minEvictableIdleTimeMillis) {
/* 548 */     assertInitializationAllowed();
/* 549 */     this._minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isTestWhileIdle() {
/* 556 */     return getTestWhileIdle();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getTestWhileIdle() {
/* 569 */     return this._testWhileIdle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTestWhileIdle(boolean testWhileIdle) {
/* 585 */     assertInitializationAllowed();
/* 586 */     this._testWhileIdle = testWhileIdle;
/* 587 */     this.testPositionSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValidationQuery() {
/* 597 */     return this.validationQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidationQuery(String validationQuery) {
/* 608 */     assertInitializationAllowed();
/* 609 */     this.validationQuery = validationQuery;
/* 610 */     if (!this.testPositionSet) {
/* 611 */       setTestOnBorrow(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRollbackAfterValidation() {
/* 625 */     return this.rollbackAfterValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRollbackAfterValidation(boolean rollbackAfterValidation) {
/* 639 */     assertInitializationAllowed();
/* 640 */     this.rollbackAfterValidation = rollbackAfterValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 653 */     return getConnection(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/* 661 */     if (this.instanceKey == null) {
/* 662 */       throw new SQLException("Must set the ConnectionPoolDataSource through setDataSourceName or setConnectionPoolDataSource before calling getConnection.");
/*     */     }
/*     */ 
/*     */     
/* 666 */     this.getConnectionCalled = true;
/* 667 */     PooledConnectionAndInfo info = null;
/*     */     try {
/* 669 */       info = getPooledConnectionAndInfo(username, password);
/* 670 */     } catch (NoSuchElementException e) {
/* 671 */       closeDueToException(info);
/* 672 */       throw new SQLNestedException("Cannot borrow connection from pool", e);
/* 673 */     } catch (RuntimeException e) {
/* 674 */       closeDueToException(info);
/* 675 */       throw e;
/* 676 */     } catch (SQLException e) {
/* 677 */       closeDueToException(info);
/* 678 */       throw e;
/* 679 */     } catch (Exception e) {
/* 680 */       closeDueToException(info);
/* 681 */       throw new SQLNestedException("Cannot borrow connection from pool", e);
/*     */     } 
/*     */     
/* 684 */     if ((null == password) ? (null == info.getPassword()) : password.equals(info.getPassword())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 691 */       Connection con = info.getPooledConnection().getConnection();
/* 692 */       setupDefaults(con, username);
/* 693 */       con.clearWarnings();
/* 694 */       return con;
/*     */     } 
/*     */     closeDueToException(info);
/*     */     throw new SQLException("Given password did not match password used to create the PooledConnection.");
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract PooledConnectionAndInfo getPooledConnectionAndInfo(String paramString1, String paramString2) throws SQLException;
/*     */   
/*     */   protected abstract void setupDefaults(Connection paramConnection, String paramString) throws SQLException;
/*     */   
/*     */   private void closeDueToException(PooledConnectionAndInfo info) {
/* 706 */     if (info != null) {
/*     */       try {
/* 708 */         info.getPooledConnection().getConnection().close();
/* 709 */       } catch (Exception e) {
/*     */ 
/*     */ 
/*     */         
/* 713 */         getLogWriter().println("[ERROR] Could not return connection to pool during exception handling. " + e.getMessage());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConnectionPoolDataSource testCPDS(String username, String password) throws NamingException, SQLException {
/* 723 */     ConnectionPoolDataSource cpds = this.cpds;
/* 724 */     if (cpds == null) {
/* 725 */       Context ctx = null;
/* 726 */       if (this.jndiEnvironment == null) {
/* 727 */         ctx = new InitialContext();
/*     */       } else {
/* 729 */         ctx = new InitialContext(this.jndiEnvironment);
/*     */       } 
/* 731 */       Object ds = ctx.lookup(this.dataSourceName);
/* 732 */       if (ds instanceof ConnectionPoolDataSource) {
/* 733 */         cpds = (ConnectionPoolDataSource)ds;
/*     */       } else {
/* 735 */         throw new SQLException("Illegal configuration: DataSource " + this.dataSourceName + " (" + ds.getClass().getName() + ")" + " doesn't implement javax.sql.ConnectionPoolDataSource");
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 743 */     PooledConnection conn = null;
/*     */     try {
/* 745 */       if (username != null) {
/* 746 */         conn = cpds.getPooledConnection(username, password);
/*     */       } else {
/*     */         
/* 749 */         conn = cpds.getPooledConnection();
/*     */       } 
/* 751 */       if (conn == null) {
/* 752 */         throw new SQLException("Cannot connect using the supplied username/password");
/*     */       }
/*     */     }
/*     */     finally {
/*     */       
/* 757 */       if (conn != null) {
/*     */         try {
/* 759 */           conn.close();
/*     */         }
/* 761 */         catch (SQLException e) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 766 */     return cpds;
/*     */   }
/*     */   
/*     */   protected byte whenExhaustedAction(int maxActive, int maxWait) {
/* 770 */     byte whenExhausted = 1;
/* 771 */     if (maxActive <= 0) {
/* 772 */       whenExhausted = 2;
/* 773 */     } else if (maxWait == 0) {
/* 774 */       whenExhausted = 0;
/*     */     } 
/* 776 */     return whenExhausted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reference getReference() throws NamingException {
/* 797 */     String className = getClass().getName();
/* 798 */     String factoryName = className + "Factory";
/* 799 */     Reference ref = new Reference(className, factoryName, null);
/* 800 */     ref.add(new StringRefAddr("instanceKey", this.instanceKey));
/* 801 */     return ref;
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\InstanceKeyDataSource.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */