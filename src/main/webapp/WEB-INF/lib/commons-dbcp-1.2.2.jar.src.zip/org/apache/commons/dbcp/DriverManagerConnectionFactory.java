/*    */ package org.apache.commons.dbcp;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DriverManagerConnectionFactory
/*    */   implements ConnectionFactory
/*    */ {
/*    */   protected String _connectUri;
/*    */   protected String _uname;
/*    */   protected String _passwd;
/*    */   protected Properties _props;
/*    */   
/*    */   public DriverManagerConnectionFactory(String connectUri, Properties props) {
/* 72 */     this._connectUri = null;
/* 73 */     this._uname = null;
/* 74 */     this._passwd = null;
/* 75 */     this._props = null; this._connectUri = connectUri; this._props = props; } public DriverManagerConnectionFactory(String connectUri, String uname, String passwd) { this._connectUri = null; this._uname = null; this._passwd = null; this._props = null;
/*    */     this._connectUri = connectUri;
/*    */     this._uname = uname;
/*    */     this._passwd = passwd; }
/*    */ 
/*    */   
/*    */   public Connection createConnection() throws SQLException {
/*    */     if (null == this._props) {
/*    */       if (this._uname == null && this._passwd == null)
/*    */         return DriverManager.getConnection(this._connectUri); 
/*    */       return DriverManager.getConnection(this._connectUri, this._uname, this._passwd);
/*    */     } 
/*    */     return DriverManager.getConnection(this._connectUri, this._props);
/*    */   }
/*    */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\DriverManagerConnectionFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */