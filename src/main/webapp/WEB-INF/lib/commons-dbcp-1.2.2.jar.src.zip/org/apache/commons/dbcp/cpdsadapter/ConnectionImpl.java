/*     */ package org.apache.commons.dbcp.cpdsadapter;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConnectionImpl
/*     */   implements Connection
/*     */ {
/*     */   private static final String CLOSED = "Attempted to use Connection after closed() was called.";
/*     */   private Connection connection;
/*     */   private PooledConnectionImpl pooledConnection;
/*     */   boolean isClosed;
/*     */   
/*     */   ConnectionImpl(PooledConnectionImpl pooledConnection, Connection connection) {
/*  62 */     this.pooledConnection = pooledConnection;
/*  63 */     this.connection = connection;
/*  64 */     this.isClosed = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/*  71 */     if (!this.isClosed)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*  76 */       throw new SQLException("A ConnectionImpl was finalized without being closed which will cause leakage of  PooledConnections from the ConnectionPool.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void assertOpen() throws SQLException {
/*  86 */     if (this.isClosed) {
/*  87 */       throw new SQLException("Attempted to use Connection after closed() was called.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearWarnings() throws SQLException {
/* 102 */     assertOpen();
/* 103 */     this.connection.clearWarnings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/* 116 */     assertOpen();
/* 117 */     this.isClosed = true;
/* 118 */     this.pooledConnection.notifyListeners();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commit() throws SQLException {
/* 128 */     assertOpen();
/* 129 */     this.connection.commit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement() throws SQLException {
/* 139 */     assertOpen();
/* 140 */     return this.connection.createStatement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/* 152 */     assertOpen();
/* 153 */     return this.connection.createStatement(resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAutoCommit() throws SQLException {
/* 164 */     assertOpen();
/* 165 */     return this.connection.getAutoCommit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCatalog() throws SQLException {
/* 175 */     assertOpen();
/* 176 */     return this.connection.getCatalog();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatabaseMetaData getMetaData() throws SQLException {
/* 186 */     assertOpen();
/* 187 */     return this.connection.getMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTransactionIsolation() throws SQLException {
/* 197 */     assertOpen();
/* 198 */     return this.connection.getTransactionIsolation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map getTypeMap() throws SQLException {
/* 208 */     assertOpen();
/* 209 */     return this.connection.getTypeMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLWarning getWarnings() throws SQLException {
/* 219 */     assertOpen();
/* 220 */     return this.connection.getWarnings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 229 */     return this.isClosed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() throws SQLException {
/* 239 */     assertOpen();
/* 240 */     return this.connection.isReadOnly();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nativeSQL(String sql) throws SQLException {
/* 250 */     assertOpen();
/* 251 */     return this.connection.nativeSQL(sql);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String sql) throws SQLException {
/* 261 */     assertOpen();
/* 262 */     return this.connection.prepareCall(sql);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 274 */     assertOpen();
/* 275 */     return this.connection.prepareCall(sql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql) throws SQLException {
/* 287 */     assertOpen();
/* 288 */     return this.pooledConnection.prepareStatement(sql);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 302 */     assertOpen();
/* 303 */     return this.pooledConnection.prepareStatement(sql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback() throws SQLException {
/* 314 */     assertOpen();
/* 315 */     this.connection.rollback();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoCommit(boolean b) throws SQLException {
/* 325 */     assertOpen();
/* 326 */     this.connection.setAutoCommit(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalog(String catalog) throws SQLException {
/* 336 */     assertOpen();
/* 337 */     this.connection.setCatalog(catalog);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadOnly(boolean readOnly) throws SQLException {
/* 347 */     assertOpen();
/* 348 */     this.connection.setReadOnly(readOnly);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionIsolation(int level) throws SQLException {
/* 358 */     assertOpen();
/* 359 */     this.connection.setTransactionIsolation(level);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeMap(Map map) throws SQLException {
/* 369 */     assertOpen();
/* 370 */     this.connection.setTypeMap(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHoldability() throws SQLException {
/* 379 */     assertOpen();
/* 380 */     return this.connection.getHoldability();
/*     */   }
/*     */   
/*     */   public void setHoldability(int holdability) throws SQLException {
/* 384 */     assertOpen();
/* 385 */     this.connection.setHoldability(holdability);
/*     */   }
/*     */   
/*     */   public Savepoint setSavepoint() throws SQLException {
/* 389 */     assertOpen();
/* 390 */     return this.connection.setSavepoint();
/*     */   }
/*     */   
/*     */   public Savepoint setSavepoint(String name) throws SQLException {
/* 394 */     assertOpen();
/* 395 */     return this.connection.setSavepoint(name);
/*     */   }
/*     */   
/*     */   public void rollback(Savepoint savepoint) throws SQLException {
/* 399 */     assertOpen();
/* 400 */     this.connection.rollback(savepoint);
/*     */   }
/*     */ 
/*     */   
/*     */   public void releaseSavepoint(Savepoint savepoint) throws SQLException {
/* 405 */     assertOpen();
/* 406 */     this.connection.releaseSavepoint(savepoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 413 */     assertOpen();
/* 414 */     return this.connection.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 422 */     assertOpen();
/* 423 */     return this.connection.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 432 */     assertOpen();
/* 433 */     return this.connection.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException {
/* 440 */     assertOpen();
/* 441 */     return this.connection.prepareStatement(sql, autoGeneratedKeys);
/*     */   }
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException {
/* 446 */     assertOpen();
/* 447 */     return this.connection.prepareStatement(sql, columnIndexes);
/*     */   }
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException {
/* 452 */     assertOpen();
/* 453 */     return this.connection.prepareStatement(sql, columnNames);
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\cpdsadapter\ConnectionImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */