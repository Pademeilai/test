/*     */ package org.apache.commons.dbcp.datasources;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class InstanceKeyObjectFactory
/*     */   implements ObjectFactory
/*     */ {
/*  45 */   private static Map instanceMap = new HashMap();
/*     */   
/*     */   static synchronized String registerNewInstance(InstanceKeyDataSource ds) {
/*  48 */     int max = 0;
/*  49 */     Iterator i = instanceMap.keySet().iterator();
/*  50 */     while (i.hasNext()) {
/*  51 */       Object obj = i.next();
/*  52 */       if (obj instanceof String) {
/*     */         
/*     */         try {
/*  55 */           max = Math.max(max, Integer.valueOf((String)obj).intValue());
/*     */         }
/*  57 */         catch (NumberFormatException e) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  62 */     String instanceKey = String.valueOf(max + 1);
/*     */ 
/*     */     
/*  65 */     instanceMap.put(instanceKey, ds);
/*  66 */     return instanceKey;
/*     */   }
/*     */ 
/*     */   
/*     */   static void removeInstance(String key) {
/*  71 */     instanceMap.remove(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeAll() throws Exception {
/*  79 */     Iterator instanceIterator = instanceMap.entrySet().iterator();
/*  80 */     while (instanceIterator.hasNext()) {
/*  81 */       ((InstanceKeyDataSource)((Map.Entry)instanceIterator.next()).getValue()).close();
/*     */     }
/*     */     
/*  84 */     instanceMap.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObjectInstance(Object refObj, Name name, Context context, Hashtable env) throws IOException, ClassNotFoundException {
/*  97 */     Object obj = null;
/*  98 */     if (refObj instanceof Reference) {
/*  99 */       Reference ref = (Reference)refObj;
/* 100 */       if (isCorrectClass(ref.getClassName())) {
/* 101 */         RefAddr ra = ref.get("instanceKey");
/* 102 */         if (ra != null && ra.getContent() != null) {
/*     */           
/* 104 */           obj = instanceMap.get(ra.getContent());
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 111 */           String key = null;
/* 112 */           if (name != null) {
/*     */             
/* 114 */             key = name.toString();
/* 115 */             obj = instanceMap.get(key);
/*     */           } 
/* 117 */           if (obj == null) {
/*     */             
/* 119 */             InstanceKeyDataSource ds = getNewInstance(ref);
/* 120 */             setCommonProperties(ref, ds);
/* 121 */             obj = ds;
/* 122 */             if (key != null)
/*     */             {
/* 124 */               instanceMap.put(key, ds);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 130 */     return obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setCommonProperties(Reference ref, InstanceKeyDataSource ikds) throws IOException, ClassNotFoundException {
/* 137 */     RefAddr ra = ref.get("dataSourceName");
/* 138 */     if (ra != null && ra.getContent() != null) {
/* 139 */       ikds.setDataSourceName(ra.getContent().toString());
/*     */     }
/*     */     
/* 142 */     ra = ref.get("defaultAutoCommit");
/* 143 */     if (ra != null && ra.getContent() != null) {
/* 144 */       ikds.setDefaultAutoCommit(Boolean.valueOf(ra.getContent().toString()).booleanValue());
/*     */     }
/*     */ 
/*     */     
/* 148 */     ra = ref.get("defaultReadOnly");
/* 149 */     if (ra != null && ra.getContent() != null) {
/* 150 */       ikds.setDefaultReadOnly(Boolean.valueOf(ra.getContent().toString()).booleanValue());
/*     */     }
/*     */ 
/*     */     
/* 154 */     ra = ref.get("description");
/* 155 */     if (ra != null && ra.getContent() != null) {
/* 156 */       ikds.setDescription(ra.getContent().toString());
/*     */     }
/*     */     
/* 159 */     ra = ref.get("jndiEnvironment");
/* 160 */     if (ra != null && ra.getContent() != null) {
/* 161 */       byte[] serialized = (byte[])ra.getContent();
/* 162 */       ikds.jndiEnvironment = (Properties)deserialize(serialized);
/*     */     } 
/*     */ 
/*     */     
/* 166 */     ra = ref.get("loginTimeout");
/* 167 */     if (ra != null && ra.getContent() != null) {
/* 168 */       ikds.setLoginTimeout(Integer.parseInt(ra.getContent().toString()));
/*     */     }
/*     */ 
/*     */     
/* 172 */     ra = ref.get("testOnBorrow");
/* 173 */     if (ra != null && ra.getContent() != null) {
/* 174 */       ikds.setTestOnBorrow(Boolean.getBoolean(ra.getContent().toString()));
/*     */     }
/*     */ 
/*     */     
/* 178 */     ra = ref.get("testOnReturn");
/* 179 */     if (ra != null && ra.getContent() != null) {
/* 180 */       ikds.setTestOnReturn(Boolean.valueOf(ra.getContent().toString()).booleanValue());
/*     */     }
/*     */ 
/*     */     
/* 184 */     ra = ref.get("timeBetweenEvictionRunsMillis");
/* 185 */     if (ra != null && ra.getContent() != null) {
/* 186 */       ikds.setTimeBetweenEvictionRunsMillis(Integer.parseInt(ra.getContent().toString()));
/*     */     }
/*     */ 
/*     */     
/* 190 */     ra = ref.get("numTestsPerEvictionRun");
/* 191 */     if (ra != null && ra.getContent() != null) {
/* 192 */       ikds.setNumTestsPerEvictionRun(Integer.parseInt(ra.getContent().toString()));
/*     */     }
/*     */ 
/*     */     
/* 196 */     ra = ref.get("minEvictableIdleTimeMillis");
/* 197 */     if (ra != null && ra.getContent() != null) {
/* 198 */       ikds.setMinEvictableIdleTimeMillis(Integer.parseInt(ra.getContent().toString()));
/*     */     }
/*     */ 
/*     */     
/* 202 */     ra = ref.get("testWhileIdle");
/* 203 */     if (ra != null && ra.getContent() != null) {
/* 204 */       ikds.setTestWhileIdle(Boolean.valueOf(ra.getContent().toString()).booleanValue());
/*     */     }
/*     */ 
/*     */     
/* 208 */     ra = ref.get("validationQuery");
/* 209 */     if (ra != null && ra.getContent() != null) {
/* 210 */       ikds.setValidationQuery(ra.getContent().toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean isCorrectClass(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract InstanceKeyDataSource getNewInstance(Reference paramReference) throws IOException, ClassNotFoundException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final Object deserialize(byte[] data) throws IOException, ClassNotFoundException {
/* 233 */     ObjectInputStream in = null;
/*     */     try {
/* 235 */       in = new ObjectInputStream(new ByteArrayInputStream(data));
/* 236 */       return in.readObject();
/*     */     } finally {
/* 238 */       if (in != null)
/*     */         try {
/* 240 */           in.close();
/* 241 */         } catch (IOException ex) {} 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\InstanceKeyObjectFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */