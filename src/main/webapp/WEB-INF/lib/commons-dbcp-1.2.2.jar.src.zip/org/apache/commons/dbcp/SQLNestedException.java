/*    */ package org.apache.commons.dbcp;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.lang.reflect.Method;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLNestedException
/*    */   extends SQLException
/*    */ {
/*    */   private static final Method THROWABLE_CAUSE_METHOD;
/*    */   
/*    */   static {
/*    */     Method getCauseMethod;
/*    */     try {
/* 39 */       getCauseMethod = Throwable.class.getMethod("getCause", (Class[])null);
/* 40 */     } catch (Exception e) {
/* 41 */       getCauseMethod = null;
/*    */     } 
/* 43 */     THROWABLE_CAUSE_METHOD = getCauseMethod;
/*    */   }
/*    */   
/*    */   private static boolean hasThrowableCauseMethod() {
/* 47 */     return (THROWABLE_CAUSE_METHOD != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   private Throwable cause = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SQLNestedException(String msg, Throwable cause) {
/* 65 */     super(msg);
/* 66 */     this.cause = cause;
/* 67 */     if (cause != null && DriverManager.getLogWriter() != null) {
/* 68 */       DriverManager.getLogWriter().print("Caused by: ");
/* 69 */       cause.printStackTrace(DriverManager.getLogWriter());
/*    */     } 
/*    */   }
/*    */   
/*    */   public Throwable getCause() {
/* 74 */     return this.cause;
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintStream s) {
/* 78 */     super.printStackTrace(s);
/* 79 */     if (this.cause != null && !hasThrowableCauseMethod()) {
/* 80 */       s.print("Caused by: ");
/* 81 */       this.cause.printStackTrace(s);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintWriter s) {
/* 86 */     super.printStackTrace(s);
/* 87 */     if (this.cause != null && !hasThrowableCauseMethod()) {
/* 88 */       s.print("Caused by: ");
/* 89 */       this.cause.printStackTrace(s);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\SQLNestedException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */