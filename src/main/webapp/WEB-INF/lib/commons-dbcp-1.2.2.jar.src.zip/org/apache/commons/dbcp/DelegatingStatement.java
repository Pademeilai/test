/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingStatement
/*     */   extends AbandonedTrace
/*     */   implements Statement
/*     */ {
/*  48 */   protected Statement _stmt = null;
/*     */   
/*  50 */   protected DelegatingConnection _conn = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _closed;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingStatement(DelegatingConnection c, Statement s) {
/*  61 */     super(c);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     this._closed = false; this._stmt = s; this._conn = c;
/*     */   }
/*     */   public Statement getDelegate() { return this._stmt; } public boolean equals(Object obj) { Statement delegate = getInnermostDelegate(); if (delegate == null)
/* 132 */       return false;  if (obj instanceof DelegatingStatement) { DelegatingStatement s = (DelegatingStatement)obj; return delegate.equals(s.getInnermostDelegate()); }  return delegate.equals(obj); } protected boolean isClosed() { return this._closed; }
/*     */   public int hashCode() { Object obj = getInnermostDelegate(); if (obj == null) return 0;  return obj.hashCode(); }
/*     */   public Statement getInnermostDelegate() { Statement s = this._stmt; while (s != null && s instanceof DelegatingStatement) { s = ((DelegatingStatement)s).getDelegate(); if (this == s)
/*     */         return null;  }  return s; }
/* 136 */   public void setDelegate(Statement s) { this._stmt = s; } protected void checkOpen() throws SQLException { if (isClosed()) {
/* 137 */       throw new SQLException(getClass().getName() + " with address: \"" + toString() + "\" is closed.");
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/*     */     try {
/*     */       try {
/* 150 */         if (this._conn != null) {
/* 151 */           this._conn.removeTrace(this);
/* 152 */           this._conn = null;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 159 */         List resultSets = getTrace();
/* 160 */         if (resultSets != null) {
/* 161 */           ResultSet[] set = (ResultSet[])resultSets.toArray((Object[])new ResultSet[resultSets.size()]);
/* 162 */           for (int i = 0; i < set.length; i++) {
/* 163 */             set[i].close();
/*     */           }
/* 165 */           clearTrace();
/*     */         } 
/*     */         
/* 168 */         this._stmt.close();
/*     */       }
/* 170 */       catch (SQLException e) {
/* 171 */         handleException(e);
/*     */       } 
/*     */     } finally {
/*     */       
/* 175 */       this._closed = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void handleException(SQLException e) throws SQLException {
/* 180 */     if (this._conn != null) {
/* 181 */       this._conn.handleException(e);
/*     */     } else {
/*     */       
/* 184 */       throw e;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void activate() throws SQLException {
/* 189 */     if (this._stmt instanceof DelegatingStatement) {
/* 190 */       ((DelegatingStatement)this._stmt).activate();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void passivate() throws SQLException {
/* 195 */     if (this._stmt instanceof DelegatingStatement) {
/* 196 */       ((DelegatingStatement)this._stmt).passivate();
/*     */     }
/*     */   }
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 201 */     checkOpen();
/* 202 */     return this._conn;
/*     */   }
/*     */   
/*     */   public ResultSet executeQuery(String sql) throws SQLException {
/* 206 */     checkOpen();
/*     */     try {
/* 208 */       return DelegatingResultSet.wrapResultSet(this, this._stmt.executeQuery(sql));
/*     */     }
/* 210 */     catch (SQLException e) {
/* 211 */       handleException(e);
/* 212 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ResultSet getResultSet() throws SQLException {
/* 217 */     checkOpen();
/*     */     try {
/* 219 */       return DelegatingResultSet.wrapResultSet(this, this._stmt.getResultSet());
/*     */     }
/* 221 */     catch (SQLException e) {
/* 222 */       handleException(e);
/* 223 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql) throws SQLException {
/* 228 */     checkOpen(); try { return this._stmt.executeUpdate(sql); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public int getMaxFieldSize() throws SQLException {
/* 231 */     checkOpen(); try { return this._stmt.getMaxFieldSize(); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public void setMaxFieldSize(int max) throws SQLException {
/* 234 */     checkOpen(); try { this._stmt.setMaxFieldSize(max); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public int getMaxRows() throws SQLException {
/* 237 */     checkOpen(); try { return this._stmt.getMaxRows(); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public void setMaxRows(int max) throws SQLException {
/* 240 */     checkOpen(); try { this._stmt.setMaxRows(max); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setEscapeProcessing(boolean enable) throws SQLException {
/* 243 */     checkOpen(); try { this._stmt.setEscapeProcessing(enable); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public int getQueryTimeout() throws SQLException {
/* 246 */     checkOpen(); try { return this._stmt.getQueryTimeout(); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public void setQueryTimeout(int seconds) throws SQLException {
/* 249 */     checkOpen(); try { this._stmt.setQueryTimeout(seconds); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void cancel() throws SQLException {
/* 252 */     checkOpen(); try { this._stmt.cancel(); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public SQLWarning getWarnings() throws SQLException {
/* 255 */     checkOpen(); try { return this._stmt.getWarnings(); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   } public void clearWarnings() throws SQLException {
/* 258 */     checkOpen(); try { this._stmt.clearWarnings(); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void setCursorName(String name) throws SQLException {
/* 261 */     checkOpen(); try { this._stmt.setCursorName(name); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public boolean execute(String sql) throws SQLException {
/* 264 */     checkOpen(); try { return this._stmt.execute(sql); } catch (SQLException e) { handleException(e); return false; }
/*     */   
/*     */   } public int getUpdateCount() throws SQLException {
/* 267 */     checkOpen(); try { return this._stmt.getUpdateCount(); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public boolean getMoreResults() throws SQLException {
/* 270 */     checkOpen(); try { return this._stmt.getMoreResults(); } catch (SQLException e) { handleException(e); return false; }
/*     */   
/*     */   } public void setFetchDirection(int direction) throws SQLException {
/* 273 */     checkOpen(); try { this._stmt.setFetchDirection(direction); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public int getFetchDirection() throws SQLException {
/* 276 */     checkOpen(); try { return this._stmt.getFetchDirection(); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public void setFetchSize(int rows) throws SQLException {
/* 279 */     checkOpen(); try { this._stmt.setFetchSize(rows); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public int getFetchSize() throws SQLException {
/* 282 */     checkOpen(); try { return this._stmt.getFetchSize(); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public int getResultSetConcurrency() throws SQLException {
/* 285 */     checkOpen(); try { return this._stmt.getResultSetConcurrency(); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public int getResultSetType() throws SQLException {
/* 288 */     checkOpen(); try { return this._stmt.getResultSetType(); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public void addBatch(String sql) throws SQLException {
/* 291 */     checkOpen(); try { this._stmt.addBatch(sql); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public void clearBatch() throws SQLException {
/* 294 */     checkOpen(); try { this._stmt.clearBatch(); } catch (SQLException e) { handleException(e); }
/*     */   
/*     */   } public int[] executeBatch() throws SQLException {
/* 297 */     checkOpen(); try { return this._stmt.executeBatch(); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 306 */     return this._stmt.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getMoreResults(int current) throws SQLException {
/* 315 */     checkOpen(); try { return this._stmt.getMoreResults(current); } catch (SQLException e) { handleException(e); return false; }
/*     */   
/*     */   } public ResultSet getGeneratedKeys() throws SQLException {
/* 318 */     checkOpen(); try { return this._stmt.getGeneratedKeys(); } catch (SQLException e) { handleException(e); return null; }
/*     */   
/*     */   } public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
/* 321 */     checkOpen(); try { return this._stmt.executeUpdate(sql, autoGeneratedKeys); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public int executeUpdate(String sql, int[] columnIndexes) throws SQLException {
/* 324 */     checkOpen(); try { return this._stmt.executeUpdate(sql, columnIndexes); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public int executeUpdate(String sql, String[] columnNames) throws SQLException {
/* 327 */     checkOpen(); try { return this._stmt.executeUpdate(sql, columnNames); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   } public boolean execute(String sql, int autoGeneratedKeys) throws SQLException {
/* 330 */     checkOpen(); try { return this._stmt.execute(sql, autoGeneratedKeys); } catch (SQLException e) { handleException(e); return false; }
/*     */   
/*     */   } public boolean execute(String sql, int[] columnIndexes) throws SQLException {
/* 333 */     checkOpen(); try { return this._stmt.execute(sql, columnIndexes); } catch (SQLException e) { handleException(e); return false; }
/*     */   
/*     */   } public boolean execute(String sql, String[] columnNames) throws SQLException {
/* 336 */     checkOpen(); try { return this._stmt.execute(sql, columnNames); } catch (SQLException e) { handleException(e); return false; }
/*     */   
/*     */   } public int getResultSetHoldability() throws SQLException {
/* 339 */     checkOpen(); try { return this._stmt.getResultSetHoldability(); } catch (SQLException e) { handleException(e); return 0; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\DelegatingStatement.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */