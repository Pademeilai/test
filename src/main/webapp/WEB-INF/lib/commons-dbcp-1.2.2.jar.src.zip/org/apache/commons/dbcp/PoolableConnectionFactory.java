/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import org.apache.commons.pool.KeyedObjectPool;
/*     */ import org.apache.commons.pool.KeyedObjectPoolFactory;
/*     */ import org.apache.commons.pool.ObjectPool;
/*     */ import org.apache.commons.pool.PoolableObjectFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoolableConnectionFactory
/*     */   implements PoolableObjectFactory
/*     */ {
/*     */   protected ConnectionFactory _connFactory;
/*     */   protected String _validationQuery;
/*     */   protected ObjectPool _pool;
/*     */   protected KeyedObjectPoolFactory _stmtPoolFactory;
/*     */   protected Boolean _defaultReadOnly;
/*     */   protected boolean _defaultAutoCommit;
/*     */   protected int _defaultTransactionIsolation;
/*     */   protected String _defaultCatalog;
/*     */   protected AbandonedConfig _config;
/*     */   static final int UNKNOWN_TRANSACTIONISOLATION = -1;
/*     */   
/*     */   public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, boolean defaultReadOnly, boolean defaultAutoCommit) {
/* 396 */     this._connFactory = null;
/* 397 */     this._validationQuery = null;
/* 398 */     this._pool = null;
/* 399 */     this._stmtPoolFactory = null;
/* 400 */     this._defaultReadOnly = null;
/* 401 */     this._defaultAutoCommit = true;
/* 402 */     this._defaultTransactionIsolation = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 408 */     this._config = null; this._connFactory = connFactory; this._pool = pool; this._pool.setFactory(this); this._stmtPoolFactory = stmtPoolFactory; this._validationQuery = validationQuery; this._defaultReadOnly = defaultReadOnly ? Boolean.TRUE : Boolean.FALSE; this._defaultAutoCommit = defaultAutoCommit; } public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, boolean defaultReadOnly, boolean defaultAutoCommit, int defaultTransactionIsolation) { this._connFactory = null; this._validationQuery = null; this._pool = null; this._stmtPoolFactory = null; this._defaultReadOnly = null; this._defaultAutoCommit = true; this._defaultTransactionIsolation = -1; this._config = null; this._connFactory = connFactory; this._pool = pool; this._pool.setFactory(this); this._stmtPoolFactory = stmtPoolFactory; this._validationQuery = validationQuery; this._defaultReadOnly = defaultReadOnly ? Boolean.TRUE : Boolean.FALSE; this._defaultAutoCommit = defaultAutoCommit; this._defaultTransactionIsolation = defaultTransactionIsolation; } public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, boolean defaultReadOnly, boolean defaultAutoCommit, AbandonedConfig config) { this._connFactory = null; this._validationQuery = null; this._pool = null; this._stmtPoolFactory = null; this._defaultReadOnly = null; this._defaultAutoCommit = true; this._defaultTransactionIsolation = -1; this._config = null; this._connFactory = connFactory; this._pool = pool; this._config = config; this._pool.setFactory(this); this._stmtPoolFactory = stmtPoolFactory; this._validationQuery = validationQuery; this._defaultReadOnly = defaultReadOnly ? Boolean.TRUE : Boolean.FALSE; this._defaultAutoCommit = defaultAutoCommit; } public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, boolean defaultReadOnly, boolean defaultAutoCommit, int defaultTransactionIsolation, AbandonedConfig config) { this._connFactory = null; this._validationQuery = null; this._pool = null; this._stmtPoolFactory = null; this._defaultReadOnly = null; this._defaultAutoCommit = true; this._defaultTransactionIsolation = -1; this._config = null; this._connFactory = connFactory; this._pool = pool; this._config = config; this._pool.setFactory(this); this._stmtPoolFactory = stmtPoolFactory; this._validationQuery = validationQuery; this._defaultReadOnly = defaultReadOnly ? Boolean.TRUE : Boolean.FALSE; this._defaultAutoCommit = defaultAutoCommit; this._defaultTransactionIsolation = defaultTransactionIsolation; } public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, boolean defaultReadOnly, boolean defaultAutoCommit, int defaultTransactionIsolation, String defaultCatalog, AbandonedConfig config) { this._connFactory = null; this._validationQuery = null; this._pool = null; this._stmtPoolFactory = null; this._defaultReadOnly = null; this._defaultAutoCommit = true; this._defaultTransactionIsolation = -1; this._config = null; this._connFactory = connFactory; this._pool = pool; this._config = config; this._pool.setFactory(this); this._stmtPoolFactory = stmtPoolFactory; this._validationQuery = validationQuery; this._defaultReadOnly = defaultReadOnly ? Boolean.TRUE : Boolean.FALSE; this._defaultAutoCommit = defaultAutoCommit; this._defaultTransactionIsolation = defaultTransactionIsolation; this._defaultCatalog = defaultCatalog; } public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, Boolean defaultReadOnly, boolean defaultAutoCommit, int defaultTransactionIsolation, String defaultCatalog, AbandonedConfig config) { this._connFactory = null; this._validationQuery = null; this._pool = null; this._stmtPoolFactory = null; this._defaultReadOnly = null; this._defaultAutoCommit = true; this._defaultTransactionIsolation = -1; this._config = null;
/*     */     this._connFactory = connFactory;
/*     */     this._pool = pool;
/*     */     this._config = config;
/*     */     this._pool.setFactory(this);
/*     */     this._stmtPoolFactory = stmtPoolFactory;
/*     */     this._validationQuery = validationQuery;
/*     */     this._defaultReadOnly = defaultReadOnly;
/*     */     this._defaultAutoCommit = defaultAutoCommit;
/*     */     this._defaultTransactionIsolation = defaultTransactionIsolation;
/*     */     this._defaultCatalog = defaultCatalog; }
/*     */ 
/*     */   
/*     */   public synchronized void setConnectionFactory(ConnectionFactory connFactory) {
/*     */     this._connFactory = connFactory;
/*     */   }
/*     */   
/*     */   public synchronized void setValidationQuery(String validationQuery) {
/*     */     this._validationQuery = validationQuery;
/*     */   }
/*     */   
/*     */   public synchronized void setPool(ObjectPool pool) {
/*     */     if (null != this._pool && pool != this._pool)
/*     */       try {
/*     */         this._pool.close();
/*     */       } catch (Exception e) {} 
/*     */     this._pool = pool;
/*     */   }
/*     */   
/*     */   public ObjectPool getPool() {
/*     */     return this._pool;
/*     */   }
/*     */   
/*     */   public synchronized void setStatementPoolFactory(KeyedObjectPoolFactory stmtPoolFactory) {
/*     */     this._stmtPoolFactory = stmtPoolFactory;
/*     */   }
/*     */   
/*     */   public void setDefaultReadOnly(boolean defaultReadOnly) {
/*     */     this._defaultReadOnly = defaultReadOnly ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */   
/*     */   public void setDefaultAutoCommit(boolean defaultAutoCommit) {
/*     */     this._defaultAutoCommit = defaultAutoCommit;
/*     */   }
/*     */   
/*     */   public void setDefaultTransactionIsolation(int defaultTransactionIsolation) {
/*     */     this._defaultTransactionIsolation = defaultTransactionIsolation;
/*     */   }
/*     */   
/*     */   public void setDefaultCatalog(String defaultCatalog) {
/*     */     this._defaultCatalog = defaultCatalog;
/*     */   }
/*     */   
/*     */   public synchronized Object makeObject() throws Exception {
/*     */     Connection conn = this._connFactory.createConnection();
/*     */     if (null != this._stmtPoolFactory) {
/*     */       KeyedObjectPool stmtpool = this._stmtPoolFactory.createPool();
/*     */       conn = new PoolingConnection(conn, stmtpool);
/*     */       stmtpool.setFactory((PoolingConnection)conn);
/*     */     } 
/*     */     return new PoolableConnection(conn, this._pool, this._config);
/*     */   }
/*     */   
/*     */   public void destroyObject(Object obj) throws Exception {
/*     */     if (obj instanceof PoolableConnection)
/*     */       ((PoolableConnection)obj).reallyClose(); 
/*     */   }
/*     */   
/*     */   public boolean validateObject(Object obj) {
/*     */     if (obj instanceof Connection)
/*     */       try {
/*     */         validateConnection((Connection)obj);
/*     */         return true;
/*     */       } catch (Exception e) {
/*     */         return false;
/*     */       }  
/*     */     return false;
/*     */   }
/*     */   
/*     */   public void validateConnection(Connection conn) throws SQLException {
/*     */     String query = this._validationQuery;
/*     */     if (conn.isClosed())
/*     */       throw new SQLException("validateConnection: connection closed"); 
/*     */     if (null != query) {
/*     */       Statement stmt = null;
/*     */       ResultSet rset = null;
/*     */       try {
/*     */         stmt = conn.createStatement();
/*     */         rset = stmt.executeQuery(query);
/*     */         if (!rset.next())
/*     */           throw new SQLException("validationQuery didn't return a row"); 
/*     */       } finally {
/*     */         if (rset != null)
/*     */           try {
/*     */             rset.close();
/*     */           } catch (Exception t) {} 
/*     */         if (stmt != null)
/*     */           try {
/*     */             stmt.close();
/*     */           } catch (Exception t) {} 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void passivateObject(Object obj) throws Exception {
/*     */     if (obj instanceof Connection) {
/*     */       Connection conn = (Connection)obj;
/*     */       if (!conn.getAutoCommit() && !conn.isReadOnly())
/*     */         conn.rollback(); 
/*     */       conn.clearWarnings();
/*     */       if (!conn.getAutoCommit())
/*     */         conn.setAutoCommit(true); 
/*     */     } 
/*     */     if (obj instanceof DelegatingConnection)
/*     */       ((DelegatingConnection)obj).passivate(); 
/*     */   }
/*     */   
/*     */   public void activateObject(Object obj) throws Exception {
/*     */     if (obj instanceof DelegatingConnection)
/*     */       ((DelegatingConnection)obj).activate(); 
/*     */     if (obj instanceof Connection) {
/*     */       Connection conn = (Connection)obj;
/*     */       if (conn.getAutoCommit() != this._defaultAutoCommit)
/*     */         conn.setAutoCommit(this._defaultAutoCommit); 
/*     */       if (this._defaultTransactionIsolation != -1 && conn.getTransactionIsolation() != this._defaultTransactionIsolation)
/*     */         conn.setTransactionIsolation(this._defaultTransactionIsolation); 
/*     */       if (this._defaultReadOnly != null && conn.isReadOnly() != this._defaultReadOnly.booleanValue())
/*     */         conn.setReadOnly(this._defaultReadOnly.booleanValue()); 
/*     */       if (this._defaultCatalog != null && !this._defaultCatalog.equals(conn.getCatalog()))
/*     */         conn.setCatalog(this._defaultCatalog); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\PoolableConnectionFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */