/*    */ package org.apache.commons.dbcp;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.Driver;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DriverConnectionFactory
/*    */   implements ConnectionFactory
/*    */ {
/*    */   protected Driver _driver;
/*    */   protected String _connectUri;
/*    */   protected Properties _props;
/*    */   
/*    */   public DriverConnectionFactory(Driver driver, String connectUri, Properties props) {
/* 41 */     this._driver = null;
/* 42 */     this._connectUri = null;
/* 43 */     this._props = null;
/*    */     this._driver = driver;
/*    */     this._connectUri = connectUri;
/* 46 */     this._props = props; } public String toString() { return getClass().getName() + " [" + String.valueOf(this._driver) + ";" + String.valueOf(this._connectUri) + ";" + String.valueOf(this._props) + "]"; }
/*    */ 
/*    */   
/*    */   public Connection createConnection() throws SQLException {
/*    */     return this._driver.connect(this._connectUri, this._props);
/*    */   }
/*    */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\DriverConnectionFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */