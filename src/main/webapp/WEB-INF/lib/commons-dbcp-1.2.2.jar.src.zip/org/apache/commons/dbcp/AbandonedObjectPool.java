/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.pool.PoolableObjectFactory;
/*     */ import org.apache.commons.pool.impl.GenericObjectPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbandonedObjectPool
/*     */   extends GenericObjectPool
/*     */ {
/*  42 */   private AbandonedConfig config = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private List trace = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbandonedObjectPool(PoolableObjectFactory factory, AbandonedConfig config) {
/*  57 */     super(factory);
/*  58 */     this.config = config;
/*  59 */     System.out.println("AbandonedObjectPool is used (" + this + ")");
/*  60 */     System.out.println("   LogAbandoned: " + config.getLogAbandoned());
/*  61 */     System.out.println("   RemoveAbandoned: " + config.getRemoveAbandoned());
/*  62 */     System.out.println("   RemoveAbandonedTimeout: " + config.getRemoveAbandonedTimeout());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object borrowObject() throws Exception {
/*  78 */     if (this.config != null && this.config.getRemoveAbandoned() && getNumIdle() < 2 && getNumActive() > getMaxActive() - 3)
/*     */     {
/*     */ 
/*     */       
/*  82 */       removeAbandoned();
/*     */     }
/*  84 */     Object obj = super.borrowObject();
/*  85 */     if (obj instanceof AbandonedTrace) {
/*  86 */       ((AbandonedTrace)obj).setStackTrace();
/*     */     }
/*  88 */     if (obj != null && this.config != null && this.config.getRemoveAbandoned()) {
/*  89 */       synchronized (this.trace) {
/*  90 */         this.trace.add(obj);
/*     */       } 
/*     */     }
/*  93 */     return obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void returnObject(Object obj) throws Exception {
/* 104 */     if (this.config != null && this.config.getRemoveAbandoned()) {
/* 105 */       synchronized (this.trace) {
/* 106 */         boolean foundObject = this.trace.remove(obj);
/* 107 */         if (!foundObject) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */     }
/* 112 */     super.returnObject(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invalidateObject(Object obj) throws Exception {
/* 122 */     if (this.config != null && this.config.getRemoveAbandoned()) {
/* 123 */       synchronized (this.trace) {
/* 124 */         boolean foundObject = this.trace.remove(obj);
/* 125 */         if (!foundObject) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */     }
/* 130 */     super.invalidateObject(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeAbandoned() {
/* 139 */     long now = System.currentTimeMillis();
/* 140 */     long timeout = now - (this.config.getRemoveAbandonedTimeout() * 1000);
/* 141 */     ArrayList remove = new ArrayList();
/* 142 */     synchronized (this.trace) {
/* 143 */       Iterator iterator = this.trace.iterator();
/* 144 */       while (iterator.hasNext()) {
/* 145 */         AbandonedTrace pc = iterator.next();
/* 146 */         if (pc.getLastUsed() > timeout) {
/*     */           continue;
/*     */         }
/* 149 */         if (pc.getLastUsed() > 0L) {
/* 150 */           remove.add(pc);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 156 */     Iterator it = remove.iterator();
/* 157 */     while (it.hasNext()) {
/* 158 */       AbandonedTrace pc = it.next();
/* 159 */       if (this.config.getLogAbandoned()) {
/* 160 */         pc.printStackTrace();
/*     */       }
/*     */       try {
/* 163 */         invalidateObject(pc);
/* 164 */       } catch (Exception e) {
/* 165 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\AbandonedObjectPool.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */