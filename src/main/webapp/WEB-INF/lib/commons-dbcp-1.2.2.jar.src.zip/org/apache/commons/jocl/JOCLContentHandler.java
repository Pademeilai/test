/*     */ package org.apache.commons.jocl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JOCLContentHandler
/*     */   extends DefaultHandler
/*     */ {
/*     */   public static final String JOCL_NAMESPACE_URI = "http://apache.org/xml/xmlns/jakarta/commons/jocl";
/*     */   public static final String JOCL_PREFIX = "jocl:";
/*     */   protected ArrayList _typeList;
/*     */   protected ArrayList _valueList;
/*     */   protected ConstructorDetails _cur;
/*     */   protected boolean _acceptEmptyNamespaceForElements;
/*     */   protected boolean _acceptJoclPrefixForElements;
/*     */   protected boolean _acceptEmptyNamespaceForAttributes;
/*     */   protected boolean _acceptJoclPrefixForAttributes;
/*     */   protected Locator _locator;
/*     */   protected static final String ELT_OBJECT = "object";
/*     */   protected static final String ATT_CLASS = "class";
/*     */   protected static final String ATT_ISNULL = "null";
/*     */   protected static final String ELT_BOOLEAN = "boolean";
/*     */   protected static final String ELT_BYTE = "byte";
/*     */   protected static final String ELT_CHAR = "char";
/*     */   protected static final String ELT_DOUBLE = "double";
/*     */   protected static final String ELT_FLOAT = "float";
/*     */   protected static final String ELT_INT = "int";
/*     */   protected static final String ELT_LONG = "long";
/*     */   protected static final String ELT_SHORT = "short";
/*     */   protected static final String ELT_STRING = "string";
/*     */   protected static final String ATT_VALUE = "value";
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 228 */     JOCLContentHandler jocl = parse(System.in, (XMLReader)null);
/* 229 */     for (int i = 0; i < jocl.size(); i++) {
/* 230 */       System.out.println("<" + jocl.getType(i) + ">\t" + jocl.getValue(i));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JOCLContentHandler parse(File f) throws SAXException, FileNotFoundException, IOException {
/* 244 */     return parse(new FileInputStream(f), (XMLReader)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JOCLContentHandler parse(Reader in) throws SAXException, IOException {
/* 257 */     return parse(new InputSource(in), (XMLReader)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JOCLContentHandler parse(InputStream in) throws SAXException, IOException {
/* 270 */     return parse(new InputSource(in), (XMLReader)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JOCLContentHandler parse(InputSource in) throws SAXException, IOException {
/* 283 */     return parse(in, (XMLReader)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JOCLContentHandler parse(File f, XMLReader reader) throws SAXException, FileNotFoundException, IOException {
/* 297 */     return parse(new FileInputStream(f), reader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JOCLContentHandler parse(Reader in, XMLReader reader) throws SAXException, IOException {
/* 310 */     return parse(new InputSource(in), reader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JOCLContentHandler parse(InputStream in, XMLReader reader) throws SAXException, IOException {
/* 323 */     return parse(new InputSource(in), reader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JOCLContentHandler parse(InputSource in, XMLReader reader) throws SAXException, IOException {
/* 336 */     JOCLContentHandler jocl = new JOCLContentHandler();
/* 337 */     if (null == reader) {
/* 338 */       reader = XMLReaderFactory.createXMLReader();
/*     */     }
/* 340 */     reader.setContentHandler(jocl);
/* 341 */     reader.parse(in);
/* 342 */     return jocl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JOCLContentHandler() {
/* 351 */     this(true, true, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JOCLContentHandler(boolean emptyEltNS, boolean joclEltPrefix, boolean emptyAttrNS, boolean joclAttrPrefix) {
/* 609 */     this._typeList = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 614 */     this._valueList = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 619 */     this._cur = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 627 */     this._acceptEmptyNamespaceForElements = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 637 */     this._acceptJoclPrefixForElements = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 645 */     this._acceptEmptyNamespaceForAttributes = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 655 */     this._acceptJoclPrefixForAttributes = true;
/*     */ 
/*     */     
/* 658 */     this._locator = null; this._acceptEmptyNamespaceForElements = emptyEltNS; this._acceptJoclPrefixForElements = joclEltPrefix; this._acceptEmptyNamespaceForAttributes = emptyAttrNS; this._acceptJoclPrefixForAttributes = joclAttrPrefix;
/*     */   }
/*     */   public int size() { return this._typeList.size(); }
/*     */   public void clear() { this._typeList = new ArrayList(); this._valueList = new ArrayList(); }
/*     */   public void clear(int i) { this._typeList.remove(i); this._valueList.remove(i); }
/*     */   public Class getType(int i) { return this._typeList.get(i); }
/*     */   public Object getValue(int i) { return this._valueList.get(i); }
/*     */   public Object[] getValueArray() { return this._valueList.toArray(); }
/*     */   public Object[] getTypeArray() { return this._typeList.toArray(); }
/*     */   public void startElement(String uri, String localName, String qname, Attributes attr) throws SAXException { try { if (isJoclNamespace(uri, localName, qname))
/*     */         if ("object".equals(localName)) { String cname = getAttributeValue("class", attr); String isnullstr = getAttributeValue("null", attr, "false"); boolean isnull = ("true".equalsIgnoreCase(isnullstr) || "yes".equalsIgnoreCase(isnullstr)); this._cur = new ConstructorDetails(cname, this._cur, isnull); }
/*     */         else if ("boolean".equals(localName)) { String valstr = getAttributeValue("value", attr, "false"); boolean val = ("true".equalsIgnoreCase(valstr) || "yes".equalsIgnoreCase(valstr)); addObject(boolean.class, new Boolean(val)); }
/*     */         else if ("byte".equals(localName)) { byte val = Byte.parseByte(getAttributeValue("value", attr, "0")); addObject(byte.class, new Byte(val)); }
/*     */         else if ("char".equals(localName)) { char val = Character.MIN_VALUE; String valstr = getAttributeValue("value", attr); if (null == valstr) { val = Character.MIN_VALUE; }
/*     */           else { if (valstr.length() > 1)
/*     */               throw new SAXException("if present, char value must be exactly one character long");  if (valstr.length() == 1) { val = valstr.charAt(0); }
/*     */             else if (valstr.length() == 0) { throw new SAXException("if present, char value must be exactly one character long"); }
/*     */              }
/*     */            addObject(char.class, new Character(val)); }
/*     */         else if ("double".equals(localName)) { double val = Double.parseDouble(getAttributeValue("value", attr, "0")); addObject(double.class, new Double(val)); }
/*     */         else if ("float".equals(localName)) { float val = Float.parseFloat(getAttributeValue("value", attr, "0")); addObject(float.class, new Float(val)); }
/*     */         else if ("int".equals(localName)) { int val = Integer.parseInt(getAttributeValue("value", attr, "0")); addObject(int.class, new Integer(val)); }
/*     */         else if ("long".equals(localName)) { long val = Long.parseLong(getAttributeValue("value", attr, "0")); addObject(long.class, new Long(val)); }
/*     */         else if ("short".equals(localName)) { short val = Short.parseShort(getAttributeValue("value", attr, "0")); addObject(short.class, new Short(val)); }
/*     */         else if ("string".equals(localName)) { String val = getAttributeValue("value", attr); addObject("".getClass(), val); }
/*     */           }
/*     */     catch (Exception e) { throw new SAXException(e); }
/*     */      }
/*     */   public void endElement(String uri, String localName, String qname) throws SAXException { try { if (isJoclNamespace(uri, localName, qname) && "object".equals(localName)) { ConstructorDetails temp = this._cur; this._cur = this._cur.getParent(); if (null == this._cur) {
/*     */           this._typeList.add(temp.getType()); this._valueList.add(temp.createObject());
/*     */         } else {
/*     */           this._cur.addArgument(temp.getType(), temp.createObject());
/*     */         }  }
/*     */        }
/*     */     catch (Exception e)
/*     */     { throw new SAXException(e); }
/*     */      }
/*     */   public void setDocumentLocator(Locator locator) { this._locator = locator; }
/*     */   protected boolean isJoclNamespace(String uri, String localname, String qname) { if ("http://apache.org/xml/xmlns/jakarta/commons/jocl".equals(uri))
/*     */       return true;  if (this._acceptEmptyNamespaceForElements && (null == uri || "".equals(uri)))
/*     */       return true;  if (this._acceptJoclPrefixForElements && (null == uri || "".equals(uri)) && qname.startsWith("jocl:"))
/*     */       return true;  return false; } protected String getAttributeValue(String localname, Attributes attr) { return getAttributeValue(localname, attr, null); } protected String getAttributeValue(String localname, Attributes attr, String implied) { String val = attr.getValue("http://apache.org/xml/xmlns/jakarta/commons/jocl", localname); if (null == val && this._acceptEmptyNamespaceForAttributes)
/*     */       val = attr.getValue("", localname);  if (null == val && this._acceptJoclPrefixForAttributes)
/*     */       val = attr.getValue("", "jocl:" + localname);  return (null == val) ? implied : val; } protected void addObject(Class type, Object val) { if (null == this._cur) {
/*     */       this._typeList.add(type); this._valueList.add(val);
/*     */     } else {
/*     */       this._cur.addArgument(type, val);
/*     */     }  } class ConstructorDetails
/*     */   {
/* 707 */     private ConstructorDetails _parent; private Class _type; private ArrayList _argTypes; public ConstructorDetails(String classname, ConstructorDetails parent) throws ClassNotFoundException { this(Class.forName(classname), parent, false); }
/*     */     
/*     */     private ArrayList _argValues; private boolean _isnull; private final JOCLContentHandler this$0;
/*     */     public ConstructorDetails(String classname, ConstructorDetails parent, boolean isnull) throws ClassNotFoundException {
/* 711 */       this(Class.forName(classname), parent, isnull);
/*     */     }
/*     */     public ConstructorDetails(Class type, ConstructorDetails parent, boolean isnull) {
/* 714 */       JOCLContentHandler.this = JOCLContentHandler.this; this._parent = null; this._type = null; this._argTypes = null; this._argValues = null; this._isnull = false;
/* 715 */       this._parent = parent;
/* 716 */       this._type = type;
/* 717 */       this._argTypes = new ArrayList();
/* 718 */       this._argValues = new ArrayList();
/* 719 */       this._isnull = isnull;
/*     */     }
/*     */     
/*     */     public void addArgument(Object value) {
/* 723 */       addArgument(value.getClass(), value);
/*     */     }
/*     */     
/*     */     public void addArgument(Class type, Object val) {
/* 727 */       if (this._isnull) {
/* 728 */         throw new NullPointerException("can't add arguments to null instances");
/*     */       }
/* 730 */       this._argTypes.add(type);
/* 731 */       this._argValues.add(val);
/*     */     }
/*     */     
/*     */     public Class getType() {
/* 735 */       return this._type;
/*     */     }
/*     */     
/*     */     public ConstructorDetails getParent() {
/* 739 */       return this._parent;
/*     */     }
/*     */     
/*     */     public Object createObject() throws InstantiationException, ClassNotFoundException, IllegalAccessException, InvocationTargetException {
/* 743 */       if (this._isnull) {
/* 744 */         return null;
/*     */       }
/* 746 */       Class k = getType();
/* 747 */       Class[] argtypes = (Class[])this._argTypes.toArray((Object[])new Class[0]);
/* 748 */       Object[] argvals = this._argValues.toArray();
/* 749 */       return ConstructorUtil.invokeConstructor(k, argtypes, argvals);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\jocl\JOCLContentHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */