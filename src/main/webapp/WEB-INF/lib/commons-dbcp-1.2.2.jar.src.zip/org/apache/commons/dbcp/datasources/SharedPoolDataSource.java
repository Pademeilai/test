/*     */ package org.apache.commons.dbcp.datasources;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.sql.ConnectionPoolDataSource;
/*     */ import org.apache.commons.dbcp.SQLNestedException;
/*     */ import org.apache.commons.pool.KeyedObjectPool;
/*     */ import org.apache.commons.pool.impl.GenericKeyedObjectPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SharedPoolDataSource
/*     */   extends InstanceKeyDataSource
/*     */ {
/*  48 */   private final Map userKeys = new LRUMap(10);
/*     */   
/*  50 */   private int maxActive = 8;
/*  51 */   private int maxIdle = 8;
/*  52 */   private int maxWait = (int)Math.min(2147483647L, -1L);
/*     */   
/*  54 */   private KeyedObjectPool pool = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws Exception {
/*  66 */     if (this.pool != null) {
/*  67 */       this.pool.close();
/*     */     }
/*  69 */     InstanceKeyObjectFactory.removeInstance(this.instanceKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxActive() {
/*  80 */     return this.maxActive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxActive(int maxActive) {
/*  89 */     assertInitializationAllowed();
/*  90 */     this.maxActive = maxActive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxIdle() {
/*  98 */     return this.maxIdle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxIdle(int maxIdle) {
/* 107 */     assertInitializationAllowed();
/* 108 */     this.maxIdle = maxIdle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxWait() {
/* 119 */     return this.maxWait;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxWait(int maxWait) {
/* 130 */     assertInitializationAllowed();
/* 131 */     this.maxWait = maxWait;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumActive() {
/* 141 */     return (this.pool == null) ? 0 : this.pool.getNumActive();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumIdle() {
/* 148 */     return (this.pool == null) ? 0 : this.pool.getNumIdle();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized PooledConnectionAndInfo getPooledConnectionAndInfo(String username, String password) throws SQLException {
/* 157 */     if (this.pool == null) {
/*     */       try {
/* 159 */         registerPool(username, password);
/* 160 */       } catch (NamingException e) {
/* 161 */         throw new SQLNestedException("RegisterPool failed", e);
/*     */       } 
/*     */     }
/*     */     
/* 165 */     PooledConnectionAndInfo info = null;
/*     */     try {
/* 167 */       info = (PooledConnectionAndInfo)this.pool.borrowObject(getUserPassKey(username, password));
/*     */     
/*     */     }
/* 170 */     catch (Exception e) {
/* 171 */       throw new SQLNestedException("Could not retrieve connection info from pool", e);
/*     */     } 
/*     */     
/* 174 */     return info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reference getReference() throws NamingException {
/* 183 */     Reference ref = new Reference(getClass().getName(), SharedPoolDataSourceFactory.class.getName(), null);
/*     */     
/* 185 */     ref.add(new StringRefAddr("instanceKey", this.instanceKey));
/* 186 */     return ref;
/*     */   }
/*     */   
/*     */   private UserPassKey getUserPassKey(String username, String password) {
/* 190 */     UserPassKey key = (UserPassKey)this.userKeys.get(username);
/* 191 */     if (key == null) {
/* 192 */       key = new UserPassKey(username, password);
/* 193 */       this.userKeys.put(username, key);
/*     */     } 
/* 195 */     return key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerPool(String username, String password) throws NamingException, SQLException {
/* 202 */     ConnectionPoolDataSource cpds = testCPDS(username, password);
/*     */ 
/*     */     
/* 205 */     GenericKeyedObjectPool tmpPool = new GenericKeyedObjectPool(null);
/* 206 */     tmpPool.setMaxActive(getMaxActive());
/* 207 */     tmpPool.setMaxIdle(getMaxIdle());
/* 208 */     tmpPool.setMaxWait(getMaxWait());
/* 209 */     tmpPool.setWhenExhaustedAction(whenExhaustedAction(this.maxActive, this.maxWait));
/* 210 */     tmpPool.setTestOnBorrow(getTestOnBorrow());
/* 211 */     tmpPool.setTestOnReturn(getTestOnReturn());
/* 212 */     tmpPool.setTimeBetweenEvictionRunsMillis(getTimeBetweenEvictionRunsMillis());
/*     */     
/* 214 */     tmpPool.setNumTestsPerEvictionRun(getNumTestsPerEvictionRun());
/* 215 */     tmpPool.setMinEvictableIdleTimeMillis(getMinEvictableIdleTimeMillis());
/* 216 */     tmpPool.setTestWhileIdle(getTestWhileIdle());
/* 217 */     this.pool = (KeyedObjectPool)tmpPool;
/*     */ 
/*     */ 
/*     */     
/* 221 */     new KeyedCPDSConnectionFactory(cpds, this.pool, getValidationQuery(), isRollbackAfterValidation());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setupDefaults(Connection con, String username) throws SQLException {
/* 227 */     con.setAutoCommit(isDefaultAutoCommit());
/* 228 */     int defaultTransactionIsolation = getDefaultTransactionIsolation();
/* 229 */     if (defaultTransactionIsolation != -1) {
/* 230 */       con.setTransactionIsolation(defaultTransactionIsolation);
/*     */     }
/* 232 */     con.setReadOnly(isDefaultReadOnly());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/*     */     try {
/* 246 */       in.defaultReadObject();
/* 247 */       SharedPoolDataSource oldDS = (SharedPoolDataSource)(new SharedPoolDataSourceFactory()).getObjectInstance(getReference(), null, null, null);
/*     */ 
/*     */       
/* 250 */       this.pool = oldDS.pool;
/*     */     }
/* 252 */     catch (NamingException e) {
/*     */       
/* 254 */       throw new IOException("NamingException: " + e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\datasources\SharedPoolDataSource.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */