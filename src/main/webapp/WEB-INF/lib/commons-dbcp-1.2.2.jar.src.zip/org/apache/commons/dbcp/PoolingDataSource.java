/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.pool.ObjectPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoolingDataSource
/*     */   implements DataSource
/*     */ {
/*     */   private boolean accessToUnderlyingConnectionAllowed = false;
/*     */   protected PrintWriter _logWriter;
/*     */   protected ObjectPool _pool;
/*     */   
/*     */   public PoolingDataSource() {
/*  51 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPool(ObjectPool pool) throws IllegalStateException, NullPointerException {
/*  59 */     if (null != this._pool)
/*  60 */       throw new IllegalStateException("Pool already set"); 
/*  61 */     if (null == pool) {
/*  62 */       throw new NullPointerException("Pool must not be null.");
/*     */     }
/*  64 */     this._pool = pool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAccessToUnderlyingConnectionAllowed() {
/*  74 */     return this.accessToUnderlyingConnectionAllowed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccessToUnderlyingConnectionAllowed(boolean allow) {
/*  85 */     this.accessToUnderlyingConnectionAllowed = allow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/*     */     try {
/*  96 */       Connection conn = (Connection)this._pool.borrowObject();
/*  97 */       if (conn != null) {
/*  98 */         conn = new PoolGuardConnectionWrapper(this, conn);
/*     */       }
/* 100 */       return conn;
/* 101 */     } catch (SQLException e) {
/* 102 */       throw e;
/* 103 */     } catch (NoSuchElementException e) {
/* 104 */       throw new SQLNestedException("Cannot get a connection, pool error " + e.getMessage(), e);
/* 105 */     } catch (RuntimeException e) {
/* 106 */       throw e;
/* 107 */     } catch (Exception e) {
/* 108 */       throw new SQLNestedException("Cannot get a connection, general error", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection(String uname, String passwd) throws SQLException {
/* 117 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getLogWriter() {
/* 126 */     return this._logWriter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLoginTimeout() {
/* 135 */     throw new UnsupportedOperationException("Login timeout is not supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginTimeout(int seconds) {
/* 144 */     throw new UnsupportedOperationException("Login timeout is not supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogWriter(PrintWriter out) {
/* 152 */     this._logWriter = out;
/*     */   }
/*     */   
/*     */   public PoolingDataSource(ObjectPool pool) {
/* 156 */     this._logWriter = null;
/*     */     
/* 158 */     this._pool = null;
/*     */     this._pool = pool;
/*     */   }
/*     */   
/*     */   private class PoolGuardConnectionWrapper
/*     */     extends DelegatingConnection
/*     */   {
/*     */     private Connection delegate;
/*     */     private final PoolingDataSource this$0;
/*     */     
/*     */     PoolGuardConnectionWrapper(PoolingDataSource this$0, Connection delegate) {
/* 169 */       super(delegate); this.this$0 = this$0;
/* 170 */       this.delegate = delegate;
/*     */     }
/*     */     
/*     */     protected void checkOpen() throws SQLException {
/* 174 */       if (this.delegate == null) {
/* 175 */         throw new SQLException("Connection is closed.");
/*     */       }
/*     */     }
/*     */     
/*     */     public void close() throws SQLException {
/* 180 */       checkOpen();
/* 181 */       this.delegate.close();
/* 182 */       this.delegate = null;
/* 183 */       setDelegate(null);
/*     */     }
/*     */     
/*     */     public boolean isClosed() throws SQLException {
/* 187 */       if (this.delegate == null) {
/* 188 */         return true;
/*     */       }
/* 190 */       return this.delegate.isClosed();
/*     */     }
/*     */     
/*     */     public void clearWarnings() throws SQLException {
/* 194 */       checkOpen();
/* 195 */       this.delegate.clearWarnings();
/*     */     }
/*     */     
/*     */     public void commit() throws SQLException {
/* 199 */       checkOpen();
/* 200 */       this.delegate.commit();
/*     */     }
/*     */     
/*     */     public Statement createStatement() throws SQLException {
/* 204 */       checkOpen();
/* 205 */       return this.delegate.createStatement();
/*     */     }
/*     */     
/*     */     public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/* 209 */       checkOpen();
/* 210 */       return this.delegate.createStatement(resultSetType, resultSetConcurrency);
/*     */     }
/*     */     
/*     */     public boolean innermostDelegateEquals(Connection c) {
/* 214 */       Connection innerCon = super.getInnermostDelegate();
/* 215 */       if (innerCon == null) {
/* 216 */         return (c == null);
/*     */       }
/* 218 */       return innerCon.equals(c);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean getAutoCommit() throws SQLException {
/* 223 */       checkOpen();
/* 224 */       return this.delegate.getAutoCommit();
/*     */     }
/*     */     
/*     */     public String getCatalog() throws SQLException {
/* 228 */       checkOpen();
/* 229 */       return this.delegate.getCatalog();
/*     */     }
/*     */     
/*     */     public DatabaseMetaData getMetaData() throws SQLException {
/* 233 */       checkOpen();
/* 234 */       return this.delegate.getMetaData();
/*     */     }
/*     */     
/*     */     public int getTransactionIsolation() throws SQLException {
/* 238 */       checkOpen();
/* 239 */       return this.delegate.getTransactionIsolation();
/*     */     }
/*     */     
/*     */     public Map getTypeMap() throws SQLException {
/* 243 */       checkOpen();
/* 244 */       return this.delegate.getTypeMap();
/*     */     }
/*     */     
/*     */     public SQLWarning getWarnings() throws SQLException {
/* 248 */       checkOpen();
/* 249 */       return this.delegate.getWarnings();
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 253 */       if (this.delegate == null) {
/* 254 */         return 0;
/*     */       }
/* 256 */       return this.delegate.hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj) {
/* 260 */       if (obj == null) {
/* 261 */         return false;
/*     */       }
/* 263 */       if (obj == this) {
/* 264 */         return true;
/*     */       }
/*     */       
/* 267 */       Connection delegate = super.getInnermostDelegate();
/* 268 */       if (delegate == null) {
/* 269 */         return false;
/*     */       }
/* 271 */       if (obj instanceof DelegatingConnection) {
/* 272 */         DelegatingConnection c = (DelegatingConnection)obj;
/* 273 */         return c.innermostDelegateEquals(delegate);
/*     */       } 
/*     */       
/* 276 */       return delegate.equals(obj);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isReadOnly() throws SQLException {
/* 281 */       checkOpen();
/* 282 */       return this.delegate.isReadOnly();
/*     */     }
/*     */     
/*     */     public String nativeSQL(String sql) throws SQLException {
/* 286 */       checkOpen();
/* 287 */       return this.delegate.nativeSQL(sql);
/*     */     }
/*     */     
/*     */     public CallableStatement prepareCall(String sql) throws SQLException {
/* 291 */       checkOpen();
/* 292 */       return this.delegate.prepareCall(sql);
/*     */     }
/*     */     
/*     */     public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 296 */       checkOpen();
/* 297 */       return this.delegate.prepareCall(sql, resultSetType, resultSetConcurrency);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql) throws SQLException {
/* 301 */       checkOpen();
/* 302 */       return this.delegate.prepareStatement(sql);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 306 */       checkOpen();
/* 307 */       return this.delegate.prepareStatement(sql, resultSetType, resultSetConcurrency);
/*     */     }
/*     */     
/*     */     public void rollback() throws SQLException {
/* 311 */       checkOpen();
/* 312 */       this.delegate.rollback();
/*     */     }
/*     */     
/*     */     public void setAutoCommit(boolean autoCommit) throws SQLException {
/* 316 */       checkOpen();
/* 317 */       this.delegate.setAutoCommit(autoCommit);
/*     */     }
/*     */     
/*     */     public void setCatalog(String catalog) throws SQLException {
/* 321 */       checkOpen();
/* 322 */       this.delegate.setCatalog(catalog);
/*     */     }
/*     */     
/*     */     public void setReadOnly(boolean readOnly) throws SQLException {
/* 326 */       checkOpen();
/* 327 */       this.delegate.setReadOnly(readOnly);
/*     */     }
/*     */     
/*     */     public void setTransactionIsolation(int level) throws SQLException {
/* 331 */       checkOpen();
/* 332 */       this.delegate.setTransactionIsolation(level);
/*     */     }
/*     */     
/*     */     public void setTypeMap(Map map) throws SQLException {
/* 336 */       checkOpen();
/* 337 */       this.delegate.setTypeMap(map);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 341 */       if (this.delegate == null) {
/* 342 */         return null;
/*     */       }
/* 344 */       return this.delegate.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getHoldability() throws SQLException {
/* 353 */       checkOpen();
/* 354 */       return this.delegate.getHoldability();
/*     */     }
/*     */     
/*     */     public void setHoldability(int holdability) throws SQLException {
/* 358 */       checkOpen();
/* 359 */       this.delegate.setHoldability(holdability);
/*     */     }
/*     */     
/*     */     public Savepoint setSavepoint() throws SQLException {
/* 363 */       checkOpen();
/* 364 */       return this.delegate.setSavepoint();
/*     */     }
/*     */     
/*     */     public Savepoint setSavepoint(String name) throws SQLException {
/* 368 */       checkOpen();
/* 369 */       return this.delegate.setSavepoint(name);
/*     */     }
/*     */     
/*     */     public void releaseSavepoint(Savepoint savepoint) throws SQLException {
/* 373 */       checkOpen();
/* 374 */       this.delegate.releaseSavepoint(savepoint);
/*     */     }
/*     */     
/*     */     public void rollback(Savepoint savepoint) throws SQLException {
/* 378 */       checkOpen();
/* 379 */       this.delegate.rollback(savepoint);
/*     */     }
/*     */     
/*     */     public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 383 */       checkOpen();
/* 384 */       return this.delegate.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */     }
/*     */     
/*     */     public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 388 */       checkOpen();
/* 389 */       return this.delegate.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException {
/* 393 */       checkOpen();
/* 394 */       return this.delegate.prepareStatement(sql, autoGeneratedKeys);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 398 */       checkOpen();
/* 399 */       return this.delegate.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException {
/* 403 */       checkOpen();
/* 404 */       return this.delegate.prepareStatement(sql, columnIndexes);
/*     */     }
/*     */     
/*     */     public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException {
/* 408 */       checkOpen();
/* 409 */       return this.delegate.prepareStatement(sql, columnNames);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Connection getDelegate() {
/* 418 */       if (this.this$0.isAccessToUnderlyingConnectionAllowed()) {
/* 419 */         return super.getDelegate();
/*     */       }
/* 421 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Connection getInnermostDelegate() {
/* 429 */       if (this.this$0.isAccessToUnderlyingConnectionAllowed()) {
/* 430 */         return super.getInnermostDelegate();
/*     */       }
/* 432 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\PoolingDataSource.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */