/*     */ package org.apache.commons.dbcp.cpdsadapter;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Hashtable;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.Referenceable;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ import javax.sql.ConnectionPoolDataSource;
/*     */ import javax.sql.PooledConnection;
/*     */ import org.apache.commons.pool.KeyedObjectPool;
/*     */ import org.apache.commons.pool.impl.GenericKeyedObjectPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DriverAdapterCPDS
/*     */   implements ConnectionPoolDataSource, Referenceable, Serializable, ObjectFactory
/*     */ {
/*     */   private static final String GET_CONNECTION_CALLED = "A PooledConnection was already requested from this source, further initialization is not allowed.";
/*     */   private String description;
/*     */   private String password;
/*     */   private String url;
/*     */   private String user;
/*     */   private String driver;
/*     */   private int loginTimeout;
/* 108 */   private PrintWriter logWriter = null;
/*     */   
/*     */   private boolean poolPreparedStatements;
/*     */   
/* 112 */   private int maxActive = 10;
/* 113 */   private int maxIdle = 10;
/* 114 */   private int _timeBetweenEvictionRunsMillis = -1;
/* 115 */   private int _numTestsPerEvictionRun = -1;
/* 116 */   private int _minEvictableIdleTimeMillis = -1;
/* 117 */   private int _maxPreparedStatements = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean getConnectionCalled = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PooledConnection getPooledConnection() throws SQLException {
/* 132 */     return getPooledConnection(getUser(), getPassword());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PooledConnection getPooledConnection(String username, String password) throws SQLException {
/*     */     GenericKeyedObjectPool genericKeyedObjectPool;
/* 141 */     this.getConnectionCalled = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     KeyedObjectPool stmtPool = null;
/* 151 */     if (isPoolPreparedStatements()) {
/* 152 */       if (getMaxPreparedStatements() <= 0) {
/*     */ 
/*     */ 
/*     */         
/* 156 */         genericKeyedObjectPool = new GenericKeyedObjectPool(null, getMaxActive(), (byte)2, 0L, getMaxIdle(), false, false, getTimeBetweenEvictionRunsMillis(), getNumTestsPerEvictionRun(), getMinEvictableIdleTimeMillis(), false);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 167 */         genericKeyedObjectPool = new GenericKeyedObjectPool(null, getMaxActive(), (byte)2, 0L, getMaxIdle(), getMaxPreparedStatements(), false, false, -1L, 0, 0L, false);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 177 */       return new PooledConnectionImpl(DriverManager.getConnection(getUrl(), username, password), (KeyedObjectPool)genericKeyedObjectPool);
/*     */ 
/*     */     
/*     */     }
/* 181 */     catch (ClassCircularityError e) {
/*     */       
/* 183 */       return new PooledConnectionImpl(DriverManager.getConnection(getUrl(), username, password), (KeyedObjectPool)genericKeyedObjectPool);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reference getReference() throws NamingException {
/* 197 */     String factory = getClass().getName();
/*     */     
/* 199 */     Reference ref = new Reference(getClass().getName(), factory, null);
/*     */     
/* 201 */     ref.add(new StringRefAddr("description", getDescription()));
/* 202 */     ref.add(new StringRefAddr("driver", getDriver()));
/* 203 */     ref.add(new StringRefAddr("loginTimeout", String.valueOf(getLoginTimeout())));
/*     */     
/* 205 */     ref.add(new StringRefAddr("password", getPassword()));
/* 206 */     ref.add(new StringRefAddr("user", getUser()));
/* 207 */     ref.add(new StringRefAddr("url", getUrl()));
/*     */     
/* 209 */     ref.add(new StringRefAddr("poolPreparedStatements", String.valueOf(isPoolPreparedStatements())));
/*     */     
/* 211 */     ref.add(new StringRefAddr("maxActive", String.valueOf(getMaxActive())));
/*     */     
/* 213 */     ref.add(new StringRefAddr("maxIdle", String.valueOf(getMaxIdle())));
/*     */     
/* 215 */     ref.add(new StringRefAddr("timeBetweenEvictionRunsMillis", String.valueOf(getTimeBetweenEvictionRunsMillis())));
/*     */     
/* 217 */     ref.add(new StringRefAddr("numTestsPerEvictionRun", String.valueOf(getNumTestsPerEvictionRun())));
/*     */     
/* 219 */     ref.add(new StringRefAddr("minEvictableIdleTimeMillis", String.valueOf(getMinEvictableIdleTimeMillis())));
/*     */     
/* 221 */     ref.add(new StringRefAddr("maxPreparedStatements", String.valueOf(getMaxPreparedStatements())));
/*     */ 
/*     */     
/* 224 */     return ref;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObjectInstance(Object refObj, Name name, Context context, Hashtable env) throws Exception {
/* 239 */     DriverAdapterCPDS cpds = null;
/* 240 */     if (refObj instanceof Reference) {
/* 241 */       Reference ref = (Reference)refObj;
/* 242 */       if (ref.getClassName().equals(getClass().getName())) {
/* 243 */         RefAddr ra = ref.get("description");
/* 244 */         if (ra != null && ra.getContent() != null) {
/* 245 */           setDescription(ra.getContent().toString());
/*     */         }
/*     */         
/* 248 */         ra = ref.get("driver");
/* 249 */         if (ra != null && ra.getContent() != null) {
/* 250 */           setDriver(ra.getContent().toString());
/*     */         }
/* 252 */         ra = ref.get("url");
/* 253 */         if (ra != null && ra.getContent() != null) {
/* 254 */           setUrl(ra.getContent().toString());
/*     */         }
/* 256 */         ra = ref.get("user");
/* 257 */         if (ra != null && ra.getContent() != null) {
/* 258 */           setUser(ra.getContent().toString());
/*     */         }
/* 260 */         ra = ref.get("password");
/* 261 */         if (ra != null && ra.getContent() != null) {
/* 262 */           setPassword(ra.getContent().toString());
/*     */         }
/*     */         
/* 265 */         ra = ref.get("poolPreparedStatements");
/* 266 */         if (ra != null && ra.getContent() != null) {
/* 267 */           setPoolPreparedStatements(Boolean.getBoolean(ra.getContent().toString()));
/*     */         }
/*     */         
/* 270 */         ra = ref.get("maxActive");
/* 271 */         if (ra != null && ra.getContent() != null) {
/* 272 */           setMaxActive(Integer.parseInt(ra.getContent().toString()));
/*     */         }
/*     */         
/* 275 */         ra = ref.get("maxIdle");
/* 276 */         if (ra != null && ra.getContent() != null) {
/* 277 */           setMaxIdle(Integer.parseInt(ra.getContent().toString()));
/*     */         }
/*     */         
/* 280 */         ra = ref.get("timeBetweenEvictionRunsMillis");
/* 281 */         if (ra != null && ra.getContent() != null) {
/* 282 */           setTimeBetweenEvictionRunsMillis(Integer.parseInt(ra.getContent().toString()));
/*     */         }
/*     */ 
/*     */         
/* 286 */         ra = ref.get("numTestsPerEvictionRun");
/* 287 */         if (ra != null && ra.getContent() != null) {
/* 288 */           setNumTestsPerEvictionRun(Integer.parseInt(ra.getContent().toString()));
/*     */         }
/*     */ 
/*     */         
/* 292 */         ra = ref.get("minEvictableIdleTimeMillis");
/* 293 */         if (ra != null && ra.getContent() != null) {
/* 294 */           setMinEvictableIdleTimeMillis(Integer.parseInt(ra.getContent().toString()));
/*     */         }
/*     */         
/* 297 */         ra = ref.get("maxPreparedStatements");
/* 298 */         if (ra != null && ra.getContent() != null) {
/* 299 */           setMaxPreparedStatements(Integer.parseInt(ra.getContent().toString()));
/*     */         }
/*     */ 
/*     */         
/* 303 */         cpds = this;
/*     */       } 
/*     */     } 
/* 306 */     return cpds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void assertInitializationAllowed() throws IllegalStateException {
/* 314 */     if (this.getConnectionCalled) {
/* 315 */       throw new IllegalStateException("A PooledConnection was already requested from this source, further initialization is not allowed.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 330 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String v) {
/* 341 */     this.description = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPassword() {
/* 349 */     return this.password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPassword(String v) {
/* 357 */     assertInitializationAllowed();
/* 358 */     this.password = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUrl() {
/* 366 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrl(String v) {
/* 374 */     assertInitializationAllowed();
/* 375 */     this.url = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUser() {
/* 383 */     return this.user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUser(String v) {
/* 391 */     assertInitializationAllowed();
/* 392 */     this.user = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDriver() {
/* 400 */     return this.driver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDriver(String v) throws ClassNotFoundException {
/* 409 */     assertInitializationAllowed();
/* 410 */     this.driver = v;
/*     */     
/* 412 */     Class.forName(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLoginTimeout() {
/* 420 */     return this.loginTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getLogWriter() {
/* 427 */     return this.logWriter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginTimeout(int seconds) {
/* 435 */     this.loginTimeout = seconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogWriter(PrintWriter out) {
/* 442 */     this.logWriter = out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPoolPreparedStatements() {
/* 455 */     return this.poolPreparedStatements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPoolPreparedStatements(boolean v) {
/* 463 */     assertInitializationAllowed();
/* 464 */     this.poolPreparedStatements = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxActive() {
/* 472 */     return this.maxActive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxActive(int maxActive) {
/* 480 */     assertInitializationAllowed();
/* 481 */     this.maxActive = maxActive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxIdle() {
/* 489 */     return this.maxIdle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxIdle(int maxIdle) {
/* 497 */     assertInitializationAllowed();
/* 498 */     this.maxIdle = maxIdle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTimeBetweenEvictionRunsMillis() {
/* 510 */     return this._timeBetweenEvictionRunsMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeBetweenEvictionRunsMillis(int timeBetweenEvictionRunsMillis) {
/* 523 */     assertInitializationAllowed();
/* 524 */     this._timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumTestsPerEvictionRun() {
/* 535 */     return this._numTestsPerEvictionRun;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumTestsPerEvictionRun(int numTestsPerEvictionRun) {
/* 550 */     assertInitializationAllowed();
/* 551 */     this._numTestsPerEvictionRun = numTestsPerEvictionRun;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinEvictableIdleTimeMillis() {
/* 563 */     return this._minEvictableIdleTimeMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMinEvictableIdleTimeMillis(int minEvictableIdleTimeMillis) {
/* 577 */     assertInitializationAllowed();
/* 578 */     this._minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxPreparedStatements() {
/* 589 */     return this._maxPreparedStatements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxPreparedStatements(int maxPreparedStatements) {
/* 601 */     this._maxPreparedStatements = maxPreparedStatements;
/*     */   }
/*     */ }


/* Location:              C:\Users\吴光清\Downloads\luntan.war!\WEB-INF\lib\commons-dbcp-1.2.2.jar!\org\apache\commons\dbcp\cpdsadapter\DriverAdapterCPDS.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */